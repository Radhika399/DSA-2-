//package tries;
// // // // // public class Classroom {

// // // // //     // Trie Node
// // // // //     static class Node {
// // // // //         Node[] children = new Node[26];
// // // // //         boolean eow; // end of word

// // // // //         Node() {
// // // // //             for (int i = 0; i < 26; i++) {
// // // // //                 children[i] = null;
// // // // //             }
// // // // //             eow = false;
// // // // //         }
// // // // //     }

// // // // //     static Node root = new Node();

// // // // //     // Insert word into Trie
// // // // //     public static void insert(String word) {
// // // // //         Node curr = root;
// // // // //         for (int level = 0; level < word.length(); level++) {
// // // // //             int idx = word.charAt(level) - 'a';
// // // // //             if (curr.children[idx] == null) {
// // // // //                 curr.children[idx] = new Node();
// // // // //             }
// // // // //             curr = curr.children[idx];
// // // // //         }
// // // // //         curr.eow = true; // mark end of word
// // // // //     }

// // // // //     // Search word in Trie
// // // // //     public static boolean search(String key) {
// // // // //         Node curr = root;
// // // // //         for (int level = 0; level < key.length(); level++) {
// // // // //             int idx = key.charAt(level) - 'a';
// // // // //             if (curr.children[idx] == null) return false;
// // // // //             curr = curr.children[idx];
// // // // //         }
// // // // //         return curr.eow;
// // // // //     }

// // // // //     public static void main(String[] args) {
// // // // //         String[] words = {"the", "there", "their", "any", "thee"};

// // // // //         // Insert all words
// // // // //         for (String word : words) {
// // // // //             insert(word);
// // // // //         }

// // // // //         // Test search
// // // // //         System.out.println(search("the"));    // true
// // // // //         System.out.println(search("their"));  // true
// // // // //         System.out.println(search("there"));  // true
// // // // //         System.out.println(search("these"));  // false
// // // // //         System.out.println(search("any"));    // true
// // // // //     }
// // // // // }










// // // // // Word Break Problem
// // // // // Given an input string and a dictionary of words, find out if the input string
// // // // // can be broken into a space-separated sequence of dictionary words.
// // // // // words[ I = ( i, like, sam, samsung, mobile, ice)
// // // // // key = "ilikesamsung"
// // // // // output: true

// // // // import java.util.*;

// // // // public class Classroom {

// // // //     // Function to check if string can be segmented
// // // //     public static boolean wordBreak(String s, String[] wordDict) {
// // // //         Set<String> dict = new HashSet<>(Arrays.asList(wordDict));
// // // //         int n = s.length();
// // // //         boolean[] dp = new boolean[n + 1]; // dp[i] = true if s[0..i-1] can be segmented
// // // //         dp[0] = true; // empty string can always be segmented

// // // //         for (int i = 1; i <= n; i++) {
// // // //             for (int j = 0; j < i; j++) {
// // // //                 if (dp[j] && dict.contains(s.substring(j, i))) {
// // // //                     dp[i] = true;
// // // //                     break;
// // // //                 }
// // // //             }
// // // //         }

// // // //         return dp[n];
// // // //     }

// // // //     public static void main(String[] args) {
// // // //         String[] words = {"i", "like", "sam", "samsung", "mobile", "ice"};
// // // //         String key = "ilikesamsung";

// // // //         boolean canBreak = wordBreak(key, words);
// // // //         System.out.println(canBreak); // Output: true
// // // //     }
// // // // }









// // // // Prefix Problem
// // // // Find shortest unique prefix for every word in a given list.
// // // // Assume no word is prefix of another.
// // // // arr[l : {"zebra", "dog", "duck", "dove")
// // // // ans {"z", "dog", "du", "dov")

// // // public class Classroom {

// // //     static class Node {
// // //         Node[] children = new Node[26];
// // //         int freq; // number of words passing through this node
// // //         boolean isEnd;

// // //         Node() {
// // //             for (int i = 0; i < 26; i++) {
// // //                 children[i] = null;
// // //             }
// // //             freq = 1;
// // //             isEnd = false;
// // //         }
// // //     }

// // //     static Node root = new Node();

// // //     // Insert word into Trie and update frequency
// // //     public static void insert(String word) {
// // //         Node curr = root;
// // //         for (int i = 0; i < word.length(); i++) {
// // //             int idx = word.charAt(i) - 'a';
// // //             if (curr.children[idx] == null) {
// // //                 curr.children[idx] = new Node();
// // //             } else {
// // //                 curr.children[idx].freq++;
// // //             }
// // //             curr = curr.children[idx];
// // //         }
// // //         curr.isEnd = true;
// // //     }

// // //     // Find shortest unique prefix for a given word
// // //     public static String getPrefix(String word) {
// // //         Node curr = root;
// // //         StringBuilder prefix = new StringBuilder();
// // //         for (int i = 0; i < word.length(); i++) {
// // //             int idx = word.charAt(i) - 'a';
// // //             prefix.append(word.charAt(i));
// // //             if (curr.children[idx].freq == 1) {
// // //                 break; // unique prefix found
// // //             }
// // //             curr = curr.children[idx];
// // //         }
// // //         return prefix.toString();
// // //     }

// // //     public static void main(String[] args) {
// // //         String[] words = {"zebra", "dog", "duck", "dove"};

// // //         // Insert all words into Trie
// // //         for (String word : words) {
// // //             insert(word);
// // //         }

// // //         // Get and print shortest unique prefixes
// // //         for (String word : words) {
// // //             System.out.println(word + " -> " + getPrefix(word));
// // //         }
// // //     }
// // // }





// // // 'startsWith Problem
// // // Create a function boolean startsWith(String prefix) for a trie.
// // // Returns true if there is a previously inserted string word that has the prefix
// // // otherwise.
// // // words( I = { "apple", "app", "mang&", "man", "woman" )
// // // prefix = "app
// // // output: true
// // // prefix = "moon"
// // // output: false

// // public class Classroom {

// //     static class Node {
// //         Node[] children = new Node[26];
// //         boolean isEnd;

// //         Node() {
// //             for (int i = 0; i < 26; i++) {
// //                 children[i] = null;
// //             }
// //             isEnd = false;
// //         }
// //     }

// //     static Node root = new Node();

// //     // Insert a word into the trie
// //     public static void insert(String word) {
// //         Node curr = root;
// //         for (int i = 0; i < word.length(); i++) {
// //             int idx = word.charAt(i) - 'a';
// //             if (curr.children[idx] == null) {
// //                 curr.children[idx] = new Node();
// //             }
// //             curr = curr.children[idx];
// //         }
// //         curr.isEnd = true;
// //     }

// //     // Check if any word in the trie starts with the given prefix
// //     public static boolean startsWith(String prefix) {
// //         Node curr = root;
// //         for (int i = 0; i < prefix.length(); i++) {
// //             int idx = prefix.charAt(i) - 'a';
// //             if (curr.children[idx] == null) {
// //                 return false;
// //             }
// //             curr = curr.children[idx];
// //         }
// //         return true; // all characters of prefix found
// //     }

// //     public static void main(String[] args) {
// //         String[] words = {"apple", "app", "mango", "man", "woman"};

// //         // Insert words into the trie
// //         for (String word : words) {
// //             insert(word);
// //         }

// //         // Test prefixes
// //         String prefix1 = "app";
// //         String prefix2 = "moon";

// //         System.out.println(prefix1 + ": " + startsWith(prefix1)); // true
// //         System.out.println(prefix2 + ": " + startsWith(prefix2)); // false
// //     }
// // }







// // Count Unique Substrings
// // Given a string of length n of lowercase alphabet characters, we need to count total number of
// // distinct substrings of this string.
// // str = "ababa"
// // ans = 10


// class Classroom {

//     static class Node {
//         Node[] children = new Node[26];
//         boolean eow; // end of word

//         Node() {
//             for (int i = 0; i < 26; i++) {
//                 children[i] = null;
//             }
//             eow = false;
//         }
//     }

//     static Node root = new Node();

//     // Insert a word (or suffix) into the trie
//     public static void insert(String word) {
//         Node curr = root;
//         for (int i = 0; i < word.length(); i++) {
//             int idx = word.charAt(i) - 'a';
//             if (curr.children[idx] == null) {
//                 curr.children[idx] = new Node();
//             }
//             curr = curr.children[idx];
//         }
//         curr.eow = true;
//     }

//     // Count all nodes in the trie
//     public static int countNodes(Node node) {
//         if (node == null) return 0;
//         int count = 0;
//         for (int i = 0; i < 26; i++) {
//             if (node.children[i] != null) {
//                 count += countNodes(node.children[i]);
//             }
//         }
//         return count + 1; // count current node
//     }

//     // Count distinct substrings
//     public static int countDistinctSubstrings(String str) {
//         // Insert all suffixes
//         for (int i = 0; i < str.length(); i++) {
//             insert(str.substring(i));
//         }
//         // Total nodes - 1 (excluding root)
//         return countNodes(root) - 1;
//     }

//     public static void main(String[] args) {
//         String str = "ababa";
//         System.out.println("Total distinct substrings: " + countDistinctSubstrings(str));
//     }
// }
