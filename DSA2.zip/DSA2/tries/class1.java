//package tries;
// public class class1 {

//     // Trie Node
//     static class Node {
//         Node[] children = new Node[26];
//         boolean eow; // end of word

//         public Node() {
//             for (int i = 0; i < 26; i++) {
//                 children[i] = null;
//             }
//             eow = false;
//         }
//     }

//     static Node root = new Node();
//     static String ans = ""; // to store longest word

//     // Insert word into Trie
//     public static void insert(String word) {
//         Node curr = root;
//         for (int level = 0; level < word.length(); level++) {
//             int idx = word.charAt(level) - 'a';
//             if (curr.children[idx] == null) {
//                 curr.children[idx] = new Node();
//             }
//             curr = curr.children[idx];
//         }
//         curr.eow = true;
//     }

//     // Search word in Trie
//     public static boolean search(String key) {
//         Node curr = root;
//         for (int i = 0; i < key.length(); i++) {
//             int idx = key.charAt(i) - 'a';
//             if (curr.children[idx] == null) return false;
//             curr = curr.children[idx];
//         }
//         return curr.eow;
//     }

//     // Find longest word such that all prefixes exist
//     public static void longestWord(Node root, StringBuilder temp) {
//         if (root == null) return;

//         for (int i = 0; i < 26; i++) {
//             if (root.children[i] != null && root.children[i].eow) {
//                 char ch = (char) (i + 'a');
//                 temp.append(ch);
//                 if (temp.length() > ans.length()) {
//                     ans = temp.toString();
//                 }
//                 longestWord(root.children[i], temp);
//                 temp.deleteCharAt(temp.length() - 1); // backtrack
//             }
//         }
//     }

//     public static void main(String[] args) {
//         String[] words = {"a", "ap", "app", "appl", "apple", "apply"};
//         for (String word : words) {
//             insert(word);
//         }

//         System.out.println("Search 'apple': " + search("apple")); // true
//         System.out.println("Search 'ap': " + search("ap")); // true
//         System.out.println("Search 'appx': " + search("appx")); // false

//         // Find longest word with all prefixes present
//         longestWord(root, new StringBuilder());
//         System.out.println("Longest word with all prefixes: " + ans);
//     }
// }
