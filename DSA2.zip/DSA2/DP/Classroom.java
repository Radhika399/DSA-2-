//package DP;
// // // // // // // // // // // // // // // // // // public class Classroom {

// // // // // // // // // // // // // // // // // //     // 1. Recursive Fibonacci
// // // // // // // // // // // // // // // // // //     public static int fibRecursive(int n) {
// // // // // // // // // // // // // // // // // //         if (n <= 1) {
// // // // // // // // // // // // // // // // // //             return n;
// // // // // // // // // // // // // // // // // //         }
// // // // // // // // // // // // // // // // // //         return fibRecursive(n - 1) + fibRecursive(n - 2);
// // // // // // // // // // // // // // // // // //     }

// // // // // // // // // // // // // // // // // //     // 2. Fibonacci with Memoization (Top Down)
// // // // // // // // // // // // // // // // // //     public static int fibMemo(int n, int[] dp) {
// // // // // // // // // // // // // // // // // //         if (n <= 1) {
// // // // // // // // // // // // // // // // // //             return n;
// // // // // // // // // // // // // // // // // //         }
// // // // // // // // // // // // // // // // // //         if (dp[n] != -1) {
// // // // // // // // // // // // // // // // // //             return dp[n]; // already calculated
// // // // // // // // // // // // // // // // // //         }
// // // // // // // // // // // // // // // // // //         dp[n] = fibMemo(n - 1, dp) + fibMemo(n - 2, dp);
// // // // // // // // // // // // // // // // // //         return dp[n];
// // // // // // // // // // // // // // // // // //     }

// // // // // // // // // // // // // // // // // //     // 3. Fibonacci with Tabulation (Bottom Up)
// // // // // // // // // // // // // // // // // //     public static int fibTabulation(int n) {
// // // // // // // // // // // // // // // // // //         int[] dp = new int[n + 1];
// // // // // // // // // // // // // // // // // //         dp[0] = 0;
// // // // // // // // // // // // // // // // // //         dp[1] = 1;

// // // // // // // // // // // // // // // // // //         for (int i = 2; i <= n; i++) {
// // // // // // // // // // // // // // // // // //             dp[i] = dp[i - 1] + dp[i - 2];
// // // // // // // // // // // // // // // // // //         }
// // // // // // // // // // // // // // // // // //         return dp[n];
// // // // // // // // // // // // // // // // // //     }

// // // // // // // // // // // // // // // // // //     // Driver code
// // // // // // // // // // // // // // // // // //     public static void main(String[] args) {
// // // // // // // // // // // // // // // // // //         int n = 10;

// // // // // // // // // // // // // // // // // //         System.out.println("Recursive: " + fibRecursive(n));

// // // // // // // // // // // // // // // // // //         int[] dp = new int[n + 1];
// // // // // // // // // // // // // // // // // //         for (int i = 0; i <= n; i++) {
// // // // // // // // // // // // // // // // // //             dp[i] = -1;
// // // // // // // // // // // // // // // // // //         }
// // // // // // // // // // // // // // // // // //         System.out.println("Memoization: " + fibMemo(n, dp));

// // // // // // // // // // // // // // // // // //         System.out.println("Tabulation: " + fibTabulation(n));
// // // // // // // // // // // // // // // // // //     }
// // // // // // // // // // // // // // // // // // }
















// // // // // // // // // // // // // // // // // // Climbing Stairs
// // // // // // // // // // // // // // // // // // Count ways to reach the nth stair. The person can climb either 1 stair or 2 stairs at a time.

// // // // // // // // // // // // // // // // // import java.util.Arrays;

// // // // // // // // // // // // // // // // // public class Classroom {

// // // // // // // // // // // // // // // // //     // Recursive + Memoization
// // // // // // // // // // // // // // // // //     public static int countWays(int n, int[] ways) {
// // // // // // // // // // // // // // // // //         if (n == 0) return 1;  // one way to stand still
// // // // // // // // // // // // // // // // //         if (n < 0) return 0;   // no way if negative

// // // // // // // // // // // // // // // // //         if (ways[n] != -1) {   // already computed
// // // // // // // // // // // // // // // // //             return ways[n];
// // // // // // // // // // // // // // // // //         }

// // // // // // // // // // // // // // // // //         // either take 1 step or 2 steps
// // // // // // // // // // // // // // // // //         ways[n] = countWays(n - 1, ways) + countWays(n - 2, ways);
// // // // // // // // // // // // // // // // //         return ways[n];
// // // // // // // // // // // // // // // // //     }

// // // // // // // // // // // // // // // // //     // Tabulation (Bottom-up DP)
// // // // // // // // // // // // // // // // //     public static int countWaysTab(int n) {
// // // // // // // // // // // // // // // // //         int[] dp = new int[n + 1];
// // // // // // // // // // // // // // // // //         dp[0] = 1;  // one way to reach step 0

// // // // // // // // // // // // // // // // //         for (int i = 1; i <= n; i++) {
// // // // // // // // // // // // // // // // //             if (i == 1) {
// // // // // // // // // // // // // // // // //                 dp[i] = dp[i - 1]; // only 1 step possible
// // // // // // // // // // // // // // // // //             } else {
// // // // // // // // // // // // // // // // //                 dp[i] = dp[i - 1] + dp[i - 2];
// // // // // // // // // // // // // // // // //             }
// // // // // // // // // // // // // // // // //         }
// // // // // // // // // // // // // // // // //         return dp[n];
// // // // // // // // // // // // // // // // //     }

// // // // // // // // // // // // // // // // //     public static void main(String[] args) {
// // // // // // // // // // // // // // // // //         int n = 5; // Example: n=3 → 3, n=4 → 5, n=5 → 8

// // // // // // // // // // // // // // // // //         // Memoization
// // // // // // // // // // // // // // // // //         int[] ways = new int[n + 1];
// // // // // // // // // // // // // // // // //         Arrays.fill(ways, -1);
// // // // // // // // // // // // // // // // //         System.out.println("Memoization: " + countWays(n, ways));

// // // // // // // // // // // // // // // // //         // Tabulation
// // // // // // // // // // // // // // // // //         System.out.println("Tabulation: " + countWaysTab(n));
// // // // // // // // // // // // // // // // //     }
// // // // // // // // // // // // // // // // // }






// // // // // // // // // // // // // // // // //0-1 kapsack

// // // // // // // // // // // // // // // // public class Classroom {

// // // // // // // // // // // // // // // //     // Recursive + Memoization
// // // // // // // // // // // // // // // //     public static int knapsack(int val[], int wt[], int W, int n, int dp[][]) {
// // // // // // // // // // // // // // // //         // base cases
// // // // // // // // // // // // // // // //         if (n == 0 || W == 0) {
// // // // // // // // // // // // // // // //             return 0;
// // // // // // // // // // // // // // // //         }

// // // // // // // // // // // // // // // //         // if already solved
// // // // // // // // // // // // // // // //         if (dp[n][W] != -1) {
// // // // // // // // // // // // // // // //             return dp[n][W];
// // // // // // // // // // // // // // // //         }

// // // // // // // // // // // // // // // //         // include item if weight is valid
// // // // // // // // // // // // // // // //         if (wt[n - 1] <= W) {
// // // // // // // // // // // // // // // //             int include = val[n - 1] + knapsack(val, wt, W - wt[n - 1], n - 1, dp);
// // // // // // // // // // // // // // // //             int exclude = knapsack(val, wt, W, n - 1, dp);
// // // // // // // // // // // // // // // //             dp[n][W] = Math.max(include, exclude);
// // // // // // // // // // // // // // // //         } else {
// // // // // // // // // // // // // // // //             // cannot include item
// // // // // // // // // // // // // // // //             dp[n][W] = knapsack(val, wt, W, n - 1, dp);
// // // // // // // // // // // // // // // //         }

// // // // // // // // // // // // // // // //         return dp[n][W];
// // // // // // // // // // // // // // // //     }

// // // // // // // // // // // // // // // //     // Bottom-up DP (Tabulation)
// // // // // // // // // // // // // // // //     public static int knapsackDP(int val[], int wt[], int W) {
// // // // // // // // // // // // // // // //         int n = val.length;
// // // // // // // // // // // // // // // //         int dp[][] = new int[n + 1][W + 1];

// // // // // // // // // // // // // // // //         // build DP table
// // // // // // // // // // // // // // // //         for (int i = 1; i <= n; i++) {
// // // // // // // // // // // // // // // //             for (int w = 1; w <= W; w++) {
// // // // // // // // // // // // // // // //                 if (wt[i - 1] <= w) {
// // // // // // // // // // // // // // // //                     int include = val[i - 1] + dp[i - 1][w - wt[i - 1]];
// // // // // // // // // // // // // // // //                     int exclude = dp[i - 1][w];
// // // // // // // // // // // // // // // //                     dp[i][w] = Math.max(include, exclude);
// // // // // // // // // // // // // // // //                 } else {
// // // // // // // // // // // // // // // //                     dp[i][w] = dp[i - 1][w];
// // // // // // // // // // // // // // // //                 }
// // // // // // // // // // // // // // // //             }
// // // // // // // // // // // // // // // //         }

// // // // // // // // // // // // // // // //         return dp[n][W];
// // // // // // // // // // // // // // // //     }

// // // // // // // // // // // // // // // //     public static void main(String args[]) {
// // // // // // // // // // // // // // // //         int val[] = {15, 14, 10, 45, 30};
// // // // // // // // // // // // // // // //         int wt[] = {2, 5, 1, 3, 4};
// // // // // // // // // // // // // // // //         int W = 7;
// // // // // // // // // // // // // // // //         int n = val.length;

// // // // // // // // // // // // // // // //         // memoization
// // // // // // // // // // // // // // // //         int dp[][] = new int[n + 1][W + 1];
// // // // // // // // // // // // // // // //         for (int i = 0; i <= n; i++) {
// // // // // // // // // // // // // // // //             for (int j = 0; j <= W; j++) {
// // // // // // // // // // // // // // // //                 dp[i][j] = -1;
// // // // // // // // // // // // // // // //             }
// // // // // // // // // // // // // // // //         }

// // // // // // // // // // // // // // // //         System.out.println("Knapsack (Memoization): " + knapsack(val, wt, W, n, dp));
// // // // // // // // // // // // // // // //         System.out.println("Knapsack (Tabulation): " + knapsackDP(val, wt, W));
// // // // // // // // // // // // // // // //     }
// // // // // // // // // // // // // // // // }








// // // // // // // // // // // // // // // //implement Subset Sum Problem
// // // // // // // // // // // // // // // public class Classroom {

// // // // // // // // // // // // // // //     // DP solution for Target Sum Subset
// // // // // // // // // // // // // // //     public static boolean targetSumSubset(int arr[], int sum) {
// // // // // // // // // // // // // // //         int n = arr.length;
// // // // // // // // // // // // // // //         boolean dp[][] = new boolean[n + 1][sum + 1];

// // // // // // // // // // // // // // //         // initialize: sum 0 can always be formed with 0 elements
// // // // // // // // // // // // // // //         for (int i = 0; i <= n; i++) {
// // // // // // // // // // // // // // //             dp[i][0] = true;
// // // // // // // // // // // // // // //         }

// // // // // // // // // // // // // // //         // fill the DP table
// // // // // // // // // // // // // // //         for (int i = 1; i <= n; i++) {
// // // // // // // // // // // // // // //             for (int j = 1; j <= sum; j++) {
// // // // // // // // // // // // // // //                 if (arr[i - 1] <= j) {
// // // // // // // // // // // // // // //                     // include arr[i-1] or exclude it
// // // // // // // // // // // // // // //                     dp[i][j] = dp[i - 1][j - arr[i - 1]] || dp[i - 1][j];
// // // // // // // // // // // // // // //                 } else {
// // // // // // // // // // // // // // //                     // cannot include arr[i-1]
// // // // // // // // // // // // // // //                     dp[i][j] = dp[i - 1][j];
// // // // // // // // // // // // // // //                 }
// // // // // // // // // // // // // // //             }
// // // // // // // // // // // // // // //         }

// // // // // // // // // // // // // // //         return dp[n][sum]; // answer: can we form 'sum' using all n elements?
// // // // // // // // // // // // // // //     }

// // // // // // // // // // // // // // //     public static void main(String args[]) {
// // // // // // // // // // // // // // //         int arr[] = {3, 34, 4, 12, 5, 2};
// // // // // // // // // // // // // // //         int sum = 20;

// // // // // // // // // // // // // // //         if (targetSumSubset(arr, sum)) {
// // // // // // // // // // // // // // //             System.out.println("Subset with sum " + sum + " exists.");
// // // // // // // // // // // // // // //         } else {
// // // // // // // // // // // // // // //             System.out.println("Subset with sum " + sum + " does not exist.");
// // // // // // // // // // // // // // //         }
// // // // // // // // // // // // // // //     }
// // // // // // // // // // // // // // // }










// // // // // // // // // // // // // // public class Classroom {

// // // // // // // // // // // // // //     // Unbounded Knapsack DP
// // // // // // // // // // // // // //     public static int unboundedKnapsack(int val[], int wt[], int W) {
// // // // // // // // // // // // // //         int n = val.length;
// // // // // // // // // // // // // //         int dp[][] = new int[n + 1][W + 1];

// // // // // // // // // // // // // //         // initialize dp table
// // // // // // // // // // // // // //         for (int i = 0; i <= n; i++) {
// // // // // // // // // // // // // //             dp[i][0] = 0; // max value for weight 0 is 0
// // // // // // // // // // // // // //         }
// // // // // // // // // // // // // //         for (int j = 0; j <= W; j++) {
// // // // // // // // // // // // // //             dp[0][j] = 0; // max value with 0 items is 0
// // // // // // // // // // // // // //         }

// // // // // // // // // // // // // //         // fill dp table
// // // // // // // // // // // // // //         for (int i = 1; i <= n; i++) {
// // // // // // // // // // // // // //             for (int j = 1; j <= W; j++) {
// // // // // // // // // // // // // //                 if (wt[i - 1] <= j) {
// // // // // // // // // // // // // //                     // include the item (unbounded, so we can include it again)
// // // // // // // // // // // // // //                     dp[i][j] = Math.max(val[i - 1] + dp[i][j - wt[i - 1]], dp[i - 1][j]);
// // // // // // // // // // // // // //                 } else {
// // // // // // // // // // // // // //                     // cannot include the item
// // // // // // // // // // // // // //                     dp[i][j] = dp[i - 1][j];
// // // // // // // // // // // // // //                 }
// // // // // // // // // // // // // //             }
// // // // // // // // // // // // // //         }

// // // // // // // // // // // // // //         return dp[n][W]; // maximum value for n items and weight W
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     public static void main(String args[]) {
// // // // // // // // // // // // // //         int val[] = {15, 14, 10, 45, 30};
// // // // // // // // // // // // // //         int wt[] = {2, 5, 1, 3, 4};
// // // // // // // // // // // // // //         int W = 7;

// // // // // // // // // // // // // //         System.out.println("Maximum value in Unbounded Knapsack: " + unboundedKnapsack(val, wt, W));
// // // // // // // // // // // // // //     }
// // // // // // // // // // // // // // }






















// // // // // // // // // // // // // // Rod Cutting
// // // // // // // // // // // // // // Given a rod of length n inches and an array of prices that includes prices of all pieces of size smaller than n.
// // // // // // // // // // // // // // Determine the maximum value obtainable by cutting up the rod and selling the pieces
// // // // // // // // // // // // // // length -1 2 3 4 5 78
// // // // // // // // // // // // // // price -58 910 17 17 20
// // // // // // // // // // // // // // rodLength = 8

// // // // // // // // // // // // // public class Classroom {

// // // // // // // // // // // // //     // Rod Cutting using DP (Unbounded Knapsack approach)
// // // // // // // // // // // // //     public static int rodCutting(int length[], int price[], int totRod) {
// // // // // // // // // // // // //         int n = price.length;
// // // // // // // // // // // // //         int dp[][] = new int[n + 1][totRod + 1];

// // // // // // // // // // // // //         // Initialize DP table for 0 length or 0 pieces
// // // // // // // // // // // // //         for (int i = 0; i <= n; i++) dp[i][0] = 0;
// // // // // // // // // // // // //         for (int j = 0; j <= totRod; j++) dp[0][j] = 0;

// // // // // // // // // // // // //         // Fill DP table
// // // // // // // // // // // // //         for (int i = 1; i <= n; i++) {
// // // // // // // // // // // // //             for (int j = 1; j <= totRod; j++) {
// // // // // // // // // // // // //                 if (length[i - 1] <= j) {
// // // // // // // // // // // // //                     // include current piece (can include multiple times)
// // // // // // // // // // // // //                     dp[i][j] = Math.max(price[i - 1] + dp[i][j - length[i - 1]], dp[i - 1][j]);
// // // // // // // // // // // // //                 } else {
// // // // // // // // // // // // //                     // cannot include current piece
// // // // // // // // // // // // //                     dp[i][j] = dp[i - 1][j];
// // // // // // // // // // // // //                 }
// // // // // // // // // // // // //             }
// // // // // // // // // // // // //         }

// // // // // // // // // // // // //         return dp[n][totRod]; // Maximum obtainable value
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     public static void main(String args[]) {
// // // // // // // // // // // // //         int length[] = {1, 2, 3, 4, 5, 6, 7, 8}; // piece lengths
// // // // // // // // // // // // //         int price[] = {1, 5, 8, 9, 10, 17, 17, 20}; // prices for each piece
// // // // // // // // // // // // //         int totRod = 8; // total rod length

// // // // // // // // // // // // //         System.out.println("Maximum value obtainable: " + rodCutting(length, price, totRod));
// // // // // // // // // // // // //     }
// // // // // // // // // // // // // }









// // // // // // // // // // // // // COLLEC
// // // // // // // // // // // // // Longest Common Subsequence
// // // // // // // // // // // // // A subsequence of a string is a new string generated from the original string with some characters (can be none)
// // // // // // // // // // // // // deleted without changing the relative order of the remaining characters.
// // // // // // // // // // // // // strl = "abcde", str2 : "ace"
// // // // // // // // // // // // // ans = 3 Il"ace"
// // // // // // // // // // // // // 12
// // // // // // // // // // // // // strl = "abcdge", str2 = "abedg"

// // // // // // // // // // // // public class Classroom {

// // // // // // // // // // // //     // Recursive LCS
// // // // // // // // // // // //     public static int lcs(String str1, String str2, int n, int m) {
// // // // // // // // // // // //         if (n == 0 || m == 0) return 0;
// // // // // // // // // // // //         if (str1.charAt(n - 1) == str2.charAt(m - 1)) {
// // // // // // // // // // // //             return 1 + lcs(str1, str2, n - 1, m - 1);
// // // // // // // // // // // //         } else {
// // // // // // // // // // // //             return Math.max(lcs(str1, str2, n - 1, m), lcs(str1, str2, n, m - 1));
// // // // // // // // // // // //         }
// // // // // // // // // // // //     }

// // // // // // // // // // // //     // LCS with memoization
// // // // // // // // // // // //     public static int lcsMemo(String str1, String str2, int n, int m, int[][] dp) {
// // // // // // // // // // // //         if (n == 0 || m == 0) return 0;
// // // // // // // // // // // //         if (dp[n][m] != -1) return dp[n][m];

// // // // // // // // // // // //         if (str1.charAt(n - 1) == str2.charAt(m - 1)) {
// // // // // // // // // // // //             dp[n][m] = 1 + lcsMemo(str1, str2, n - 1, m - 1, dp);
// // // // // // // // // // // //         } else {
// // // // // // // // // // // //             dp[n][m] = Math.max(lcsMemo(str1, str2, n - 1, m, dp), lcsMemo(str1, str2, n, m - 1, dp));
// // // // // // // // // // // //         }
// // // // // // // // // // // //         return dp[n][m];
// // // // // // // // // // // //     }

// // // // // // // // // // // //     // LCS using tabulation
// // // // // // // // // // // //     public static int lcsTab(String str1, String str2) {
// // // // // // // // // // // //         int n = str1.length();
// // // // // // // // // // // //         int m = str2.length();
// // // // // // // // // // // //         int[][] dp = new int[n + 1][m + 1];

// // // // // // // // // // // //         for (int i = 0; i <= n; i++) {
// // // // // // // // // // // //             for (int j = 0; j <= m; j++) {
// // // // // // // // // // // //                 if (i == 0 || j == 0) dp[i][j] = 0;
// // // // // // // // // // // //                 else if (str1.charAt(i - 1) == str2.charAt(j - 1))
// // // // // // // // // // // //                     dp[i][j] = 1 + dp[i - 1][j - 1];
// // // // // // // // // // // //                 else
// // // // // // // // // // // //                     dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
// // // // // // // // // // // //             }
// // // // // // // // // // // //         }
// // // // // // // // // // // //         return dp[n][m];
// // // // // // // // // // // //     }

// // // // // // // // // // // //     public static void main(String[] args) {
// // // // // // // // // // // //         String str1 = "abcdge";
// // // // // // // // // // // //         String str2 = "abedg";

// // // // // // // // // // // //         int n = str1.length();
// // // // // // // // // // // //         int m = str2.length();

// // // // // // // // // // // //         // Recursive
// // // // // // // // // // // //         System.out.println("LCS length (recursive): " + lcs(str1, str2, n, m));

// // // // // // // // // // // //         // Memoization
// // // // // // // // // // // //         int[][] dp = new int[n + 1][m + 1];
// // // // // // // // // // // //         for (int i = 0; i <= n; i++) {
// // // // // // // // // // // //             for (int j = 0; j <= m; j++) dp[i][j] = -1;
// // // // // // // // // // // //         }
// // // // // // // // // // // //         System.out.println("LCS length (memoization): " + lcsMemo(str1, str2, n, m, dp));

// // // // // // // // // // // //         // Tabulation
// // // // // // // // // // // //         System.out.println("LCS length (tabulation): " + lcsTab(str1, str2));
// // // // // // // // // // // //     }
// // // // // // // // // // // // }







// // // // // // // // // // // // Longest Common Substring
// // // // // // // // // // // // a substring is a contiguous sequence of characters within a string
// // // // // // // // // // // // Sl "ABCDE", S2 "ABGCE"
// // // // // // // // // // // // ans 2 11 "AB"
// // // // // // // // // // // // Sl "ABCDGH", S2 : "ACDGHR"
// // // // // // // // // // // // ans 411 "CDGH"
// // // // // // // // // // // public class Classroom {

// // // // // // // // // // //     // Function to find length of longest common substring
// // // // // // // // // // //     public static int longestCommonSubstring(String str1, String str2) {
// // // // // // // // // // //         int n = str1.length();
// // // // // // // // // // //         int m = str2.length();
// // // // // // // // // // //         int[][] dp = new int[n + 1][m + 1];

// // // // // // // // // // //         int maxLen = 0;

// // // // // // // // // // //         // Initialize DP table (first row and first column are 0)
// // // // // // // // // // //         for (int i = 0; i <= n; i++) dp[i][0] = 0;
// // // // // // // // // // //         for (int j = 0; j <= m; j++) dp[0][j] = 0;

// // // // // // // // // // //         // Build the DP table
// // // // // // // // // // //         for (int i = 1; i <= n; i++) {
// // // // // // // // // // //             for (int j = 1; j <= m; j++) {
// // // // // // // // // // //                 if (str1.charAt(i - 1) == str2.charAt(j - 1)) {
// // // // // // // // // // //                     dp[i][j] = 1 + dp[i - 1][j - 1];
// // // // // // // // // // //                     maxLen = Math.max(maxLen, dp[i][j]);
// // // // // // // // // // //                 } else {
// // // // // // // // // // //                     dp[i][j] = 0; // reset for non-contiguous characters
// // // // // // // // // // //                 }
// // // // // // // // // // //             }
// // // // // // // // // // //         }
// // // // // // // // // // //         return maxLen;
// // // // // // // // // // //     }

// // // // // // // // // // //     public static void main(String[] args) {
// // // // // // // // // // //         String str1 = "ABCDE";
// // // // // // // // // // //         String str2 = "ABGCE";

// // // // // // // // // // //         System.out.println("Length of Longest Common Substring: " + longestCommonSubstring(str1, str2));
// // // // // // // // // // //         // Output: 2 ("AB")

// // // // // // // // // // //         String str3 = "ABCDGH";
// // // // // // // // // // //         String str4 = "ACDGHR";

// // // // // // // // // // //         System.out.println("Length of Longest Common Substring: " + longestCommonSubstring(str3, str4));
// // // // // // // // // // //         // Output: 4 ("CDGH")
// // // // // // // // // // //     }
// // // // // // // // // // // }






// // // // // // // // // // // Longest Increasing Subsequence
// // // // // // // // // // // arr[l = (50, 3, 10, 7, 40, 80)
// // // // // // // // // // // Length of LIS: 4

// // // // // // // // // // import java.util.*;

// // // // // // // // // // public class Classroom {

// // // // // // // // // //     // Helper function: Longest Common Subsequence (LCS)
// // // // // // // // // //     public static int lcs(int[] arr1, int[] arr2) {
// // // // // // // // // //         int n = arr1.length;
// // // // // // // // // //         int m = arr2.length;
// // // // // // // // // //         int[][] dp = new int[n + 1][m + 1];

// // // // // // // // // //         for (int i = 0; i <= n; i++) dp[i][0] = 0;
// // // // // // // // // //         for (int j = 0; j <= m; j++) dp[0][j] = 0;

// // // // // // // // // //         for (int i = 1; i <= n; i++) {
// // // // // // // // // //             for (int j = 1; j <= m; j++) {
// // // // // // // // // //                 if (arr1[i - 1] == arr2[j - 1]) {
// // // // // // // // // //                     dp[i][j] = 1 + dp[i - 1][j - 1];
// // // // // // // // // //                 } else {
// // // // // // // // // //                     dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
// // // // // // // // // //                 }
// // // // // // // // // //             }
// // // // // // // // // //         }
// // // // // // // // // //         return dp[n][m];
// // // // // // // // // //     }

// // // // // // // // // //     // LIS using LCS approach
// // // // // // // // // //     public static int lis(int[] arr) {
// // // // // // // // // //         HashSet<Integer> set = new HashSet<>();
// // // // // // // // // //         for (int num : arr) {
// // // // // // // // // //             set.add(num); // store unique elements
// // // // // // // // // //         }

// // // // // // // // // //         int[] sortedUnique = new int[set.size()];
// // // // // // // // // //         int i = 0;
// // // // // // // // // //         for (int num : set) {
// // // // // // // // // //             sortedUnique[i++] = num;
// // // // // // // // // //         }
// // // // // // // // // //         Arrays.sort(sortedUnique); // sort in ascending order

// // // // // // // // // //         return lcs(arr, sortedUnique);
// // // // // // // // // //     }

// // // // // // // // // //     public static void main(String[] args) {
// // // // // // // // // //         int[] arr = {50, 3, 10, 7, 40, 80};
// // // // // // // // // //         System.out.println("Length of LIS: " + lis(arr)); // Output: 4
// // // // // // // // // //     }
// // // // // // // // // // }







// // // // // // // // // // Edit Distance
// // // // // // // // // // Given two strings wordl and word2, return the minimum number of operations required to convert wordl to
// // // // // // // // // // word2.
// // // // // // // // // // You have the following three operations permitted on a word:
// // // // // // // // // // • Insert a character
// // // // // // // // // // • Delete a character
// // // // // // // // // // • Replace a character
// // // // // // // // // // wordl = "intention", word2 : "execution"
// // // // // // // // // // intention -> inention (remove 't')
// // // // // // // // // // inention enention (replace 'i' with 'e')
// // // // // // // // // // enention -> exention (replace 'n' with 'x')
// // // // // // // // // // exention -> exection (replace 'n' with 'c')
// // // // // // // // // // exection execution (insert 'u')
// // // // // // // // // // ans : 5



// // // // // // // // // public class Classroom {

// // // // // // // // //     public static int editDistance(String word1, String word2) {
// // // // // // // // //         int n = word1.length();
// // // // // // // // //         int m = word2.length();

// // // // // // // // //         int[][] dp = new int[n + 1][m + 1];

// // // // // // // // //         // Initialize base cases
// // // // // // // // //         for (int i = 0; i <= n; i++) dp[i][0] = i; // delete all characters
// // // // // // // // //         for (int j = 0; j <= m; j++) dp[0][j] = j; // insert all characters

// // // // // // // // //         // Bottom-up DP
// // // // // // // // //         for (int i = 1; i <= n; i++) {
// // // // // // // // //             for (int j = 1; j <= m; j++) {
// // // // // // // // //                 if (word1.charAt(i - 1) == word2.charAt(j - 1)) {
// // // // // // // // //                     dp[i][j] = dp[i - 1][j - 1]; // same character, no operation
// // // // // // // // //                 } else {
// // // // // // // // //                     int insertOp = dp[i][j - 1] + 1;    // insert
// // // // // // // // //                     int deleteOp = dp[i - 1][j] + 1;    // delete
// // // // // // // // //                     int replaceOp = dp[i - 1][j - 1] + 1; // replace
// // // // // // // // //                     dp[i][j] = Math.min(insertOp, Math.min(deleteOp, replaceOp));
// // // // // // // // //                 }
// // // // // // // // //             }
// // // // // // // // //         }

// // // // // // // // //         return dp[n][m];
// // // // // // // // //     }

// // // // // // // // //     public static void main(String[] args) {
// // // // // // // // //         String word1 = "intention";
// // // // // // // // //         String word2 = "execution";

// // // // // // // // //         System.out.println("Minimum operations to convert \"" + word1 + "\" to \"" + word2 + "\": " 
// // // // // // // // //                            + editDistance(word1, word2));
// // // // // // // // //     }
// // // // // // // // // }













// // // // // // // // // String Conversion
// // // // // // // // // Convert Stringl to String2 with only insertion & deletion.
// // // // // // // // // Print number of deletions & insertions.
// // // // // // // // // rl : "Dear" str2 z"

// // // // // // // // public class Classroom {

// // // // // // // //     // Function to compute LCS length
// // // // // // // //     public static int lcsLength(String str1, String str2) {
// // // // // // // //         int n = str1.length();
// // // // // // // //         int m = str2.length();
// // // // // // // //         int[][] dp = new int[n + 1][m + 1];

// // // // // // // //         for (int i = 0; i <= n; i++) {
// // // // // // // //             for (int j = 0; j <= m; j++) {
// // // // // // // //                 if (i == 0 || j == 0) dp[i][j] = 0;
// // // // // // // //                 else if (str1.charAt(i - 1) == str2.charAt(j - 1)) dp[i][j] = dp[i - 1][j - 1] + 1;
// // // // // // // //                 else dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
// // // // // // // //             }
// // // // // // // //         }

// // // // // // // //         return dp[n][m];
// // // // // // // //     }

// // // // // // // //     public static void main(String[] args) {
// // // // // // // //         String str1 = "Dear";
// // // // // // // //         String str2 = "Ear";

// // // // // // // //         int lcsLen = lcsLength(str1, str2);

// // // // // // // //         int deletions = str1.length() - lcsLen;
// // // // // // // //         int insertions = str2.length() - lcsLen;

// // // // // // // //         System.out.println("Deletions needed: " + deletions);
// // // // // // // //         System.out.println("Insertions needed: " + insertions);
// // // // // // // //     }
// // // // // // // // }







// // // // // // // // Wildcard Matching
// // // // // // // // Given a text and a wildcard pattern, implement wildcard Dattern matching algorithm that finds if wildcard
// // // // // // // // pattern is matched with text. The matching should cover the entire text (not partial text). The wildcard
// // // // // // // // pattern can include the characters '?' and '*'
// // // // // // // // • matches any single character
// // // // // // // // • '*' - Matches any sequence of characters (including the empty sequence)
// // // // // // // // Text : "baaabab"
// // // // // // // // Pattern :
// // // // // // // // output : true
// // // // // // // // Text = "baaabab"
// // // // // // // // Pattern = "a*ab"
// // // // // // // // output : false

// // // // // // // public class Classroom {

// // // // // // //     public static boolean isMatch(String text, String pattern) {
// // // // // // //         int n = text.length();
// // // // // // //         int m = pattern.length();
// // // // // // //         boolean[][] dp = new boolean[n + 1][m + 1];

// // // // // // //         // Empty pattern matches empty text
// // // // // // //         dp[0][0] = true;

// // // // // // //         // Initialize first row (text is empty)
// // // // // // //         for (int j = 1; j <= m; j++) {
// // // // // // //             if (pattern.charAt(j - 1) == '*') dp[0][j] = dp[0][j - 1];
// // // // // // //         }

// // // // // // //         // Fill the DP table
// // // // // // //         for (int i = 1; i <= n; i++) {
// // // // // // //             for (int j = 1; j <= m; j++) {
// // // // // // //                 char sc = text.charAt(i - 1);
// // // // // // //                 char pc = pattern.charAt(j - 1);

// // // // // // //                 if (pc == sc || pc == '?') {
// // // // // // //                     // Match single character
// // // // // // //                     dp[i][j] = dp[i - 1][j - 1];
// // // // // // //                 } else if (pc == '*') {
// // // // // // //                     // '*' matches empty sequence (dp[i][j-1])
// // // // // // //                     // or '*' matches one or more chars (dp[i-1][j])
// // // // // // //                     dp[i][j] = dp[i][j - 1] || dp[i - 1][j];
// // // // // // //                 } else {
// // // // // // //                     dp[i][j] = false; // No match
// // // // // // //                 }
// // // // // // //             }
// // // // // // //         }

// // // // // // //         return dp[n][m];
// // // // // // //     }

// // // // // // //     public static void main(String[] args) {
// // // // // // //         String text1 = "baaabab";
// // // // // // //         String pattern1 = "ba*a?ab";
// // // // // // //         System.out.println(isMatch(text1, pattern1)); // true

// // // // // // //         String text2 = "baaabab";
// // // // // // //         String pattern2 = "a*ab";
// // // // // // //         System.out.println(isMatch(text2, pattern2)); // false
// // // // // // //     }
// // // // // // // }

















// // // // // // //Catalan numbers using recursion, memoization, and tabulation:
// // // // // // import java.util.Arrays;

// // // // // // public class Classroom {

// // // // // //     // Recursive solution (inefficient for large n)
// // // // // //     public static int catalanRec(int n) {
// // // // // //         if (n <= 1) return 1;
// // // // // //         int ans = 0;
// // // // // //         for (int i = 0; i <= n - 1; i++) {
// // // // // //             ans += catalanRec(i) * catalanRec(n - 1 - i);
// // // // // //         }
// // // // // //         return ans;
// // // // // //     }

// // // // // //     // Memoized solution (top-down DP)
// // // // // //     public static int catalanMem(int n, int[] dp) {
// // // // // //         if (n <= 1) return 1;
// // // // // //         if (dp[n] != -1) return dp[n];

// // // // // //         int ans = 0;
// // // // // //         for (int i = 0; i <= n - 1; i++) {
// // // // // //             ans += catalanMem(i, dp) * catalanMem(n - 1 - i, dp);
// // // // // //         }
// // // // // //         dp[n] = ans;
// // // // // //         return ans;
// // // // // //     }

// // // // // //     // Tabulation solution (bottom-up DP)
// // // // // //     public static int catalanTab(int n) {
// // // // // //         int[] dp = new int[n + 1];
// // // // // //         dp[0] = dp[1] = 1;

// // // // // //         for (int i = 2; i <= n; i++) {
// // // // // //             dp[i] = 0;
// // // // // //             for (int j = 0; j < i; j++) {
// // // // // //                 dp[i] += dp[j] * dp[i - 1 - j];
// // // // // //             }
// // // // // //         }

// // // // // //         return dp[n];
// // // // // //     }

// // // // // //     public static void main(String[] args) {
// // // // // //         int n = 4;

// // // // // //         System.out.println("Recursive: " + catalanRec(n));

// // // // // //         int[] dp = new int[n + 1];
// // // // // //         Arrays.fill(dp, -1);
// // // // // //         System.out.println("Memoization: " + catalanMem(n, dp));

// // // // // //         System.out.println("Tabulation: " + catalanTab(n));
// // // // // //     }
// // // // // // }



















// // // // // // Counting Trees
// // // // // // Find number of all possible BSTs with given n nodes.
// // // // // // n 3 (10, 20, 30)
// // // // // // ans = 5

// // // // // // to count the number of possible BSTs for n nodes. This is essentially calculating the nth Catalan number, as the number of BSTs with n distinct nodes is Catalan(n).

// // // // // public class Classroom {

// // // // //     // Function to count number of BSTs with n nodes (Tabulation)
// // // // //     public static int countBST(int n) {
// // // // //         int[] dp = new int[n + 1];
// // // // //         dp[0] = 1; // Empty tree
// // // // //         dp[1] = 1; // Single node tree

// // // // //         // Fill dp[] iteratively
// // // // //         for (int i = 2; i <= n; i++) {
// // // // //             dp[i] = 0;
// // // // //             for (int j = 0; j < i; j++) {
// // // // //                 dp[i] += dp[j] * dp[i - 1 - j];
// // // // //             }
// // // // //         }

// // // // //         return dp[n];
// // // // //     }

// // // // //     public static void main(String[] args) {
// // // // //         int n = 3; // Example: nodes 10, 20, 30
// // // // //         System.out.println("Number of BSTs with " + n + " nodes: " + countBST(n));
// // // // //     }
// // // // // }








// // // // //number of mountain ranges problem, which is also a Catalan number problem.

// // // // public class Classroom {

// // // //     // Function to count number of mountain ranges (Catalan number)
// // // //     public static int countMountainRanges(int n) {
// // // //         int[] dp = new int[n + 1];
// // // //         dp[0] = 1; // Empty sequence
// // // //         dp[1] = 1; // Single peak

// // // //         for (int i = 2; i <= n; i++) {
// // // //             dp[i] = 0;
// // // //             for (int j = 0; j < i; j++) {
// // // //                 dp[i] += dp[j] * dp[i - 1 - j];
// // // //             }
// // // //         }

// // // //         return dp[n];
// // // //     }

// // // //     public static void main(String[] args) {
// // // //         int n = 4; // Number of pairs of parentheses / mountain peaks
// // // //         System.out.println("Number of mountain ranges with " + n + " pairs: " + countMountainRanges(n));
// // // //     }
// // // // }















// // // //implementation of Matrix Chain Multiplication (MCM) in Java, including recursive, memoized, and tabulation
// // // import java.util.*;

// // // public class Classroom {

// // //     // Recursive MCM
// // //     public static int mcmRec(int[] arr, int i, int j) {
// // //         if (i == j) return 0; // single matrix
// // //         int ans = Integer.MAX_VALUE;

// // //         for (int k = i; k < j; k++) {
// // //             int cost1 = mcmRec(arr, i, k);
// // //             int cost2 = mcmRec(arr, k + 1, j);
// // //             int cost3 = arr[i - 1] * arr[k] * arr[j];
// // //             int finalCost = cost1 + cost2 + cost3;
// // //             ans = Math.min(ans, finalCost);
// // //         }

// // //         return ans;
// // //     }

// // //     // Memoized MCM
// // //     public static int mcmMem(int[] arr, int i, int j, int[][] dp) {
// // //         if (i == j) return 0;
// // //         if (dp[i][j] != -1) return dp[i][j];

// // //         int ans = Integer.MAX_VALUE;
// // //         for (int k = i; k < j; k++) {
// // //             int cost1 = mcmMem(arr, i, k, dp);
// // //             int cost2 = mcmMem(arr, k + 1, j, dp);
// // //             int cost3 = arr[i - 1] * arr[k] * arr[j];
// // //             int finalCost = cost1 + cost2 + cost3;
// // //             ans = Math.min(ans, finalCost);
// // //         }
// // //         return dp[i][j] = ans;
// // //     }

// // //     // Tabulation (Bottom-Up)
// // //     public static int mcmTab(int[] arr) {
// // //         int n = arr.length;
// // //         int[][] dp = new int[n][n];

// // //         for (int len = 2; len < n; len++) { // chain length
// // //             for (int i = 1; i < n - len + 1; i++) {
// // //                 int j = i + len - 1;
// // //                 dp[i][j] = Integer.MAX_VALUE;

// // //                 for (int k = i; k < j; k++) {
// // //                     int cost = dp[i][k] + dp[k + 1][j] + arr[i - 1] * arr[k] * arr[j];
// // //                     dp[i][j] = Math.min(dp[i][j], cost);
// // //                 }
// // //             }
// // //         }

// // //         return dp[1][n - 1];
// // //     }

// // //     public static void main(String[] args) {
// // //         int[] arr = {40, 20, 30, 10, 30}; // example dimensions
// // //         int n = arr.length;

// // //         // Recursive
// // //         System.out.println("Min cost (Recursive): " + mcmRec(arr, 1, n - 1));

// // //         // Memoized
// // //         int[][] dp = new int[n][n];
// // //         for (int[] row : dp) Arrays.fill(row, -1);
// // //         System.out.println("Min cost (Memoized): " + mcmMem(arr, 1, n - 1, dp));

// // //         // Tabulation
// // //         System.out.println("Min cost (Tabulation): " + mcmTab(arr));
// // //     }
// // // }
















// // //Minimum Partition Problem

// // public class Classroom {

// //     public static int minPartition(int[] arr) {
// //         int n = arr.length;
// //         int sum = 0;

// //         for (int num : arr) sum += num;

// //         int W = sum / 2; // maximum sum for subset1
// //         boolean[][] dp = new boolean[n + 1][W + 1];

// //         // Initialization
// //         for (int i = 0; i <= n; i++) dp[i][0] = true;

// //         // Bottom-up DP
// //         for (int i = 1; i <= n; i++) {
// //             for (int j = 1; j <= W; j++) {
// //                 if (arr[i - 1] <= j) {
// //                     dp[i][j] = dp[i - 1][j] || dp[i - 1][j - arr[i - 1]];
// //                 } else {
// //                     dp[i][j] = dp[i - 1][j];
// //                 }
// //             }
// //         }

// //         // Find the largest j such that dp[n][j] is true
// //         int subsetSum1 = 0;
// //         for (int j = W; j >= 0; j--) {
// //             if (dp[n][j]) {
// //                 subsetSum1 = j;
// //                 break;
// //             }
// //         }

// //         int subsetSum2 = sum - subsetSum1;
// //         return Math.abs(subsetSum2 - subsetSum1); // minimum difference
// //     }

// //     public static void main(String[] args) {
// //         int[] nums = {1, 6, 11, 5};
// //         System.out.println("Minimum difference: " + minPartition(nums));
// //     }
// // }







// // Min Array Jumps
// // int arro = 2, 3, 1, 1, 4
// // min jumps = 2
// //implementation for Minimum Jumps to Reach the End of an Array:
// import java.util.Arrays;

// public class Classroom {

//     // Function to find minimum jumps to reach the end
//     public static int minJumps(int[] nums) {
//         int n = nums.length;
//         int[] dp = new int[n];
//         Arrays.fill(dp, Integer.MAX_VALUE);

//         dp[n - 1] = 0; // Last position requires 0 jumps

//         // Fill dp array from second last to first
//         for (int i = n - 2; i >= 0; i--) {
//             int steps = nums[i];
//             int min = Integer.MAX_VALUE;

//             for (int j = i + 1; j <= i + steps && j < n; j++) {
//                 if (dp[j] != Integer.MAX_VALUE) {
//                     min = Math.min(min, dp[j]);
//                 }
//             }

//             if (min != Integer.MAX_VALUE) {
//                 dp[i] = 1 + min;
//             }
//         }

//         return dp[0]; // Minimum jumps from start
//     }

//     public static void main(String[] args) {
//         int[] nums = {2, 3, 1, 1, 4};
//         System.out.println("Minimum jumps: " + minJumps(nums));
//     }
// }
