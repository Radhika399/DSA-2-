// // //Segment Tree implementation
// // public class Classroom {
// //     static int[] tree;

// //     // Initialize segment tree
// //     public static void init(int n) {
// //         tree = new int[4 * n];
// //     }

// //     // Build segment tree
// //     public static int buildST(int[] arr, int i, int start, int end) {
// //         if (start == end) {
// //             tree[i] = arr[start];
// //             return tree[i];
// //         }
// //         int mid = (start + end) / 2;
// //         int left = buildST(arr, 2 * i + 1, start, mid);
// //         int right = buildST(arr, 2 * i + 2, mid + 1, end);
// //         tree[i] = left + right;
// //         return tree[i];
// //     }

// //     // Utility function to get sum in range [l, r]
// //     public static int getSumUtil(int i, int si, int sj, int qi, int qj) {
// //         if (qj < si || qi > sj) { // no overlap
// //             return 0;
// //         } else if (qi <= si && sj <= qj) { // complete overlap
// //             return tree[i];
// //         } else { // partial overlap
// //             int mid = (si + sj) / 2;
// //             int left = getSumUtil(2 * i + 1, si, mid, qi, qj);
// //             int right = getSumUtil(2 * i + 2, mid + 1, sj, qi, qj);
// //             return left + right;
// //         }
// //     }

// //     public static int getSum(int[] arr, int qi, int qj) {
// //         int n = arr.length;
// //         return getSumUtil(0, 0, n - 1, qi, qj);
// //     }

// //     // Utility function to update value at index idx
// //     public static void updateUtil(int i, int si, int sj, int idx, int diff) {
// //         if (idx < si || idx > sj) return;

// //         tree[i] += diff;

// //         if (si != sj) { // non-leaf node
// //             int mid = (si + sj) / 2;
// //             updateUtil(2 * i + 1, si, mid, idx, diff);
// //             updateUtil(2 * i + 2, mid + 1, sj, idx, diff);
// //         }
// //     }

// //     public static void update(int[] arr, int idx, int newVal) {
// //         int diff = newVal - arr[idx];
// //         arr[idx] = newVal;
// //         updateUtil(0, 0, arr.length - 1, idx, diff);
// //     }

// //     public static void main(String[] args) {
// //         int[] arr = {1, 2, 3, 4, 5, 6, 7, 8};
// //         int n = arr.length;

// //         init(n);
// //         buildST(arr, 0, 0, n - 1);

// //         System.out.print("Segment Tree: ");
// //         for (int val : tree) {
// //             System.out.print(val + " ");
// //         }
// //         System.out.println();

// //         System.out.println("Sum of range [2, 5]: " + getSum(arr, 2, 5));

// //         update(arr, 3, 10); // update arr[3] = 10
// //         System.out.println("After update arr[3] = 10, sum of range [2, 5]: " + getSum(arr, 2, 5));
// //     }
// // }







// // MaxiMin Element Queries
// // Given an arr[ l, we have to answer few queries :
// // a. Output MaxlMin for the subarray[i..jl
// // b. Update the element at idx
// // {6, 8, -1, 2, 17, 1, 3, 2, 4)


// //Max/Min queries on subarrays

// public class Classroom {
//     static int[] tree;
//     static boolean isMaxTree; // true for max segment tree, false for min segment tree

//     // Initialize segment tree
//     public static void init(int n, boolean maxTree) {
//         tree = new int[4 * n];
//         isMaxTree = maxTree;
//     }

//     // Build segment tree
//     public static void buildTree(int i, int si, int sj, int[] arr) {
//         if (si == sj) {
//             tree[i] = arr[si];
//             return;
//         }
//         int mid = (si + sj) / 2;
//         buildTree(2 * i + 1, si, mid, arr);
//         buildTree(2 * i + 2, mid + 1, sj, arr);
//         tree[i] = isMaxTree ? Math.max(tree[2 * i + 1], tree[2 * i + 2])
//                             : Math.min(tree[2 * i + 1], tree[2 * i + 2]);
//     }

//     // Query utility
//     public static int queryUtil(int i, int si, int sj, int qi, int qj) {
//         if (si > qj || sj < qi) { // no overlap
//             return isMaxTree ? Integer.MIN_VALUE : Integer.MAX_VALUE;
//         } else if (qi <= si && sj <= qj) { // complete overlap
//             return tree[i];
//         } else { // partial overlap
//             int mid = (si + sj) / 2;
//             int leftAns = queryUtil(2 * i + 1, si, mid, qi, qj);
//             int rightAns = queryUtil(2 * i + 2, mid + 1, sj, qi, qj);
//             return isMaxTree ? Math.max(leftAns, rightAns) : Math.min(leftAns, rightAns);
//         }
//     }

//     public static int query(int[] arr, int qi, int qj) {
//         return queryUtil(0, 0, arr.length - 1, qi, qj);
//     }

//     // Update utility
//     public static void updateUtil(int i, int si, int sj, int idx, int newVal) {
//         if (idx < si || idx > sj) return;

//         if (si == sj) { // leaf node
//             tree[i] = newVal;
//             return;
//         }

//         int mid = (si + sj) / 2;
//         updateUtil(2 * i + 1, si, mid, idx, newVal);
//         updateUtil(2 * i + 2, mid + 1, sj, idx, newVal);
//         tree[i] = isMaxTree ? Math.max(tree[2 * i + 1], tree[2 * i + 2])
//                             : Math.min(tree[2 * i + 1], tree[2 * i + 2]);
//     }

//     public static void update(int[] arr, int idx, int newVal) {
//         arr[idx] = newVal;
//         updateUtil(0, 0, arr.length - 1, idx, newVal);
//     }

//     public static void main(String[] args) {
//         int[] arr = {6, 8, -1, 2, 17, 1, 3, 2, 4};
//         int n = arr.length;

//         // Max segment tree
//         init(n, true);
//         buildTree(0, 0, n - 1, arr);
//         System.out.println("Max of range [2, 5]: " + query(arr, 2, 5));

//         // Update element
//         update(arr, 3, 10);
//         System.out.println("After update arr[3] = 10, Max of range [2, 5]: " + query(arr, 2, 5));

//         // Min segment tree
//         init(n, false);
//         buildTree(0, 0, n - 1, arr);
//         System.out.println("Min of range [2, 5]: " + query(arr, 2, 5));
//     }
// }











