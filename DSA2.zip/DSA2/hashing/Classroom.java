//package hashing;
// // // // // // // // // // // // // // // import java.util.*;

// // // // // // // // // // // // // // // public class Classroom {
// // // // // // // // // // // // // // //     public static void main(String[] args) {

// // // // // // // // // // // // // // //         // 1. Create a HashMap
// // // // // // // // // // // // // // //         HashMap<String, Integer> hm = new HashMap<>();

// // // // // // // // // // // // // // //         // 2. Insert elements (key-value pairs) — O(1)
// // // // // // // // // // // // // // //         hm.put("India", 100);
// // // // // // // // // // // // // // //         hm.put("China", 150);
// // // // // // // // // // // // // // //         hm.put("US", 50);

// // // // // // // // // // // // // // //         System.out.println("HashMap: " + hm);

// // // // // // // // // // // // // // //         // 3. Get value by key — O(1)
// // // // // // // // // // // // // // //         int populationIndia = hm.get("India");
// // // // // // // // // // // // // // //         System.out.println("Population of India: " + populationIndia);

// // // // // // // // // // // // // // //         // If key does not exist, get() returns null
// // // // // // // // // // // // // // //         System.out.println("Population of Indonesia: " + hm.get("Indonesia"));

// // // // // // // // // // // // // // //         // 4. Check if key exists — O(1)
// // // // // // // // // // // // // // //         System.out.println("Contains key 'India'? " + hm.containsKey("India"));       // true
// // // // // // // // // // // // // // //         System.out.println("Contains key 'Indonesia'? " + hm.containsKey("Indonesia")); // false

// // // // // // // // // // // // // // //         // 5. Remove a key-value pair — O(1)
// // // // // // // // // // // // // // //         System.out.println("Removing China: " + hm.remove("China"));

// // // // // // // // // // // // // // //         // 6. Iterate over keys
// // // // // // // // // // // // // // //         Set<String> keys = hm.keySet();
// // // // // // // // // // // // // // //         System.out.println("Keys in HashMap: " + keys);

// // // // // // // // // // // // // // //         for (String k : keys) {
// // // // // // // // // // // // // // //             System.out.println("Key: " + k + ", Value: " + hm.get(k));
// // // // // // // // // // // // // // //         }

// // // // // // // // // // // // // // //         // 7. Iterate over entries
// // // // // // // // // // // // // // //         System.out.println("Iterating over entry set:");
// // // // // // // // // // // // // // //         for (Map.Entry<String, Integer> entry : hm.entrySet()) {
// // // // // // // // // // // // // // //             System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
// // // // // // // // // // // // // // //         }
// // // // // // // // // // // // // // //     }
// // // // // // // // // // // // // // // }



// // // // // // // // // // // // // // import java.util.*;

// // // // // // // // // // // // // // public class HashMapCode<K, V> {

// // // // // // // // // // // // // //     // Node class to store key-value pairs
// // // // // // // // // // // // // //     private class Node {
// // // // // // // // // // // // // //         K key;
// // // // // // // // // // // // // //         V value;

// // // // // // // // // // // // // //         Node(K key, V value) {
// // // // // // // // // // // // // //             this.key = key;
// // // // // // // // // // // // // //             this.value = value;
// // // // // // // // // // // // // //         }
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     private int size; // total number of key-value pairs
// // // // // // // // // // // // // //     private LinkedList<Node>[] buckets; // array of buckets
// // // // // // // // // // // // // //     private static final int INITIAL_CAPACITY = 16;

// // // // // // // // // // // // // //     @SuppressWarnings("unchecked")
// // // // // // // // // // // // // //     public HashMapCode() {
// // // // // // // // // // // // // //         this.buckets = new LinkedList[INITIAL_CAPACITY];
// // // // // // // // // // // // // //         for (int i = 0; i < INITIAL_CAPACITY; i++) {
// // // // // // // // // // // // // //             buckets[i] = new LinkedList<>();
// // // // // // // // // // // // // //         }
// // // // // // // // // // // // // //         this.size = 0;
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     // Hash function to map key to bucket index
// // // // // // // // // // // // // //     private int getBucketIndex(K key) {
// // // // // // // // // // // // // //         return Math.abs(key.hashCode()) % buckets.length;
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     // Insert or update a key-value pair
// // // // // // // // // // // // // //     public void put(K key, V value) {
// // // // // // // // // // // // // //         int idx = getBucketIndex(key);
// // // // // // // // // // // // // //         LinkedList<Node> bucket = buckets[idx];

// // // // // // // // // // // // // //         // Check if key exists; if yes, update
// // // // // // // // // // // // // //         for (Node node : bucket) {
// // // // // // // // // // // // // //             if (node.key.equals(key)) {
// // // // // // // // // // // // // //                 node.value = value;
// // // // // // // // // // // // // //                 return;
// // // // // // // // // // // // // //             }
// // // // // // // // // // // // // //         }

// // // // // // // // // // // // // //         // Otherwise, insert new node
// // // // // // // // // // // // // //         bucket.add(new Node(key, value));
// // // // // // // // // // // // // //         size++;

// // // // // // // // // // // // // //         // Optional: resize if load factor exceeds threshold
// // // // // // // // // // // // // //         if (size >= buckets.length * 0.75) {
// // // // // // // // // // // // // //             resize();
// // // // // // // // // // // // // //         }
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     // Get value by key
// // // // // // // // // // // // // //     public V get(K key) {
// // // // // // // // // // // // // //         int idx = getBucketIndex(key);
// // // // // // // // // // // // // //         LinkedList<Node> bucket = buckets[idx];

// // // // // // // // // // // // // //         for (Node node : bucket) {
// // // // // // // // // // // // // //             if (node.key.equals(key)) {
// // // // // // // // // // // // // //                 return node.value;
// // // // // // // // // // // // // //             }
// // // // // // // // // // // // // //         }
// // // // // // // // // // // // // //         return null; // key not found
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     // Remove a key-value pair
// // // // // // // // // // // // // //     public V remove(K key) {
// // // // // // // // // // // // // //         int idx = getBucketIndex(key);
// // // // // // // // // // // // // //         LinkedList<Node> bucket = buckets[idx];

// // // // // // // // // // // // // //         Iterator<Node> it = bucket.iterator();
// // // // // // // // // // // // // //         while (it.hasNext()) {
// // // // // // // // // // // // // //             Node node = it.next();
// // // // // // // // // // // // // //             if (node.key.equals(key)) {
// // // // // // // // // // // // // //                 V val = node.value;
// // // // // // // // // // // // // //                 it.remove();
// // // // // // // // // // // // // //                 size--;
// // // // // // // // // // // // // //                 return val;
// // // // // // // // // // // // // //             }
// // // // // // // // // // // // // //         }
// // // // // // // // // // // // // //         return null; // key not found
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     // Check if a key exists
// // // // // // // // // // // // // //     public boolean containsKey(K key) {
// // // // // // // // // // // // // //         int idx = getBucketIndex(key);
// // // // // // // // // // // // // //         LinkedList<Node> bucket = buckets[idx];

// // // // // // // // // // // // // //         for (Node node : bucket) {
// // // // // // // // // // // // // //             if (node.key.equals(key)) {
// // // // // // // // // // // // // //                 return true;
// // // // // // // // // // // // // //             }
// // // // // // // // // // // // // //         }
// // // // // // // // // // // // // //         return false;
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     // Resize and rehash
// // // // // // // // // // // // // //     @SuppressWarnings("unchecked")
// // // // // // // // // // // // // //     private void resize() {
// // // // // // // // // // // // // //         LinkedList<Node>[] oldBuckets = buckets;
// // // // // // // // // // // // // //         buckets = new LinkedList[oldBuckets.length * 2];
// // // // // // // // // // // // // //         for (int i = 0; i < buckets.length; i++) {
// // // // // // // // // // // // // //             buckets[i] = new LinkedList<>();
// // // // // // // // // // // // // //         }

// // // // // // // // // // // // // //         size = 0;
// // // // // // // // // // // // // //         for (LinkedList<Node> bucket : oldBuckets) {
// // // // // // // // // // // // // //             for (Node node : bucket) {
// // // // // // // // // // // // // //                 put(node.key, node.value);
// // // // // // // // // // // // // //             }
// // // // // // // // // // // // // //         }
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     public int size() {
// // // // // // // // // // // // // //         return size;
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     // Demo
// // // // // // // // // // // // // //     public static void main(String[] args) {
// // // // // // // // // // // // // //         HashMapCode<String, Integer> map = new HashMapCode<>();
// // // // // // // // // // // // // //         map.put("India", 100);
// // // // // // // // // // // // // //         map.put("China", 150);
// // // // // // // // // // // // // //         map.put("US", 50);

// // // // // // // // // // // // // //         System.out.println("India: " + map.get("India"));       // 100
// // // // // // // // // // // // // //         System.out.println("Contains Indonesia? " + map.containsKey("Indonesia")); // false
// // // // // // // // // // // // // //         System.out.println("Remove China: " + map.remove("China")); // 150
// // // // // // // // // // // // // //         System.out.println("Contains China? " + map.containsKey("China")); // false
// // // // // // // // // // // // // //     }
// // // // // // // // // // // // // // }
















// // // // // // // // // // // // // //implement a custom HashMap with chaining

// // // // // // // // // // // // // import java.util.*;

// // // // // // // // // // // // // public class HashMapCode<K, V> {

// // // // // // // // // // // // //     private class Node {
// // // // // // // // // // // // //         K key;
// // // // // // // // // // // // //         V value;

// // // // // // // // // // // // //         Node(K key, V value) {
// // // // // // // // // // // // //             this.key = key;
// // // // // // // // // // // // //             this.value = value;
// // // // // // // // // // // // //         }
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     private int n; // total number of key-value pairs
// // // // // // // // // // // // //     private int N; // number of buckets
// // // // // // // // // // // // //     private LinkedList<Node>[] buckets;

// // // // // // // // // // // // //     @SuppressWarnings("unchecked")
// // // // // // // // // // // // //     public HashMapCode() {
// // // // // // // // // // // // //         this.N = 4; // initial bucket size
// // // // // // // // // // // // //         this.buckets = new LinkedList[N];
// // // // // // // // // // // // //         for (int i = 0; i < N; i++) {
// // // // // // // // // // // // //             buckets[i] = new LinkedList<>();
// // // // // // // // // // // // //         }
// // // // // // // // // // // // //         this.n = 0;
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     private int hashFunction(K key) {
// // // // // // // // // // // // //         return Math.abs(key.hashCode()) % N;
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     // Search in linked list of a bucket
// // // // // // // // // // // // //     private int searchInLL(K key, int bi) {
// // // // // // // // // // // // //         LinkedList<Node> ll = buckets[bi];
// // // // // // // // // // // // //         for (int i = 0; i < ll.size(); i++) {
// // // // // // // // // // // // //             if (ll.get(i).key.equals(key)) {
// // // // // // // // // // // // //                 return i;
// // // // // // // // // // // // //             }
// // // // // // // // // // // // //         }
// // // // // // // // // // // // //         return -1;
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     // Insert or update a key-value pair
// // // // // // // // // // // // //     public void put(K key, V value) {
// // // // // // // // // // // // //         int bi = hashFunction(key);
// // // // // // // // // // // // //         int di = searchInLL(key, bi);

// // // // // // // // // // // // //         if (di != -1) {
// // // // // // // // // // // // //             // Update existing node
// // // // // // // // // // // // //             Node node = buckets[bi].get(di);
// // // // // // // // // // // // //             node.value = value;
// // // // // // // // // // // // //         } else {
// // // // // // // // // // // // //             // Insert new node
// // // // // // // // // // // // //             buckets[bi].add(new Node(key, value));
// // // // // // // // // // // // //             n++;
// // // // // // // // // // // // //         }

// // // // // // // // // // // // //         double lambda = (double) n / N; // load factor
// // // // // // // // // // // // //         if (lambda > 2.0) {
// // // // // // // // // // // // //             rehash();
// // // // // // // // // // // // //         }
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     // Rehash when load factor exceeds threshold
// // // // // // // // // // // // //     @SuppressWarnings("unchecked")
// // // // // // // // // // // // //     private void rehash() {
// // // // // // // // // // // // //         LinkedList<Node>[] oldBuckets = buckets;
// // // // // // // // // // // // //         N = N * 2;
// // // // // // // // // // // // //         buckets = new LinkedList[N];
// // // // // // // // // // // // //         for (int i = 0; i < N; i++) {
// // // // // // // // // // // // //             buckets[i] = new LinkedList<>();
// // // // // // // // // // // // //         }
// // // // // // // // // // // // //         n = 0;

// // // // // // // // // // // // //         for (LinkedList<Node> ll : oldBuckets) {
// // // // // // // // // // // // //             for (Node node : ll) {
// // // // // // // // // // // // //                 put(node.key, node.value);
// // // // // // // // // // // // //             }
// // // // // // // // // // // // //         }
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     public boolean containsKey(K key) {
// // // // // // // // // // // // //         int bi = hashFunction(key);
// // // // // // // // // // // // //         int di = searchInLL(key, bi);
// // // // // // // // // // // // //         return di != -1;
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     public V remove(K key) {
// // // // // // // // // // // // //         int bi = hashFunction(key);
// // // // // // // // // // // // //         int di = searchInLL(key, bi);
// // // // // // // // // // // // //         if (di != -1) {
// // // // // // // // // // // // //             Node node = buckets[bi].remove(di);
// // // // // // // // // // // // //             n--;
// // // // // // // // // // // // //             return node.value;
// // // // // // // // // // // // //         }
// // // // // // // // // // // // //         return null;
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     public V get(K key) {
// // // // // // // // // // // // //         int bi = hashFunction(key);
// // // // // // // // // // // // //         int di = searchInLL(key, bi);
// // // // // // // // // // // // //         if (di != -1) {
// // // // // // // // // // // // //             return buckets[bi].get(di).value;
// // // // // // // // // // // // //         }
// // // // // // // // // // // // //         return null;
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     public ArrayList<K> keySet() {
// // // // // // // // // // // // //         ArrayList<K> keys = new ArrayList<>();
// // // // // // // // // // // // //         for (LinkedList<Node> ll : buckets) {
// // // // // // // // // // // // //             for (Node node : ll) {
// // // // // // // // // // // // //                 keys.add(node.key);
// // // // // // // // // // // // //             }
// // // // // // // // // // // // //         }
// // // // // // // // // // // // //         return keys;
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     public static void main(String[] args) {
// // // // // // // // // // // // //         HashMapCode<String, Integer> hm = new HashMapCode<>();

// // // // // // // // // // // // //         hm.put("India", 100);
// // // // // // // // // // // // //         hm.put("China", 150);
// // // // // // // // // // // // //         hm.put("US", 50);

// // // // // // // // // // // // //         System.out.println("India: " + hm.get("India")); // 100
// // // // // // // // // // // // //         System.out.println("Contains 'China'? " + hm.containsKey("China")); // true

// // // // // // // // // // // // //         hm.remove("China");
// // // // // // // // // // // // //         System.out.println("Contains 'China'? " + hm.containsKey("China")); // false

// // // // // // // // // // // // //         System.out.println("Keys: " + hm.keySet());
// // // // // // // // // // // // //     }
// // // // // // // // // // // // // }









// // // // // // // // // // // // import java.util.*;

// // // // // // // // // // // // public class Classroom {
// // // // // // // // // // // //     public static void main(String[] args) {

// // // // // // // // // // // //         // LinkedHashMap preserves insertion order
// // // // // // // // // // // //         LinkedHashMap<String, Integer> lhm = new LinkedHashMap<>();
// // // // // // // // // // // //         lhm.put("India", 10);
// // // // // // // // // // // //         lhm.put("China", 150);
// // // // // // // // // // // //         lhm.put("US", 50);
// // // // // // // // // // // //         System.out.println("LinkedHashMap: " + lhm); 
// // // // // // // // // // // //         // Output: {India=10, China=150, US=50}

// // // // // // // // // // // //         // HashMap does NOT preserve order
// // // // // // // // // // // //         HashMap<String, Integer> hm = new HashMap<>();
// // // // // // // // // // // //         hm.put("India", 100);
// // // // // // // // // // // //         hm.put("China", 150);
// // // // // // // // // // // //         hm.put("US", 50);
// // // // // // // // // // // //         System.out.println("HashMap: " + hm); 
// // // // // // // // // // // //         // Output order may vary

// // // // // // // // // // // //         // TreeMap sorts keys in natural order (alphabetical for String)
// // // // // // // // // // // //         TreeMap<String, Integer> tm = new TreeMap<>();
// // // // // // // // // // // //         tm.put("India", 100);
// // // // // // // // // // // //         tm.put("China", 150);
// // // // // // // // // // // //         tm.put("US", 50);
// // // // // // // // // // // //         System.out.println("TreeMap: " + tm); 
// // // // // // // // // // // //         // Output: {China=150, India=100, US=50}
// // // // // // // // // // // //     }
// // // // // // // // // // // // }






























// // // // // // // // // // // Majority Element
// // // // // // // // // // // Given an integer array of size n, find all elements that appear more than I n/3 ] times.
// // // // // // // // // // // nums[ (1, 3, 2, 5, 1, 3, 1, 5, 1);
// // // // // // // // // // // //1

// // // // // // // // // // // nums[ I = {1, 2);
// // // // // // // // // // //  1, 2



// // // // // // // // // // import java.util.*;

// // // // // // // // // // public class Classroom {
// // // // // // // // // //     public static void main(String[] args) {
// // // // // // // // // //         int arr[] = {1, 2, 3, 1, 1, 2, 1}; // Example array
// // // // // // // // // //         HashMap<Integer, Integer> map = new HashMap<>();

// // // // // // // // // //         // Count frequency of each element
// // // // // // // // // //         for (int i = 0; i < arr.length; i++) {
// // // // // // // // // //             map.put(arr[i], map.getOrDefault(arr[i], 0) + 1);
// // // // // // // // // //         }

// // // // // // // // // //         // Find elements appearing more than n/3 times
// // // // // // // // // //         int n = arr.length;
// // // // // // // // // //         System.out.println("Elements appearing more than n/3 times:");
// // // // // // // // // //         for (Integer key : map.keySet()) {
// // // // // // // // // //             if (map.get(key) > n / 3) {
// // // // // // // // // //                 System.out.print(key + " ");
// // // // // // // // // //             }
// // // // // // // // // //         }
// // // // // // // // // //     }
// // // // // // // // // // }






// // // // // // // // // // Valid Anagram
// // // // // // // // // // Given two strings s and t, return true if t is an anagram of s, and false otherwise.
// // // // // // // // // // An Anagram is a word or phrase formed by rearranging the letters of a different word or phrase,
// // // // // // // // // // typically using all the original letters exactly once.
// // // // // // // // // // s = "race"
// // // // // // // // // // s = "heart"
// // // // // // // // // // s = "tulip" t
// // // // // // // // // // = "lipid"
// // // // // // // // // // TRUE
// // // // // // // // // // TRUE
// // // // // // // // // // FALSE

// // // // // // // // // import java.util.*;

// // // // // // // // // public class Classroom {

// // // // // // // // //     public static boolean isAnagram(String s, String t) {
// // // // // // // // //         if (s.length() != t.length()) return false;

// // // // // // // // //         HashMap<Character, Integer> map = new HashMap<>();

// // // // // // // // //         // Count frequency of characters in s
// // // // // // // // //         for (int i = 0; i < s.length(); i++) {
// // // // // // // // //             char ch = s.charAt(i);
// // // // // // // // //             map.put(ch, map.getOrDefault(ch, 0) + 1);
// // // // // // // // //         }

// // // // // // // // //         // Subtract frequency using characters from t
// // // // // // // // //         for (int i = 0; i < t.length(); i++) {
// // // // // // // // //             char ch = t.charAt(i);
// // // // // // // // //             if (!map.containsKey(ch)) {
// // // // // // // // //                 return false; // Character not in s
// // // // // // // // //             }
// // // // // // // // //             map.put(ch, map.get(ch) - 1);
// // // // // // // // //             if (map.get(ch) == 0) {
// // // // // // // // //                 map.remove(ch); // Remove zero-count characters
// // // // // // // // //             }
// // // // // // // // //         }

// // // // // // // // //         // If map is empty, strings are anagrams
// // // // // // // // //         return map.isEmpty();
// // // // // // // // //     }

// // // // // // // // //     public static void main(String[] args) {
// // // // // // // // //         String s1 = "race", t1 = "care";
// // // // // // // // //         String s2 = "heart", t2 = "earth";
// // // // // // // // //         String s3 = "tulip", t3 = "lipid";

// // // // // // // // //         System.out.println(isAnagram(s1, t1)); // true
// // // // // // // // //         System.out.println(isAnagram(s2, t2)); // true
// // // // // // // // //         System.out.println(isAnagram(s3, t3)); // false
// // // // // // // // //     }
// // // // // // // // // }















// // // // // // // // import java.util.HashSet;

// // // // // // // // public class Classroom {
// // // // // // // //     public static void main(String[] args) {
// // // // // // // //         // Create a HashSet
// // // // // // // //         HashSet<Integer> set = new HashSet<>();

// // // // // // // //         // Add elements (duplicates will be ignored)
// // // // // // // //         set.add(1);
// // // // // // // //         set.add(2);
// // // // // // // //         set.add(4);
// // // // // // // //         set.add(2); // duplicate, ignored
// // // // // // // //         set.add(1); // duplicate, ignored

// // // // // // // //         // Print the set
// // // // // // // //         System.out.println("HashSet elements: " + set);

// // // // // // // //         // Check if an element exists
// // // // // // // //         if (set.contains(2)) {
// // // // // // // //             System.out.println("Set contains 2");
// // // // // // // //         }

// // // // // // // //         // Size of the set
// // // // // // // //         System.out.println("Size of set: " + set.size());
// // // // // // // //     }
// // // // // // // // }









// // // // // // // import java.util.*;

// // // // // // // public class Classroom {
// // // // // // //     public static void main(String[] args) {
// // // // // // //         // HashSet - no duplicates, unordered
// // // // // // //         HashSet<String> cities = new HashSet<>();
// // // // // // //         cities.add("Delhi");
// // // // // // //         cities.add("Mumbai");
// // // // // // //         cities.add("Noida");
// // // // // // //         cities.add("Bengaluru");

// // // // // // //         System.out.println("HashSet elements (unordered):");
// // // // // // //         // Using iterator
// // // // // // //         Iterator<String> it = cities.iterator();
// // // // // // //         while (it.hasNext()) {
// // // // // // //             System.out.println(it.next());
// // // // // // //         }

// // // // // // //         // Using for-each loop
// // // // // // //         System.out.println("\nHashSet elements (for-each):");
// // // // // // //         for (String city : cities) {
// // // // // // //             System.out.println(city);
// // // // // // //         }

// // // // // // //         // LinkedHashSet - maintains insertion order
// // // // // // //         LinkedHashSet<String> lhs = new LinkedHashSet<>();
// // // // // // //         lhs.add("Delhi");
// // // // // // //         lhs.add("Mumbai");
// // // // // // //         lhs.add("Noida");
// // // // // // //         lhs.add("Bengaluru");

// // // // // // //         System.out.println("\nLinkedHashSet elements (insertion order):");
// // // // // // //         for (String city : lhs) {
// // // // // // //             System.out.println(city);
// // // // // // //         }

// // // // // // //         // TreeSet - sorted order
// // // // // // //         TreeSet<String> ts = new TreeSet<>();
// // // // // // //         ts.add("Delhi");
// // // // // // //         ts.add("Mumbai");
// // // // // // //         ts.add("Noida");
// // // // // // //         ts.add("Bengaluru");

// // // // // // //         System.out.println("\nTreeSet elements (sorted):");
// // // // // // //         for (String city : ts) {
// // // // // // //             System.out.println(city);
// // // // // // //         }
// // // // // // //     }
// // // // // // // }


















// // // // // // import java.util.HashSet;

// // // // // // public class Classroom {
// // // // // //     public static void main(String[] args) {
// // // // // //         int[] num = {1, 2, 3, 2, 4, 1, 5};

// // // // // //         // Create a HashSet to store unique elements
// // // // // //         HashSet<Integer> set = new HashSet<>();

// // // // // //         // Add all elements to the set (duplicates will be ignored)
// // // // // //         for (int i = 0; i < num.length; i++) {
// // // // // //             set.add(num[i]);
// // // // // //         }

// // // // // //         // Print the number of unique elements
// // // // // //         System.out.println("Number of unique elements: " + set.size());
// // // // // //     }
// // // // // // }





















// // // // // Union & Intersection of 2 arrays
// // // // // arrl {7, 3, 9)
// // // // // arr2 = (6, 3, 9, 2, 9, 4)
// // // // // union 6 (7, 3, 9, 6, 2, 4)
// // // // // intersection : 2 (3, 9)


// // // // import java.util.HashSet;

// // // // public class Classroom {
// // // //     public static void main(String[] args) {
// // // //         int arr1[] = {7, 3, 9};
// // // //         int arr2[] = {6, 3, 9, 2, 9, 4};

// // // //         // Union
// // // //         HashSet<Integer> set = new HashSet<>();
// // // //         for (int i = 0; i < arr1.length; i++) {
// // // //             set.add(arr1[i]);
// // // //         }
// // // //         for (int i = 0; i < arr2.length; i++) {
// // // //             set.add(arr2[i]);
// // // //         }

// // // //         System.out.println("Union: " + set);

// // // //         // Intersection
// // // //         set.clear();
// // // //         for (int i = 0; i < arr1.length; i++) {
// // // //             set.add(arr1[i]);
// // // //         }

// // // //         HashSet<Integer> intersection = new HashSet<>();
// // // //         for (int i = 0; i < arr2.length; i++) {
// // // //             if (set.contains(arr2[i])) {
// // // //                 intersection.add(arr2[i]);
// // // //             }
// // // //         }

// // // //         System.out.println("Intersection: " + intersection);
// // // //     }
// // // // }




// // // // Find Itinerary from Tickets
// // // // "Chennai" -> "Bengaluru"
// // // // "Mumbai" -> "Delhi"
// // // // "Goa "Chennai"
// // // // "Delhi" -> "Goa"
// // // // "Mumbai" -> "Delhi" "
// // // // Goa" -> "Chennai" -> "Benagluru"



// // // import java.util.HashMap;

// // // public class Classroom {

// // //     // Function to find the starting city
// // //     public static String getStart(HashMap<String, String> tickets) {
// // //         HashMap<String, String> revMap = new HashMap<>();
// // //         for (String key : tickets.keySet()) {
// // //             revMap.put(tickets.get(key), key);
// // //         }

// // //         // The starting city is not present as a destination in revMap
// // //         for (String key : tickets.keySet()) {
// // //             if (!revMap.containsKey(key)) {
// // //                 return key;
// // //             }
// // //         }
// // //         return null; // If no start found
// // //     }

// // //     public static void main(String[] args) {
// // //         HashMap<String, String> tickets = new HashMap<>();
// // //         tickets.put("Chennai", "Bengaluru");
// // //         tickets.put("Mumbai", "Delhi");
// // //         tickets.put("Goa", "Chennai");
// // //         tickets.put("Delhi", "Goa");

// // //         String start = getStart(tickets);
// // //         System.out.println("Travel starts from: " + start);

// // //         // Print the full itinerary
// // //         while (tickets.containsKey(start)) {
// // //             String next = tickets.get(start);
// // //             System.out.println(start + " -> " + next);
// // //             start = next;
// // //         }
// // //     }
// // // }











// // // Largest subarray with 0 sum
// // //arr (15, -2, 2, -8, 1, 7, 10, 23)
// // // ans=5
// // // arr : {3, 4, 5)
// // // ans = O

// // import java.util.HashMap;

// // public class Classroom {

// //     public static void main(String[] args) {
// //         int arr[] = {15, -2, 2, -8, 1, 7, 10, 23};
// //         int maxLen = 0;
// //         int sum = 0;

// //         // Map to store (prefix sum, first index)
// //         HashMap<Integer, Integer> map = new HashMap<>();

// //         for (int i = 0; i < arr.length; i++) {
// //             sum += arr[i];

// //             if (sum == 0) {
// //                 maxLen = i + 1; // Subarray from index 0
// //             }

// //             if (map.containsKey(sum)) {
// //                 // Subarray between previous index + 1 to current index has sum 0
// //                 maxLen = Math.max(maxLen, i - map.get(sum));
// //             } else {
// //                 map.put(sum, i); // Store first occurrence of this sum
// //             }
// //         }

// //         System.out.println("Length of the largest subarray with 0 sum: " + maxLen);
// //     }
// // }



// // Subarray sum equal to K
// // arr (1, 2, 3)
// // ans=2 (1, 2) (3)
// // return number of such subarrays

// import java.util.HashMap;

// public class Classroom {

//     public static void main(String[] args) {
//         int arr[] = {10, 2, -2, -20, 10};
//         int k = -10;

//         int sum = 0;           // Prefix sum
//         int count = 0;         // Number of subarrays
//         HashMap<Integer, Integer> map = new HashMap<>();
//         map.put(0, 1);         // To handle subarray starting from index 0

//         for (int i = 0; i < arr.length; i++) {
//             sum += arr[i];

//             // If (sum - k) exists, there is a subarray ending at i with sum k
//             if (map.containsKey(sum - k)) {
//                 count += map.get(sum - k);
//             }

//             // Store/update the count of prefix sum
//             map.put(sum, map.getOrDefault(sum, 0) + 1);
//         }

//         System.out.println("Number of subarrays with sum " + k + ": " + count);
//     }
// }



