// // // // // import java.util.*;

// // // // //         1
// // // // //       /   \
// // // // //      2     3
// // // // //     / \   /
// // // // //    4   5 6

// // // // // public class BinaryTreesB {

// // // // //     // Node class
// // // // //     static class Node {
// // // // //         int data;
// // // // //         Node left, right;

// // // // //         Node(int data) {
// // // // //             this.data = data;
// // // // //             this.left = null;
// // // // //             this.right = null;
// // // // //         }
// // // // //     }

// // // // //     // BinaryTree class with static index for building tree
// // // // //     static class BinaryTree {
// // // // //         static int idx = -1;

// // // // //         public static Node buildTree(int[] nodes) {
// // // // //             idx++;
// // // // //             if (idx >= nodes.length || nodes[idx] == -1) {
// // // // //                 return null;
// // // // //             }
// // // // //             Node newNode = new Node(nodes[idx]);
// // // // //             newNode.left = buildTree(nodes);
// // // // //             newNode.right = buildTree(nodes);
// // // // //             return newNode;
// // // // //         }
// // // // //     }

// // // // //     // Preorder traversal
// // // // //     public static void preorder(Node root) {
// // // // //         if (root == null) return;
// // // // //         System.out.print(root.data + " ");
// // // // //         preorder(root.left);
// // // // //         preorder(root.right);
// // // // //     }

// // // // //     // Inorder traversal
// // // // //     public static void inorder(Node root) {
// // // // //         if (root == null) return;
// // // // //         inorder(root.left);
// // // // //         System.out.print(root.data + " ");
// // // // //         inorder(root.right);
// // // // //     }

// // // // //     // Postorder traversal
// // // // //     public static void postorder(Node root) {
// // // // //         if (root == null) return;
// // // // //         postorder(root.left);
// // // // //         postorder(root.right);
// // // // //         System.out.print(root.data + " ");
// // // // //     }

// // // // //     // Level Order Traversal
// // // // //     public static void levelOrder(Node root) {
// // // // //         if (root == null) return;
// // // // //         Queue<Node> q = new LinkedList<>();
// // // // //         q.add(root);
// // // // //         while (!q.isEmpty()) {
// // // // //             Node curr = q.poll();
// // // // //             System.out.print(curr.data + " ");
// // // // //             if (curr.left != null) q.add(curr.left);
// // // // //             if (curr.right != null) q.add(curr.right);
// // // // //         }
// // // // //     }

// // // // //     // Height of tree
// // // // //     public static int height(Node root) {
// // // // //         if (root == null) return 0;
// // // // //         int lh = height(root.left);
// // // // //         int rh = height(root.right);
// // // // //         return Math.max(lh, rh) + 1;
// // // // //     }

// // // // //     // Count of nodes
// // // // //     public static int count(Node root) {
// // // // //         if (root == null) return 0;
// // // // //         return count(root.left) + count(root.right) + 1;
// // // // //     }

// // // // //     // Sum of nodes
// // // // //     public static int sum(Node root) {
// // // // //         if (root == null) return 0;
// // // // //         return sum(root.left) + sum(root.right) + root.data;
// // // // //     }

// // // // //     // Main method
// // // // //     public static void main(String[] args) {
// // // // //         // Example tree using -1 as null marker
// // // // //         int[] nodes = {1, 2, 4, -1, -1, 5, -1, -1, 3, 6, -1, -1, -1};

// // // // //         BinaryTree tree = new BinaryTree();
// // // // //         Node root = tree.buildTree(nodes);

// // // // //         System.out.print("Preorder: ");
// // // // //         preorder(root);
// // // // //         System.out.println();

// // // // //         System.out.print("Inorder: ");
// // // // //         inorder(root);
// // // // //         System.out.println();

// // // // //         System.out.print("Postorder: ");
// // // // //         postorder(root);
// // // // //         System.out.println();

// // // // //         System.out.print("Level Order: ");
// // // // //         levelOrder(root);
// // // // //         System.out.println();

// // // // //         System.out.println("Height of tree: " + height(root));
// // // // //         System.out.println("Total nodes: " + count(root));
// // // // //         System.out.println("Sum of all nodes: " + sum(root));
// // // // //     }
// // // // // }
  

















// // // //         1
// // // //       /   \
// // // //      2     3
// // // //     / \   / \
// // // //    4   5 6   7


// // // //      2
// // // //     / \
// // // //    4   5

// // // // public class BinaryTreeProblems {

// // // //     // Node class
// // // //     static class Node {
// // // //         int data;
// // // //         Node left, right;

// // // //         Node(int data) {
// // // //             this.data = data;
// // // //             left = right = null;
// // // //         }
// // // //     }

// // // //     // ------------------- Diameter -------------------

// // // //     // Naive approach: O(n^2)
// // // //     public static int height(Node root) {
// // // //         if (root == null) return 0;
// // // //         return Math.max(height(root.left), height(root.right)) + 1;
// // // //     }

// // // //     public static int diameterNaive(Node root) {
// // // //         if (root == null) return 0;
// // // //         int leftDiam = diameterNaive(root.left);
// // // //         int rightDiam = diameterNaive(root.right);
// // // //         int selfDiam = height(root.left) + height(root.right) + 1;
// // // //         return Math.max(selfDiam, Math.max(leftDiam, rightDiam));
// // // //     }

// // // //     // Optimized approach using helper class
// // // //     static class Info {
// // // //         int ht;
// // // //         int diam;
// // // //         Info(int ht, int diam) {
// // // //             this.ht = ht;
// // // //             this.diam = diam;
// // // //         }
// // // //     }

// // // //     public static Info diameterOptimized(Node root) {
// // // //         if (root == null) return new Info(0, 0);
// // // //         Info leftInfo = diameterOptimized(root.left);
// // // //         Info rightInfo = diameterOptimized(root.right);

// // // //         int height = Math.max(leftInfo.ht, rightInfo.ht) + 1;
// // // //         int diam = Math.max(Math.max(leftInfo.diam, rightInfo.diam),
// // // //                             leftInfo.ht + rightInfo.ht + 1);
// // // //         return new Info(height, diam);
// // // //     }

// // // //     // ------------------- Subtree Check -------------------

// // // //     public static boolean isIdentical(Node a, Node b) {
// // // //         if (a == null && b == null) return true;
// // // //         if (a == null || b == null) return false;
// // // //         return (a.data == b.data) &&
// // // //                isIdentical(a.left, b.left) &&
// // // //                isIdentical(a.right, b.right);
// // // //     }

// // // //     public static boolean isSubtree(Node root, Node subRoot) {
// // // //         if (root == null) return false;
// // // //         if (isIdentical(root, subRoot)) return true;
// // // //         return isSubtree(root.left, subRoot) || isSubtree(root.right, subRoot);
// // // //     }

// // // //     // ------------------- Main -------------------
// // // //     public static void main(String[] args) {

// // // //         // Build main tree
// // // //         Node root = new Node(1);
// // // //         root.left = new Node(2);
// // // //         root.right = new Node(3);
// // // //         root.left.left = new Node(4);
// // // //         root.left.right = new Node(5);
// // // //         root.right.left = new Node(6);
// // // //         root.right.right = new Node(7);

// // // //         // Diameter
// // // //         System.out.println("Diameter (naive) = " + diameterNaive(root));
// // // //         System.out.println("Diameter (optimized) = " + diameterOptimized(root).diam);

// // // //         // Build subtree
// // // //         Node subRoot = new Node(2);
// // // //         subRoot.left = new Node(4);
// // // //         subRoot.right = new Node(5);

// // // //         // Subtree check
// // // //         System.out.println("Is subtree? " + isSubtree(root, subRoot));
// // // //     }
// // // // }










// // //         1
// // //       /   \
// // //      2     3
// // //     / \   / \
// // //    4   5 6   7



// // //    4 2 1 3 7


// // //    import java.util.*;

// // // public class BinaryTreeTopView {

// // //     // Node class
// // //     static class Node {
// // //         int data;
// // //         Node left, right;
// // //         Node(int data) {
// // //             this.data = data;
// // //             left = right = null;
// // //         }
// // //     }

// // //     // Helper class to store node with horizontal distance
// // //     static class Info {
// // //         Node node;
// // //         int hd; // horizontal distance
// // //         Info(Node node, int hd) {
// // //             this.node = node;
// // //             this.hd = hd;
// // //         }
// // //     }

// // //     // Top View method
// // //     public static void topView(Node root) {
// // //         if (root == null) return;

// // //         Queue<Info> q = new LinkedList<>();
// // //         Map<Integer, Integer> map = new TreeMap<>(); // hd -> node.data

// // //         q.add(new Info(root, 0));

// // //         while (!q.isEmpty()) {
// // //             Info curr = q.poll();
// // //             // If horizontal distance is not yet in map, add it
// // //             map.putIfAbsent(curr.hd, curr.node.data);

// // //             if (curr.node.left != null) q.add(new Info(curr.node.left, curr.hd - 1));
// // //             if (curr.node.right != null) q.add(new Info(curr.node.right, curr.hd + 1));
// // //         }

// // //         // Print top view
// // //         for (int key : map.keySet()) {
// // //             System.out.print(map.get(key) + " ");
// // //         }
// // //         System.out.println();
// // //     }

// // //     // Main method
// // //     public static void main(String[] args) {
// // //         // Build tree
// // //         Node root = new Node(1);
// // //         root.left = new Node(2);
// // //         root.right = new Node(3);
// // //         root.left.left = new Node(4);
// // //         root.left.right = new Node(5);
// // //         root.right.left = new Node(6);
// // //         root.right.right = new Node(7);

// // //         System.out.print("Top View: ");
// // //         topView(root);
// // //     }
// // // }



// //         1
// //       /   \
// //      2     3
// //     / \   / \
// //    4   5 6   7

// // K = 3 → Nodes at level 3: 4 5 6 7

// // LCA of 4 and 5 → Node 2

// // import java.util.*;

// // public class BinaryTreeKLevelLCA {

// //     // Node class
// //     static class Node {
// //         int data;
// //         Node left, right;

// //         Node(int data) {
// //             this.data = data;
// //             left = right = null;
// //         }
// //     }

// //     // ------------------- Kth Level Nodes -------------------
// //     public static void printKLevel(Node root, int level, int k) {
// //         if (root == null) return;
// //         if (level == k) {
// //             System.out.print(root.data + " ");
// //             return;
// //         }
// //         printKLevel(root.left, level + 1, k);
// //         printKLevel(root.right, level + 1, k);
// //     }

// //     // ------------------- Lowest Common Ancestor -------------------
// //     // Helper to get path from root to given node
// //     public static boolean getPath(Node root, int n, ArrayList<Node> path) {
// //         if (root == null) return false;
// //         path.add(root);
// //         if (root.data == n) return true;
// //         if (getPath(root.left, n, path) || getPath(root.right, n, path)) return true;
// //         path.remove(path.size() - 1);
// //         return false;
// //     }

// //     public static Node LCA(Node root, int n1, int n2) {
// //         ArrayList<Node> path1 = new ArrayList<>();
// //         ArrayList<Node> path2 = new ArrayList<>();
// //         getPath(root, n1, path1);
// //         getPath(root, n2, path2);

// //         int i = 0;
// //         for (; i < path1.size() && i < path2.size(); i++) {
// //             if (path1.get(i) != path2.get(i)) break;
// //         }
// //         return path1.get(i - 1); // Last common node
// //     }

// //     // ------------------- Main -------------------
// //     public static void main(String[] args) {
// //         // Build tree
// //         Node root = new Node(1);
// //         root.left = new Node(2);
// //         root.right = new Node(3);
// //         root.left.left = new Node(4);
// //         root.left.right = new Node(5);
// //         root.right.left = new Node(6);
// //         root.right.right = new Node(7);

// //         // Kth level nodes
// //         int k = 3;
// //         System.out.print("Nodes at level " + k + ": ");
// //         printKLevel(root, 1, k);
// //         System.out.println();

// //         // LCA of two nodes
// //         int n1 = 4, n2 = 5;
// //         Node lca = LCA(root, n1, n2);
// //         System.out.println("LCA of " + n1 + " and " + n2 + " is: " + lca.data);
// //     }
// // }


//         1
//       /   \
//      2     3
//     / \   / \
//    4   5 6   7


//    import java.util.*;

// public class BinaryTreeAdvanced {

//     // Node class
//     static class Node {
//         int data;
//         Node left, right;

//         Node(int data) {
//             this.data = data;
//             left = right = null;
//         }
//     }

//     // ------------------- Optimized LCA -------------------
//     public static Node LCA2(Node root, int n1, int n2) {
//         if (root == null) return null;
//         if (root.data == n1 || root.data == n2) return root;

//         Node leftLCA = LCA2(root.left, n1, n2);
//         Node rightLCA = LCA2(root.right, n1, n2);

//         if (leftLCA != null && rightLCA != null) return root;
//         return (leftLCA != null) ? leftLCA : rightLCA;
//     }

//     // ------------------- Distance from root to a node -------------------
//     public static int LcaDist(Node root, int n) {
//         if (root == null) return -1;
//         if (root.data == n) return 0;

//         int leftDist = LcaDist(root.left, n);
//         if (leftDist != -1) return leftDist + 1;

//         int rightDist = LcaDist(root.right, n);
//         if (rightDist != -1) return rightDist + 1;

//         return -1;
//     }

//     // Distance between two nodes
//     public static int minDist(Node root, int n1, int n2) {
//         Node lca = LCA2(root, n1, n2);
//         return LcaDist(lca, n1) + LcaDist(lca, n2);
//     }

//     // ------------------- Kth Ancestor -------------------
//     static int KAncestorUtil(Node root, int n, int k) {
//         if (root == null) return -1;
//         if (root.data == n) return 0;

//         int leftDist = KAncestorUtil(root.left, n, k);
//         int rightDist = KAncestorUtil(root.right, n, k);

//         int max = Math.max(leftDist, rightDist);
//         if (max != -1) {
//             if (max + 1 == k) {
//                 System.out.println("Kth ancestor of " + n + " is: " + root.data);
//             }
//             return max + 1;
//         }
//         return -1;
//     }

//     public static void KAncestor(Node root, int n, int k) {
//         KAncestorUtil(root, n, k);
//     }

//     // ------------------- Transform Tree (Node = sum of children) -------------------
//     public static int transform(Node root) {
//         if (root == null) return 0;

//         int leftChild = transform(root.left);
//         int rightChild = transform(root.right);

//         int oldData = root.data;
//         int leftData = (root.left != null) ? root.left.data : 0;
//         int rightData = (root.right != null) ? root.right.data : 0;

//         root.data = leftData + leftChild + rightData + rightChild;
//         return oldData;
//     }

//     // ------------------- Main -------------------
//     public static void main(String[] args) {
//         Node root = new Node(1);
//         root.left = new Node(2);
//         root.right = new Node(3);
//         root.left.left = new Node(4);
//         root.left.right = new Node(5);
//         root.right.left = new Node(6);
//         root.right.right = new Node(7);

//         // LCA2
//         int n1 = 4, n2 = 5;
//         Node lca = LCA2(root, n1, n2);
//         System.out.println("LCA of " + n1 + " and " + n2 + " is: " + lca.data);

//         // Distance between two nodes
//         System.out.println("Distance between " + n1 + " and " + n2 + ": " + minDist(root, n1, n2));

//         // Kth ancestor
//         int node = 5, k = 2;
//         KAncestor(root, node, k);

//         // Transform tree
//         transform(root);
//         System.out.println("Tree transformed to sum of children. Root data = " + root.data);
//     }
// }

