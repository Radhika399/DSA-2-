//package Graph;
// // // // // // // // // // // // // // // // import java.util.ArrayList;

// // // // // // // // // // // // // // // // public class Classroom {

// // // // // // // // // // // // // // // //     // Edge class representing a connection between two vertices
// // // // // // // // // // // // // // // //     static class Edge {
// // // // // // // // // // // // // // // //         int src;
// // // // // // // // // // // // // // // //         int dest;
// // // // // // // // // // // // // // // //         int wt;

// // // // // // // // // // // // // // // //         public Edge(int s, int d, int w) {
// // // // // // // // // // // // // // // //             this.src = s;
// // // // // // // // // // // // // // // //             this.dest = d;
// // // // // // // // // // // // // // // //             this.wt = w;
// // // // // // // // // // // // // // // //         }
// // // // // // // // // // // // // // // //     }

// // // // // // // // // // // // // // // //     public static void main(String[] args) {
// // // // // // // // // // // // // // // //         int V = 5; // Number of vertices

// // // // // // // // // // // // // // // //         // Create an array of ArrayLists to represent the adjacency list
// // // // // // // // // // // // // // // //         ArrayList<Edge>[] graph = new ArrayList[V];

// // // // // // // // // // // // // // // //         // Initialize each vertex's adjacency list
// // // // // // // // // // // // // // // //         for (int i = 0; i < V; i++) {
// // // // // // // // // // // // // // // //             graph[i] = new ArrayList<>();
// // // // // // // // // // // // // // // //         }

// // // // // // // // // // // // // // // //         // Add edges to the graph
// // // // // // // // // // // // // // // //         // Vertex 0
// // // // // // // // // // // // // // // //         graph[0].add(new Edge(0, 1, 2));
// // // // // // // // // // // // // // // //         graph[0].add(new Edge(0, 2, 4));

// // // // // // // // // // // // // // // //         // Vertex 1
// // // // // // // // // // // // // // // //         graph[1].add(new Edge(1, 2, 1));
// // // // // // // // // // // // // // // //         graph[1].add(new Edge(1, 3, 7));

// // // // // // // // // // // // // // // //         // Vertex 2
// // // // // // // // // // // // // // // //         graph[2].add(new Edge(2, 3, 3));
// // // // // // // // // // // // // // // //         graph[2].add(new Edge(2, 4, 1));

// // // // // // // // // // // // // // // //         // Vertex 3
// // // // // // // // // // // // // // // //         graph[3].add(new Edge(3, 4, 5));

// // // // // // // // // // // // // // // //         // Vertex 4
// // // // // // // // // // // // // // // //         graph[4].add(new Edge(4, 0, 2));

// // // // // // // // // // // // // // // //         // Print the graph
// // // // // // // // // // // // // // // //         for (int i = 0; i < V; i++) {
// // // // // // // // // // // // // // // //             System.out.print("Vertex " + i + " is connected to: ");
// // // // // // // // // // // // // // // //             for (Edge e : graph[i]) {
// // // // // // // // // // // // // // // //                 System.out.print("(" + e.dest + ", wt=" + e.wt + ") ");
// // // // // // // // // // // // // // // //             }
// // // // // // // // // // // // // // // //             System.out.println();
// // // // // // // // // // // // // // // //         }
// // // // // // // // // // // // // // // //     }
// // // // // // // // // // // // // // // // }











// // // // // // // // // // // // // // // import java.util.*;

// // // // // // // // // // // // // // // public class Classroom {

// // // // // // // // // // // // // // //     // Edge class representing a connection between two vertices
// // // // // // // // // // // // // // //     static class Edge {
// // // // // // // // // // // // // // //         int src;
// // // // // // // // // // // // // // //         int dest;
// // // // // // // // // // // // // // //         int wt;

// // // // // // // // // // // // // // //         public Edge(int s, int d, int w) {
// // // // // // // // // // // // // // //             this.src = s;
// // // // // // // // // // // // // // //             this.dest = d;
// // // // // // // // // // // // // // //             this.wt = w;
// // // // // // // // // // // // // // //         }
// // // // // // // // // // // // // // //     }

// // // // // // // // // // // // // // //     // Create a sample graph
// // // // // // // // // // // // // // //     static void createGraph(ArrayList<Edge>[] graph) {
// // // // // // // // // // // // // // //         for (int i = 0; i < graph.length; i++) {
// // // // // // // // // // // // // // //             graph[i] = new ArrayList<>();
// // // // // // // // // // // // // // //         }

// // // // // // // // // // // // // // //         // Adding edges
// // // // // // // // // // // // // // //         graph[0].add(new Edge(0, 1, 2));
// // // // // // // // // // // // // // //         graph[0].add(new Edge(0, 2, 4));

// // // // // // // // // // // // // // //         graph[1].add(new Edge(1, 0, 2));
// // // // // // // // // // // // // // //         graph[1].add(new Edge(1, 3, 1));

// // // // // // // // // // // // // // //         graph[2].add(new Edge(2, 0, 4));
// // // // // // // // // // // // // // //         graph[2].add(new Edge(2, 4, 1));

// // // // // // // // // // // // // // //         graph[3].add(new Edge(3, 1, 1));
// // // // // // // // // // // // // // //         graph[3].add(new Edge(3, 4, 3));
// // // // // // // // // // // // // // //         graph[3].add(new Edge(3, 5, 2));

// // // // // // // // // // // // // // //         graph[4].add(new Edge(4, 2, 1));
// // // // // // // // // // // // // // //         graph[4].add(new Edge(4, 3, 3));
// // // // // // // // // // // // // // //         graph[4].add(new Edge(4, 5, 1));

// // // // // // // // // // // // // // //         graph[5].add(new Edge(5, 3, 2));
// // // // // // // // // // // // // // //         graph[5].add(new Edge(5, 4, 1));
// // // // // // // // // // // // // // //         graph[5].add(new Edge(5, 6, 4));

// // // // // // // // // // // // // // //         graph[6].add(new Edge(6, 5, 4));
// // // // // // // // // // // // // // //     }

// // // // // // // // // // // // // // //     // BFS traversal from source 0
// // // // // // // // // // // // // // //     public static void bfs(ArrayList<Edge>[] graph) {
// // // // // // // // // // // // // // //         Queue<Integer> q = new LinkedList<>();
// // // // // // // // // // // // // // //         boolean vis[] = new boolean[graph.length];

// // // // // // // // // // // // // // //         q.add(0); // start from vertex 0
// // // // // // // // // // // // // // //         while (!q.isEmpty()) {
// // // // // // // // // // // // // // //             int curr = q.remove();
// // // // // // // // // // // // // // //             if (!vis[curr]) {
// // // // // // // // // // // // // // //                 System.out.print(curr + " ");
// // // // // // // // // // // // // // //                 vis[curr] = true;

// // // // // // // // // // // // // // //                 for (Edge e : graph[curr]) {
// // // // // // // // // // // // // // //                     if (!vis[e.dest]) {
// // // // // // // // // // // // // // //                         q.add(e.dest);
// // // // // // // // // // // // // // //                     }
// // // // // // // // // // // // // // //                 }
// // // // // // // // // // // // // // //             }
// // // // // // // // // // // // // // //         }
// // // // // // // // // // // // // // //         System.out.println();
// // // // // // // // // // // // // // //     }

// // // // // // // // // // // // // // //     // DFS traversal
// // // // // // // // // // // // // // //     public static void dfs(ArrayList<Edge>[] graph, int curr, boolean vis[]) {
// // // // // // // // // // // // // // //         System.out.print(curr + " ");
// // // // // // // // // // // // // // //         vis[curr] = true;

// // // // // // // // // // // // // // //         for (Edge e : graph[curr]) {
// // // // // // // // // // // // // // //             if (!vis[e.dest]) {
// // // // // // // // // // // // // // //                 dfs(graph, e.dest, vis);
// // // // // // // // // // // // // // //             }
// // // // // // // // // // // // // // //         }
// // // // // // // // // // // // // // //     }

// // // // // // // // // // // // // // //     // Check if path exists between src and dest
// // // // // // // // // // // // // // //     public static boolean hasPath(ArrayList<Edge>[] graph, int src, int dest, boolean vis[]) {
// // // // // // // // // // // // // // //         if (src == dest) return true;

// // // // // // // // // // // // // // //         vis[src] = true;

// // // // // // // // // // // // // // //         for (Edge e : graph[src]) {
// // // // // // // // // // // // // // //             if (!vis[e.dest]) {
// // // // // // // // // // // // // // //                 if (hasPath(graph, e.dest, dest, vis)) return true;
// // // // // // // // // // // // // // //             }
// // // // // // // // // // // // // // //         }

// // // // // // // // // // // // // // //         return false;
// // // // // // // // // // // // // // //     }

// // // // // // // // // // // // // // //     public static void main(String[] args) {
// // // // // // // // // // // // // // //         int V = 7; // Number of vertices
// // // // // // // // // // // // // // //         ArrayList<Edge>[] graph = new ArrayList[V];

// // // // // // // // // // // // // // //         createGraph(graph);

// // // // // // // // // // // // // // //         System.out.println("BFS traversal:");
// // // // // // // // // // // // // // //         bfs(graph);

// // // // // // // // // // // // // // //         System.out.println("DFS traversal:");
// // // // // // // // // // // // // // //         boolean vis[] = new boolean[V];
// // // // // // // // // // // // // // //         dfs(graph, 0, vis);
// // // // // // // // // // // // // // //         System.out.println();

// // // // // // // // // // // // // // //         System.out.println("Check if path exists between 0 and 6:");
// // // // // // // // // // // // // // //         boolean visited[] = new boolean[V];
// // // // // // // // // // // // // // //         System.out.println(hasPath(graph, 0, 6, visited));
// // // // // // // // // // // // // // //     }
// // // // // // // // // // // // // // // }
















// // // // // // // // // // // // // // import java.util.*;

// // // // // // // // // // // // // // public class Classroom {

// // // // // // // // // // // // // //     // Edge class
// // // // // // // // // // // // // //     static class Edge {
// // // // // // // // // // // // // //         int src;
// // // // // // // // // // // // // //         int dest;
// // // // // // // // // // // // // //         int wt;

// // // // // // // // // // // // // //         public Edge(int s, int d, int w) {
// // // // // // // // // // // // // //             this.src = s;
// // // // // // // // // // // // // //             this.dest = d;
// // // // // // // // // // // // // //             this.wt = w;
// // // // // // // // // // // // // //         }
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     // Create a sample graph
// // // // // // // // // // // // // //     static void createGraph(ArrayList<Edge>[] graph) {
// // // // // // // // // // // // // //         for (int i = 0; i < graph.length; i++) {
// // // // // // // // // // // // // //             graph[i] = new ArrayList<>();
// // // // // // // // // // // // // //         }

// // // // // // // // // // // // // //         // Example edges (undirected)
// // // // // // // // // // // // // //         graph[0].add(new Edge(0, 1, 1));
// // // // // // // // // // // // // //         graph[1].add(new Edge(1, 0, 1));

// // // // // // // // // // // // // //         graph[1].add(new Edge(1, 2, 1));
// // // // // // // // // // // // // //         graph[2].add(new Edge(2, 1, 1));

// // // // // // // // // // // // // //         graph[2].add(new Edge(2, 3, 1));
// // // // // // // // // // // // // //         graph[3].add(new Edge(3, 2, 1));

// // // // // // // // // // // // // //         graph[3].add(new Edge(3, 0, 1));
// // // // // // // // // // // // // //         graph[0].add(new Edge(0, 3, 1));

// // // // // // // // // // // // // //         graph[3].add(new Edge(3, 4, 1));
// // // // // // // // // // // // // //         graph[4].add(new Edge(4, 3, 1));
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     // DFS traversal for the whole graph
// // // // // // // // // // // // // //     public static void dfs(ArrayList<Edge>[] graph) {
// // // // // // // // // // // // // //         boolean vis[] = new boolean[graph.length];
// // // // // // // // // // // // // //         for (int i = 0; i < graph.length; i++) {
// // // // // // // // // // // // // //             if (!vis[i]) {
// // // // // // // // // // // // // //                 dfsUtil(graph, i, vis);
// // // // // // // // // // // // // //             }
// // // // // // // // // // // // // //         }
// // // // // // // // // // // // // //         System.out.println();
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     // DFS utility function
// // // // // // // // // // // // // //     public static void dfsUtil(ArrayList<Edge>[] graph, int curr, boolean vis[]) {
// // // // // // // // // // // // // //         System.out.print(curr + " ");
// // // // // // // // // // // // // //         vis[curr] = true;

// // // // // // // // // // // // // //         for (Edge e : graph[curr]) {
// // // // // // // // // // // // // //             if (!vis[e.dest]) {
// // // // // // // // // // // // // //                 dfsUtil(graph, e.dest, vis);
// // // // // // // // // // // // // //             }
// // // // // // // // // // // // // //         }
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     // Detect cycle in an undirected graph
// // // // // // // // // // // // // //     public static boolean detectCycle(ArrayList<Edge>[] graph) {
// // // // // // // // // // // // // //         boolean vis[] = new boolean[graph.length];
// // // // // // // // // // // // // //         for (int i = 0; i < graph.length; i++) {
// // // // // // // // // // // // // //             if (!vis[i]) {
// // // // // // // // // // // // // //                 if (detectCycleUtil(graph, vis, i, -1)) {
// // // // // // // // // // // // // //                     return true;
// // // // // // // // // // // // // //                 }
// // // // // // // // // // // // // //             }
// // // // // // // // // // // // // //         }
// // // // // // // // // // // // // //         return false;
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     // Utility for cycle detection
// // // // // // // // // // // // // //     public static boolean detectCycleUtil(ArrayList<Edge>[] graph, boolean vis[], int curr, int parent) {
// // // // // // // // // // // // // //         vis[curr] = true;

// // // // // // // // // // // // // //         for (Edge e : graph[curr]) {
// // // // // // // // // // // // // //             // Case 1: Unvisited neighbor
// // // // // // // // // // // // // //             if (!vis[e.dest]) {
// // // // // // // // // // // // // //                 if (detectCycleUtil(graph, vis, e.dest, curr)) {
// // // // // // // // // // // // // //                     return true;
// // // // // // // // // // // // // //                 }
// // // // // // // // // // // // // //             }
// // // // // // // // // // // // // //             // Case 2: Visited neighbor not parent -> cycle
// // // // // // // // // // // // // //             else if (e.dest != parent) {
// // // // // // // // // // // // // //                 return true;
// // // // // // // // // // // // // //             }
// // // // // // // // // // // // // //         }

// // // // // // // // // // // // // //         return false;
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     public static void main(String[] args) {
// // // // // // // // // // // // // //         int V = 5; // number of vertices
// // // // // // // // // // // // // //         ArrayList<Edge>[] graph = new ArrayList[V];

// // // // // // // // // // // // // //         createGraph(graph);

// // // // // // // // // // // // // //         System.out.println("DFS traversal:");
// // // // // // // // // // // // // //         dfs(graph);

// // // // // // // // // // // // // //         System.out.println("Cycle detected? " + detectCycle(graph));
// // // // // // // // // // // // // //     }
// // // // // // // // // // // // // // }
















// // // // // // // // // // // // // import java.util.*;

// // // // // // // // // // // // // public class Classroom {

// // // // // // // // // // // // //     // Edge class
// // // // // // // // // // // // //     static class Edge {
// // // // // // // // // // // // //         int src;
// // // // // // // // // // // // //         int dest;
// // // // // // // // // // // // //         int wt;

// // // // // // // // // // // // //         public Edge(int s, int d, int w) {
// // // // // // // // // // // // //             this.src = s;
// // // // // // // // // // // // //             this.dest = d;
// // // // // // // // // // // // //             this.wt = w;
// // // // // // // // // // // // //         }
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     // Create a sample directed graph
// // // // // // // // // // // // //     static void createGraph(ArrayList<Edge>[] graph) {
// // // // // // // // // // // // //         for (int i = 0; i < graph.length; i++) {
// // // // // // // // // // // // //             graph[i] = new ArrayList<>();
// // // // // // // // // // // // //         }
// // // // // // // // // // // // //         // Example edges for topological sort / cycle detection
// // // // // // // // // // // // //         graph[2].add(new Edge(2, 3, 1));
// // // // // // // // // // // // //         graph[3].add(new Edge(3, 4, 1));
// // // // // // // // // // // // //         graph[4].add(new Edge(4, 5, 1));
// // // // // // // // // // // // //         graph[5].add(new Edge(5, 0, 1));
// // // // // // // // // // // // //         graph[1].add(new Edge(1, 2, 1));
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     // Check if a graph is bipartite using BFS
// // // // // // // // // // // // //     public static boolean isBipartite(ArrayList<Edge>[] graph) {
// // // // // // // // // // // // //         int[] color = new int[graph.length];
// // // // // // // // // // // // //         Arrays.fill(color, -1); // -1 = no color

// // // // // // // // // // // // //         Queue<Integer> q = new LinkedList<>();

// // // // // // // // // // // // //         for (int i = 0; i < graph.length; i++) {
// // // // // // // // // // // // //             if (color[i] == -1) {
// // // // // // // // // // // // //                 q.add(i);
// // // // // // // // // // // // //                 color[i] = 0; // start color

// // // // // // // // // // // // //                 while (!q.isEmpty()) {
// // // // // // // // // // // // //                     int curr = q.remove();
// // // // // // // // // // // // //                     for (Edge e : graph[curr]) {
// // // // // // // // // // // // //                         if (color[e.dest] == -1) {
// // // // // // // // // // // // //                             color[e.dest] = 1 - color[curr]; // alternate color
// // // // // // // // // // // // //                             q.add(e.dest);
// // // // // // // // // // // // //                         } else if (color[e.dest] == color[curr]) {
// // // // // // // // // // // // //                             return false; // not bipartite
// // // // // // // // // // // // //                         }
// // // // // // // // // // // // //                     }
// // // // // // // // // // // // //                 }
// // // // // // // // // // // // //             }
// // // // // // // // // // // // //         }
// // // // // // // // // // // // //         return true;
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     // Detect cycle in directed graph using DFS
// // // // // // // // // // // // //     public static boolean detectCycle(ArrayList<Edge>[] graph) {
// // // // // // // // // // // // //         boolean[] vis = new boolean[graph.length];
// // // // // // // // // // // // //         boolean[] stack = new boolean[graph.length];

// // // // // // // // // // // // //         for (int i = 0; i < graph.length; i++) {
// // // // // // // // // // // // //             if (!vis[i] && detectCycleUtil(graph, i, vis, stack)) {
// // // // // // // // // // // // //                 return true;
// // // // // // // // // // // // //             }
// // // // // // // // // // // // //         }
// // // // // // // // // // // // //         return false;
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     public static boolean detectCycleUtil(ArrayList<Edge>[] graph, int curr, boolean[] vis, boolean[] stack) {
// // // // // // // // // // // // //         vis[curr] = true;
// // // // // // // // // // // // //         stack[curr] = true;

// // // // // // // // // // // // //         for (Edge e : graph[curr]) {
// // // // // // // // // // // // //             if (!vis[e.dest] && detectCycleUtil(graph, e.dest, vis, stack)) {
// // // // // // // // // // // // //                 return true;
// // // // // // // // // // // // //             } else if (stack[e.dest]) {
// // // // // // // // // // // // //                 return true; // cycle detected
// // // // // // // // // // // // //             }
// // // // // // // // // // // // //         }

// // // // // // // // // // // // //         stack[curr] = false;
// // // // // // // // // // // // //         return false;
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     // Topological sort
// // // // // // // // // // // // //     public static void topSort(ArrayList<Edge>[] graph) {
// // // // // // // // // // // // //         boolean[] vis = new boolean[graph.length];
// // // // // // // // // // // // //         Stack<Integer> s = new Stack<>();

// // // // // // // // // // // // //         for (int i = 0; i < graph.length; i++) {
// // // // // // // // // // // // //             if (!vis[i]) {
// // // // // // // // // // // // //                 topSortUtil(graph, i, vis, s);
// // // // // // // // // // // // //             }
// // // // // // // // // // // // //         }

// // // // // // // // // // // // //         System.out.print("Topological Sort: ");
// // // // // // // // // // // // //         while (!s.isEmpty()) {
// // // // // // // // // // // // //             System.out.print(s.pop() + " ");
// // // // // // // // // // // // //         }
// // // // // // // // // // // // //         System.out.println();
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     public static void topSortUtil(ArrayList<Edge>[] graph, int curr, boolean[] vis, Stack<Integer> s) {
// // // // // // // // // // // // //         vis[curr] = true;

// // // // // // // // // // // // //         for (Edge e : graph[curr]) {
// // // // // // // // // // // // //             if (!vis[e.dest]) {
// // // // // // // // // // // // //                 topSortUtil(graph, e.dest, vis, s);
// // // // // // // // // // // // //             }
// // // // // // // // // // // // //         }

// // // // // // // // // // // // //         s.push(curr); // add to stack after visiting neighbors
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     public static void main(String[] args) {
// // // // // // // // // // // // //         int V = 6;
// // // // // // // // // // // // //         ArrayList<Edge>[] graph = new ArrayList[V];

// // // // // // // // // // // // //         createGraph(graph);

// // // // // // // // // // // // //         System.out.println("Is graph bipartite? " + isBipartite(graph));
// // // // // // // // // // // // //         System.out.println("Does graph have a cycle? " + detectCycle(graph));
// // // // // // // // // // // // //         topSort(graph);
// // // // // // // // // // // // //     }
// // // // // // // // // // // // // }





















// // // // // // // // // // // // // Java implementation that includes:
// // // // // // // // // // // // // Calculating in-degree and out-degree of each vertex.
// // // // // // // // // // // // // Topological sort using in-degree (Kahn’s algorithm / BFS).
// // // // // // // // // // // // // Printing all paths from a source to a destination vertex.

// // // // // // // // // // // // import java.util.*;

// // // // // // // // // // // // public class Classroom {

// // // // // // // // // // // //     static class Edge {
// // // // // // // // // // // //         int src;
// // // // // // // // // // // //         int dest;
// // // // // // // // // // // //         int wt;

// // // // // // // // // // // //         public Edge(int s, int d, int w) {
// // // // // // // // // // // //             this.src = s;
// // // // // // // // // // // //             this.dest = d;
// // // // // // // // // // // //             this.wt = w;
// // // // // // // // // // // //         }
// // // // // // // // // // // //     }

// // // // // // // // // // // //     // Create a sample directed graph
// // // // // // // // // // // //     static void createGraph(ArrayList<Edge>[] graph) {
// // // // // // // // // // // //         for (int i = 0; i < graph.length; i++) {
// // // // // // // // // // // //             graph[i] = new ArrayList<>();
// // // // // // // // // // // //         }

// // // // // // // // // // // //         // Example directed edges
// // // // // // // // // // // //         graph[0].add(new Edge(0, 1, 1));
// // // // // // // // // // // //         graph[0].add(new Edge(0, 2, 1));
// // // // // // // // // // // //         graph[1].add(new Edge(1, 3, 1));
// // // // // // // // // // // //         graph[2].add(new Edge(2, 3, 1));
// // // // // // // // // // // //         graph[3].add(new Edge(3, 4, 1));
// // // // // // // // // // // //         graph[4].add(new Edge(4, 5, 1));
// // // // // // // // // // // //     }

// // // // // // // // // // // //     // Calculate in-degree and out-degree
// // // // // // // // // // // //     static void calcDegrees(ArrayList<Edge>[] graph, int[] indeg, int[] outdeg) {
// // // // // // // // // // // //         for (int i = 0; i < graph.length; i++) {
// // // // // // // // // // // //             outdeg[i] = graph[i].size(); // out-degree = number of outgoing edges
// // // // // // // // // // // //             for (Edge e : graph[i]) {
// // // // // // // // // // // //                 indeg[e.dest]++; // increment in-degree for destination vertex
// // // // // // // // // // // //             }
// // // // // // // // // // // //         }
// // // // // // // // // // // //     }

// // // // // // // // // // // //     // Topological sort using Kahn's Algorithm (BFS based on in-degree)
// // // // // // // // // // // //     static void topSort(ArrayList<Edge>[] graph) {
// // // // // // // // // // // //         int V = graph.length;
// // // // // // // // // // // //         int[] indeg = new int[V];
// // // // // // // // // // // //         int[] outdeg = new int[V];
// // // // // // // // // // // //         calcDegrees(graph, indeg, outdeg);

// // // // // // // // // // // //         System.out.println("In-degree: " + Arrays.toString(indeg));
// // // // // // // // // // // //         System.out.println("Out-degree: " + Arrays.toString(outdeg));

// // // // // // // // // // // //         Queue<Integer> q = new LinkedList<>();
// // // // // // // // // // // //         for (int i = 0; i < V; i++) {
// // // // // // // // // // // //             if (indeg[i] == 0) q.add(i);
// // // // // // // // // // // //         }

// // // // // // // // // // // //         System.out.print("Topological Sort: ");
// // // // // // // // // // // //         while (!q.isEmpty()) {
// // // // // // // // // // // //             int curr = q.remove();
// // // // // // // // // // // //             System.out.print(curr + " ");

// // // // // // // // // // // //             for (Edge e : graph[curr]) {
// // // // // // // // // // // //                 indeg[e.dest]--;
// // // // // // // // // // // //                 if (indeg[e.dest] == 0) q.add(e.dest);
// // // // // // // // // // // //             }
// // // // // // // // // // // //         }
// // // // // // // // // // // //         System.out.println();
// // // // // // // // // // // //     }

// // // // // // // // // // // //     // Print all paths from src to dest
// // // // // // // // // // // //     static void printAllPaths(ArrayList<Edge>[] graph, int src, int dest, String path) {
// // // // // // // // // // // //         if (src == dest) {
// // // // // // // // // // // //             System.out.println(path + dest);
// // // // // // // // // // // //             return;
// // // // // // // // // // // //         }

// // // // // // // // // // // //         for (Edge e : graph[src]) {
// // // // // // // // // // // //             printAllPaths(graph, e.dest, dest, path + src + " -> ");
// // // // // // // // // // // //         }
// // // // // // // // // // // //     }

// // // // // // // // // // // //     public static void main(String[] args) {
// // // // // // // // // // // //         int V = 6;
// // // // // // // // // // // //         ArrayList<Edge>[] graph = new ArrayList[V];
// // // // // // // // // // // //         createGraph(graph);

// // // // // // // // // // // //         // Calculate in-degree and out-degree, and perform topological sort
// // // // // // // // // // // //         topSort(graph);

// // // // // // // // // // // //         // Print all paths from source to destination
// // // // // // // // // // // //         int src = 0, dest = 5;
// // // // // // // // // // // //         System.out.println("All paths from " + src + " to " + dest + ":");
// // // // // // // // // // // //         printAllPaths(graph, src, dest, "");
// // // // // // // // // // // //     }
// // // // // // // // // // // // }










// // // // // // // // // // // implementation of Dijkstra’s algorithm
// // // // // // // // // // // import java.util.*;

// // // // // // // // // // // public class Classroom {

// // // // // // // // // // //     // Edge class representing a weighted directed edge
// // // // // // // // // // //     static class Edge {
// // // // // // // // // // //         int src;
// // // // // // // // // // //         int dest;
// // // // // // // // // // //         int wt;

// // // // // // // // // // //         public Edge(int s, int d, int w) {
// // // // // // // // // // //             this.src = s;
// // // // // // // // // // //             this.dest = d;
// // // // // // // // // // //             this.wt = w;
// // // // // // // // // // //         }
// // // // // // // // // // //     }

// // // // // // // // // // //     // Pair class for priority queue
// // // // // // // // // // //     static class Pair implements Comparable<Pair> {
// // // // // // // // // // //         int node;
// // // // // // // // // // //         int path; // distance from source

// // // // // // // // // // //         public Pair(int node, int path) {
// // // // // // // // // // //             this.node = node;
// // // // // // // // // // //             this.path = path;
// // // // // // // // // // //         }

// // // // // // // // // // //         @Override
// // // // // // // // // // //         public int compareTo(Pair p2) {
// // // // // // // // // // //             return this.path - p2.path; // min-heap based on distance
// // // // // // // // // // //         }
// // // // // // // // // // //     }

// // // // // // // // // // //     // Create a sample weighted directed graph
// // // // // // // // // // //     static void createGraph(ArrayList<Edge>[] graph) {
// // // // // // // // // // //         for (int i = 0; i < graph.length; i++) {
// // // // // // // // // // //             graph[i] = new ArrayList<>();
// // // // // // // // // // //         }

// // // // // // // // // // //         // Example weighted edges
// // // // // // // // // // //         graph[0].add(new Edge(0, 1, 4));
// // // // // // // // // // //         graph[0].add(new Edge(0, 2, 2));
// // // // // // // // // // //         graph[1].add(new Edge(1, 2, 5));
// // // // // // // // // // //         graph[1].add(new Edge(1, 3, 10));
// // // // // // // // // // //         graph[2].add(new Edge(2, 4, 3));
// // // // // // // // // // //         graph[4].add(new Edge(4, 3, 4));
// // // // // // // // // // //         graph[3].add(new Edge(3, 5, 11));
// // // // // // // // // // //     }

// // // // // // // // // // //     // Dijkstra's algorithm from source src
// // // // // // // // // // //     static void dijkstra(ArrayList<Edge>[] graph, int src) {
// // // // // // // // // // //         int V = graph.length;
// // // // // // // // // // //         int[] dist = new int[V]; // distance from src to each node
// // // // // // // // // // //         Arrays.fill(dist, Integer.MAX_VALUE);
// // // // // // // // // // //         dist[src] = 0;

// // // // // // // // // // //         boolean[] vis = new boolean[V]; // visited array
// // // // // // // // // // //         PriorityQueue<Pair> pq = new PriorityQueue<>();
// // // // // // // // // // //         pq.add(new Pair(src, 0));

// // // // // // // // // // //         while (!pq.isEmpty()) {
// // // // // // // // // // //             Pair curr = pq.remove();
// // // // // // // // // // //             int u = curr.node;

// // // // // // // // // // //             if (vis[u]) continue;
// // // // // // // // // // //             vis[u] = true;

// // // // // // // // // // //             // Check all neighbors
// // // // // // // // // // //             for (Edge e : graph[u]) {
// // // // // // // // // // //                 int v = e.dest;
// // // // // // // // // // //                 int wt = e.wt;

// // // // // // // // // // //                 if (dist[u] + wt < dist[v]) {
// // // // // // // // // // //                     dist[v] = dist[u] + wt;
// // // // // // // // // // //                     pq.add(new Pair(v, dist[v]));
// // // // // // // // // // //                 }
// // // // // // // // // // //             }
// // // // // // // // // // //         }

// // // // // // // // // // //         // Print distances from src
// // // // // // // // // // //         System.out.println("Shortest distances from node " + src + ":");
// // // // // // // // // // //         for (int i = 0; i < V; i++) {
// // // // // // // // // // //             if (dist[i] == Integer.MAX_VALUE) {
// // // // // // // // // // //                 System.out.println("Node " + i + ": INF");
// // // // // // // // // // //             } else {
// // // // // // // // // // //                 System.out.println("Node " + i + ": " + dist[i]);
// // // // // // // // // // //             }
// // // // // // // // // // //         }
// // // // // // // // // // //     }

// // // // // // // // // // //     public static void main(String[] args) {
// // // // // // // // // // //         int V = 6;
// // // // // // // // // // //         ArrayList<Edge>[] graph = new ArrayList[V];
// // // // // // // // // // //         createGraph(graph);

// // // // // // // // // // //         int src = 0;
// // // // // // // // // // //         dijkstra(graph, src);
// // // // // // // // // // //     }
// // // // // // // // // // // }









// // // // // // // // // // //implementation of the Bellman-Ford algorithm
// // // // // // // // // // import java.util.*;

// // // // // // // // // // public class Classroom {

// // // // // // // // // //     // Edge class representing weighted directed edges
// // // // // // // // // //     static class Edge {
// // // // // // // // // //         int src;
// // // // // // // // // //         int dest;
// // // // // // // // // //         int wt;

// // // // // // // // // //         public Edge(int s, int d, int w) {
// // // // // // // // // //             this.src = s;
// // // // // // // // // //             this.dest = d;
// // // // // // // // // //             this.wt = w;
// // // // // // // // // //         }
// // // // // // // // // //     }

// // // // // // // // // //     // Create a sample graph (directed, possibly with negative weights)
// // // // // // // // // //     static void createGraph(ArrayList<Edge>[] graph) {
// // // // // // // // // //         for (int i = 0; i < graph.length; i++) {
// // // // // // // // // //             graph[i] = new ArrayList<>();
// // // // // // // // // //         }

// // // // // // // // // //         // Example edges (u, v, weight)
// // // // // // // // // //         graph[0].add(new Edge(0, 1, 6));
// // // // // // // // // //         graph[0].add(new Edge(0, 2, 7));
// // // // // // // // // //         graph[1].add(new Edge(1, 2, 8));
// // // // // // // // // //         graph[1].add(new Edge(1, 3, 5));
// // // // // // // // // //         graph[1].add(new Edge(1, 4, -4));
// // // // // // // // // //         graph[2].add(new Edge(2, 3, -3));
// // // // // // // // // //         graph[2].add(new Edge(2, 4, 9));
// // // // // // // // // //         graph[3].add(new Edge(3, 1, -2));
// // // // // // // // // //         graph[4].add(new Edge(4, 0, 2));
// // // // // // // // // //         graph[4].add(new Edge(4, 3, 7));
// // // // // // // // // //     }

// // // // // // // // // //     // Bellman-Ford Algorithm
// // // // // // // // // //     static void bellmanFord(ArrayList<Edge>[] graph, int src) {
// // // // // // // // // //         int V = graph.length;
// // // // // // // // // //         int[] dist = new int[V];
// // // // // // // // // //         Arrays.fill(dist, Integer.MAX_VALUE);
// // // // // // // // // //         dist[src] = 0;

// // // // // // // // // //         // Relax edges V-1 times
// // // // // // // // // //         for (int i = 0; i < V - 1; i++) {
// // // // // // // // // //             for (int u = 0; u < V; u++) {
// // // // // // // // // //                 for (Edge e : graph[u]) {
// // // // // // // // // //                     int v = e.dest;
// // // // // // // // // //                     int wt = e.wt;
// // // // // // // // // //                     if (dist[u] != Integer.MAX_VALUE && dist[u] + wt < dist[v]) {
// // // // // // // // // //                         dist[v] = dist[u] + wt;
// // // // // // // // // //                     }
// // // // // // // // // //                 }
// // // // // // // // // //             }
// // // // // // // // // //         }

// // // // // // // // // //         // Check for negative weight cycles
// // // // // // // // // //         boolean hasNegativeCycle = false;
// // // // // // // // // //         for (int u = 0; u < V; u++) {
// // // // // // // // // //             for (Edge e : graph[u]) {
// // // // // // // // // //                 int v = e.dest;
// // // // // // // // // //                 int wt = e.wt;
// // // // // // // // // //                 if (dist[u] != Integer.MAX_VALUE && dist[u] + wt < dist[v]) {
// // // // // // // // // //                     hasNegativeCycle = true;
// // // // // // // // // //                     break;
// // // // // // // // // //                 }
// // // // // // // // // //             }
// // // // // // // // // //         }

// // // // // // // // // //         // Print results
// // // // // // // // // //         if (hasNegativeCycle) {
// // // // // // // // // //             System.out.println("Graph contains a negative weight cycle");
// // // // // // // // // //         } else {
// // // // // // // // // //             System.out.println("Shortest distances from node " + src + ":");
// // // // // // // // // //             for (int i = 0; i < V; i++) {
// // // // // // // // // //                 if (dist[i] == Integer.MAX_VALUE) {
// // // // // // // // // //                     System.out.println("Node " + i + ": INF");
// // // // // // // // // //                 } else {
// // // // // // // // // //                     System.out.println("Node " + i + ": " + dist[i]);
// // // // // // // // // //                 }
// // // // // // // // // //             }
// // // // // // // // // //         }
// // // // // // // // // //     }

// // // // // // // // // //     public static void main(String[] args) {
// // // // // // // // // //         int V = 5;
// // // // // // // // // //         ArrayList<Edge>[] graph = new ArrayList[V];
// // // // // // // // // //         createGraph(graph);

// // // // // // // // // //         int src = 0;
// // // // // // // // // //         bellmanFord(graph, src);
// // // // // // // // // //     }
// // // // // // // // // // }










// // // // // // // // // // prims algorithm 
// // // // // // // // // import java.util.*;

// // // // // // // // // public class Classroom {

// // // // // // // // //     // Edge class representing a weighted undirected edge
// // // // // // // // //     static class Edge {
// // // // // // // // //         int src;
// // // // // // // // //         int dest;
// // // // // // // // //         int wt;

// // // // // // // // //         public Edge(int s, int d, int w) {
// // // // // // // // //             this.src = s;
// // // // // // // // //             this.dest = d;
// // // // // // // // //             this.wt = w;
// // // // // // // // //         }
// // // // // // // // //     }

// // // // // // // // //     // Pair class for priority queue
// // // // // // // // //     static class Pair implements Comparable<Pair> {
// // // // // // // // //         int v;    // vertex
// // // // // // // // //         int cost; // edge weight to reach this vertex

// // // // // // // // //         public Pair(int v, int c) {
// // // // // // // // //             this.v = v;
// // // // // // // // //             this.cost = c;
// // // // // // // // //         }

// // // // // // // // //         @Override
// // // // // // // // //         public int compareTo(Pair p2) {
// // // // // // // // //             return this.cost - p2.cost; // min-heap based on cost
// // // // // // // // //         }
// // // // // // // // //     }

// // // // // // // // //     // Create a sample undirected weighted graph
// // // // // // // // //     static void createGraph(ArrayList<Edge>[] graph) {
// // // // // // // // //         for (int i = 0; i < graph.length; i++) {
// // // // // // // // //             graph[i] = new ArrayList<>();
// // // // // // // // //         }

// // // // // // // // //         // Add edges (undirected graph: add both directions)
// // // // // // // // //         addEdge(graph, 0, 1, 4);
// // // // // // // // //         addEdge(graph, 0, 2, 3);
// // // // // // // // //         addEdge(graph, 1, 2, 1);
// // // // // // // // //         addEdge(graph, 1, 3, 2);
// // // // // // // // //         addEdge(graph, 2, 3, 4);
// // // // // // // // //         addEdge(graph, 3, 4, 2);
// // // // // // // // //         addEdge(graph, 4, 5, 6);
// // // // // // // // //     }

// // // // // // // // //     static void addEdge(ArrayList<Edge>[] graph, int u, int v, int w) {
// // // // // // // // //         graph[u].add(new Edge(u, v, w));
// // // // // // // // //         graph[v].add(new Edge(v, u, w)); // undirected
// // // // // // // // //     }

// // // // // // // // //     // Prim's algorithm to find Minimum Spanning Tree (MST)
// // // // // // // // //     static void prims(ArrayList<Edge>[] graph) {
// // // // // // // // //         boolean[] vis = new boolean[graph.length];
// // // // // // // // //         PriorityQueue<Pair> pq = new PriorityQueue<>();
// // // // // // // // //         pq.add(new Pair(0, 0)); // start from vertex 0

// // // // // // // // //         int finalCost = 0;

// // // // // // // // //         System.out.println("Edges in MST:");

// // // // // // // // //         while (!pq.isEmpty()) {
// // // // // // // // //             Pair curr = pq.remove();
// // // // // // // // //             if (vis[curr.v]) continue;

// // // // // // // // //             vis[curr.v] = true;
// // // // // // // // //             finalCost += curr.cost;

// // // // // // // // //             for (Edge e : graph[curr.v]) {
// // // // // // // // //                 if (!vis[e.dest]) {
// // // // // // // // //                     pq.add(new Pair(e.dest, e.wt));
// // // // // // // // //                 }
// // // // // // // // //             }
// // // // // // // // //         }

// // // // // // // // //         System.out.println("Total cost of MST: " + finalCost);
// // // // // // // // //     }

// // // // // // // // //     public static void main(String[] args) {
// // // // // // // // //         int V = 6;
// // // // // // // // //         ArrayList<Edge>[] graph = new ArrayList[V];
// // // // // // // // //         createGraph(graph);

// // // // // // // // //         prims(graph);
// // // // // // // // //     }
// // // // // // // // // }










// // // // // // // // /*
// // // // // // // // Cheapest Flights within K Stops

// // // // // // // // There are n cities connected by some number of flights. 
// // // // // // // // You are given an array 'flights' where flights[i] = [from, to, price] 
// // // // // // // // indicates that there is a flight from city 'from' to city 'to' with cost 'price'.

// // // // // // // // You are also given three integers: 
// // // // // // // // - src  : the starting city
// // // // // // // // - dst  : the destination city
// // // // // // // // - k    : the maximum number of stops allowed

// // // // // // // // Task:
// // // // // // // // Return the cheapest price from 'src' to 'dst' with at most 'k' stops. 
// // // // // // // // If there is no such route, return -1.

// // // // // // // // Example:
// // // // // // // // flights = [[0,1,100],[1,2,100],[0,2,500]]
// // // // // // // // src = 0
// // // // // // // // dst = 2
// // // // // // // // k = 1
// // // // // // // // Output: 200
// // // // // // // // */

// // // // // // // // import java.util.*;

// // // // // // // // public class CheapestFlight {

// // // // // // // //     // Edge class to represent a flight
// // // // // // // //     static class Edge {
// // // // // // // //         int src;
// // // // // // // //         int dest;
// // // // // // // //         int wt;

// // // // // // // //         public Edge(int s, int d, int w) {
// // // // // // // //             this.src = s;
// // // // // // // //             this.dest = d;
// // // // // // // //             this.wt = w;
// // // // // // // //         }
// // // // // // // //     }

// // // // // // // //     // Info class to track current node, cost, and stops
// // // // // // // //     static class Info {
// // // // // // // //         int v;
// // // // // // // //         int cost;
// // // // // // // //         int stops;

// // // // // // // //         public Info(int v, int cost, int stops) {
// // // // // // // //             this.v = v;
// // // // // // // //             this.cost = cost;
// // // // // // // //             this.stops = stops;
// // // // // // // //         }
// // // // // // // //     }

// // // // // // // //     public static int findCheapestPrice(int n, int[][] flights, int src, int dst, int k) {
// // // // // // // //         // Build adjacency list
// // // // // // // //         List<Edge>[] graph = new ArrayList[n];
// // // // // // // //         for (int i = 0; i < n; i++) {
// // // // // // // //             graph[i] = new ArrayList<>();
// // // // // // // //         }
// // // // // // // //         for (int[] f : flights) {
// // // // // // // //             graph[f[0]].add(new Edge(f[0], f[1], f[2]));
// // // // // // // //         }

// // // // // // // //         // Distance array
// // // // // // // //         int[] dist = new int[n];
// // // // // // // //         Arrays.fill(dist, Integer.MAX_VALUE);
// // // // // // // //         dist[src] = 0;

// // // // // // // //         // BFS Queue
// // // // // // // //         Queue<Info> q = new LinkedList<>();
// // // // // // // //         q.add(new Info(src, 0, 0));

// // // // // // // //         while (!q.isEmpty()) {
// // // // // // // //             Info curr = q.remove();

// // // // // // // //             if (curr.stops > k) continue;

// // // // // // // //             for (Edge e : graph[curr.v]) {
// // // // // // // //                 int u = e.src;
// // // // // // // //                 int v = e.dest;
// // // // // // // //                 int wt = e.wt;

// // // // // // // //                 if (curr.cost + wt < dist[v]) {
// // // // // // // //                     dist[v] = curr.cost + wt;
// // // // // // // //                     q.add(new Info(v, dist[v], curr.stops + 1));
// // // // // // // //                 }
// // // // // // // //             }
// // // // // // // //         }

// // // // // // // //         return dist[dst] == Integer.MAX_VALUE ? -1 : dist[dst];
// // // // // // // //     }

// // // // // // // //     public static void main(String[] args) {
// // // // // // // //         int n = 4;
// // // // // // // //         int[][] flights = {{0, 1, 100}, {1, 2, 100}, {0, 2, 500}};
// // // // // // // //         int src = 0, dst = 2, k = 1;

// // // // // // // //         int cheapest = findCheapestPrice(n, flights, src, dst, k);
// // // // // // // //         System.out.println("Cheapest price: " + cheapest);
// // // // // // // //     }
// // // // // // // // }

















// // // // // // // // Connecting Cities with Minimum Cost
// // // // // // // // Find the minimum cost for connecting all cities on the map.
// // // // // // // // cities[][] =
// // // // // // // // {{0, 1, 2, 3, 4), {1, 0, 5, 0, 7}, {2, 5, 0, 6, 0}, {3, 0, 6, 0, 0), {4, 7, 0, 0, 0}}
// // // // // // // // ans = 10

// // // // // // // import java.util.*;

// // // // // // // public class ConnectCities {

// // // // // // //     // Edge class for priority queue
// // // // // // //     static class Edge implements Comparable<Edge> {
// // // // // // //         int dest;
// // // // // // //         int cost;

// // // // // // //         public Edge(int d, int c) {
// // // // // // //             this.dest = d;
// // // // // // //             this.cost = c;
// // // // // // //         }

// // // // // // //         @Override
// // // // // // //         public int compareTo(Edge e) {
// // // // // // //             return this.cost - e.cost; // min-heap based on cost
// // // // // // //         }
// // // // // // //     }

// // // // // // //     // Function to calculate minimum cost to connect all cities
// // // // // // //     public static int connectCities(int[][] cities) {
// // // // // // //         int n = cities.length;
// // // // // // //         boolean[] vis = new boolean[n];
// // // // // // //         PriorityQueue<Edge> pq = new PriorityQueue<>();
// // // // // // //         pq.add(new Edge(0, 0)); // start from city 0
// // // // // // //         int finalCost = 0;

// // // // // // //         while (!pq.isEmpty()) {
// // // // // // //             Edge curr = pq.remove();
// // // // // // //             if (!vis[curr.dest]) {
// // // // // // //                 vis[curr.dest] = true;
// // // // // // //                 finalCost += curr.cost;

// // // // // // //                 for (int i = 0; i < n; i++) {
// // // // // // //                     if (cities[curr.dest][i] != 0 && !vis[i]) {
// // // // // // //                         pq.add(new Edge(i, cities[curr.dest][i]));
// // // // // // //                     }
// // // // // // //                 }
// // // // // // //             }
// // // // // // //         }

// // // // // // //         return finalCost;
// // // // // // //     }

// // // // // // //     public static void main(String[] args) {
// // // // // // //         int[][] cities = {
// // // // // // //             {0, 2, 3, 0, 0},
// // // // // // //             {2, 0, 5, 0, 7},
// // // // // // //             {3, 5, 0, 6, 0},
// // // // // // //             {0, 0, 6, 0, 0},
// // // // // // //             {0, 7, 0, 0, 0}
// // // // // // //         };

// // // // // // //         int minCost = connectCities(cities);
// // // // // // //         System.out.println("Minimum cost to connect all cities: " + minCost);
// // // // // // //     }
// // // // // // // }







// // // // // // // disjoint set union 
// // // // // // public class DisjointSetUnion {

// // // // // //     static int[] par;
// // // // // //     static int[] rank;
// // // // // //     static int n = 5; // example size, adjust as needed

// // // // // //     // Initialize parent and rank arrays
// // // // // //     static void init() {
// // // // // //         par = new int[n];
// // // // // //         rank = new int[n];
// // // // // //         for (int i = 0; i < n; i++) {
// // // // // //             par[i] = i; // parent of each element is itself
// // // // // //             rank[i] = 0; // initial rank
// // // // // //         }
// // // // // //     }

// // // // // //     // Find with path compression
// // // // // //     public static int find(int x) {
// // // // // //         if (par[x] != x) {
// // // // // //             par[x] = find(par[x]);
// // // // // //         }
// // // // // //         return par[x];
// // // // // //     }

// // // // // //     // Union by rank
// // // // // //     public static void union(int a, int b) {
// // // // // //         int parA = find(a);
// // // // // //         int parB = find(b);

// // // // // //         if (parA == parB) return; // already in same set

// // // // // //         if (rank[parA] > rank[parB]) {
// // // // // //             par[parB] = parA;
// // // // // //         } else if (rank[parA] < rank[parB]) {
// // // // // //             par[parA] = parB;
// // // // // //         } else {
// // // // // //             par[parB] = parA;
// // // // // //             rank[parA]++;
// // // // // //         }
// // // // // //     }

// // // // // //     public static void main(String[] args) {
// // // // // //         init();

// // // // // //         // Example unions
// // // // // //         union(1, 2);
// // // // // //         union(2, 3);
// // // // // //         union(4, 1);

// // // // // //         // Example finds
// // // // // //         System.out.println("Parent of 2: " + find(2));
// // // // // //         System.out.println("Parent of 3: " + find(3));
// // // // // //         System.out.println("Parent of 4: " + find(4));
// // // // // //     }
// // // // // // }



















// // // // // // Kruskal mst 
// // // // // import java.util.*;

// // // // // public class KruskalMST {

// // // // //     // Edge class
// // // // //     static class Edge implements Comparable<Edge> {
// // // // //         int src;
// // // // //         int dest;
// // // // //         int wt;

// // // // //         public Edge(int s, int d, int w) {
// // // // //             this.src = s;
// // // // //             this.dest = d;
// // // // //             this.wt = w;
// // // // //         }

// // // // //         @Override
// // // // //         public int compareTo(Edge e2) {
// // // // //             return this.wt - e2.wt; // sort by weight
// // // // //         }
// // // // //     }

// // // // //     // Union-Find arrays
// // // // //     static int[] par;
// // // // //     static int[] rank;

// // // // //     // Initialize Union-Find
// // // // //     static void init(int V) {
// // // // //         par = new int[V];
// // // // //         rank = new int[V];
// // // // //         for (int i = 0; i < V; i++) {
// // // // //             par[i] = i;
// // // // //             rank[i] = 0;
// // // // //         }
// // // // //     }

// // // // //     // Find with path compression
// // // // //     public static int find(int x) {
// // // // //         if (par[x] != x) {
// // // // //             par[x] = find(par[x]);
// // // // //         }
// // // // //         return par[x];
// // // // //     }

// // // // //     // Union by rank
// // // // //     public static void union(int a, int b) {
// // // // //         int parA = find(a);
// // // // //         int parB = find(b);

// // // // //         if (parA == parB) return;

// // // // //         if (rank[parA] > rank[parB]) {
// // // // //             par[parB] = parA;
// // // // //         } else if (rank[parA] < rank[parB]) {
// // // // //             par[parA] = parB;
// // // // //         } else {
// // // // //             par[parB] = parA;
// // // // //             rank[parA]++;
// // // // //         }
// // // // //     }

// // // // //     // Kruskal's algorithm to calculate MST
// // // // //     public static void kruskalsMST(ArrayList<Edge> edges, int V) {
// // // // //         init(V);
// // // // //         Collections.sort(edges); // sort edges by weight

// // // // //         int mstCost = 0;
// // // // //         int count = 0;

// // // // //         for (int i = 0; count < V - 1 && i < edges.size(); i++) {
// // // // //             Edge e = edges.get(i);
// // // // //             int parA = find(e.src);
// // // // //             int parB = find(e.dest);

// // // // //             if (parA != parB) {
// // // // //                 union(e.src, e.dest);
// // // // //                 mstCost += e.wt;
// // // // //                 count++;
// // // // //             }
// // // // //         }

// // // // //         System.out.println("Minimum cost of MST: " + mstCost);
// // // // //     }

// // // // //     public static void main(String[] args) {
// // // // //         int V = 4;
// // // // //         ArrayList<Edge> edges = new ArrayList<>();

// // // // //         // Add edges: Edge(src, dest, weight)
// // // // //         edges.add(new Edge(0, 1, 15));
// // // // //         edges.add(new Edge(0, 3, 30));
// // // // //         edges.add(new Edge(1, 3, 40));
// // // // //         edges.add(new Edge(1, 2, 10));
// // // // //         edges.add(new Edge(2, 3, 5));

// // // // //         kruskalsMST(edges, V);
// // // // //     }
// // // // // }







// // // // /*
// // // // Flood Fill Algorithm

// // // // Problem:
// // // // You are given a m x n integer grid "image" where each value represents the pixel color.
// // // // You are also given three integers sr, sc, and color.
// // // // You need to perform a flood fill on the image starting from the pixel (sr, sc).

// // // // Flood fill rules:
// // // // - Start from (sr, sc).
// // // // - Change the color of that pixel and all pixels connected 4-directionally
// // // //   (up, down, left, right) with the same original color.
// // // // - Continue spreading until no more same-color neighbors are found.
// // // // - Replace all these pixels with the new color.

// // // // Example:

// // // // Input:
// // // // image = [
// // // //   [1, 1, 1],
// // // //   [1, 1, 0],
// // // //   [1, 0, 1]
// // // // ]
// // // // sr = 1, sc = 1, color = 2

// // // // Output:
// // // // [
// // // //   [2, 2, 2],
// // // //   [2, 2, 0],
// // // //   [2, 0, 1]
// // // // ]
// // // // */


// // // // import java.util.*;

// // // // public class Classroom {

// // // //     // Helper function for DFS flood fill
// // // //     public static void helper(int[][] image, int sr, int sc, int color, boolean[][] vis, int orgCol) {
// // // //         // Boundary conditions
// // // //         if (sr < 0 || sc < 0 || sr >= image.length || sc >= image[0].length) return;
// // // //         if (vis[sr][sc]) return; // already visited
// // // //         if (image[sr][sc] != orgCol) return; // different color, stop

// // // //         // Fill with new color
// // // //         image[sr][sc] = color;
// // // //         vis[sr][sc] = true;

// // // //         // Move 4-directionally
// // // //         helper(image, sr, sc - 1, color, vis, orgCol); // left
// // // //         helper(image, sr, sc + 1, color, vis, orgCol); // right
// // // //         helper(image, sr - 1, sc, color, vis, orgCol); // up
// // // //         helper(image, sr + 1, sc, color, vis, orgCol); // down
// // // //     }

// // // //     // Main flood fill function
// // // //     public static int[][] floodFill(int[][] image, int sr, int sc, int color) {
// // // //         boolean[][] vis = new boolean[image.length][image[0].length];
// // // //         int orgCol = image[sr][sc];
// // // //         if (orgCol != color) { // avoid infinite loop
// // // //             helper(image, sr, sc, color, vis, orgCol);
// // // //         }
// // // //         return image;
// // // //     }

// // // //     public static void main(String[] args) {
// // // //         int[][] image = {
// // // //             {1, 1, 1},
// // // //             {1, 1, 0},
// // // //             {1, 0, 1}
// // // //         };
// // // //         int sr = 1, sc = 1, color = 2;

// // // //         int[][] ans = floodFill(image, sr, sc, color);

// // // //         System.out.println("Flood Filled Image:");
// // // //         for (int[] row : ans) {
// // // //             System.out.println(Arrays.toString(row));
// // // //         }
// // // //     }
// // // // }









// // // //Kosaraju’s Algorithm for Strongly Connected Components (SCCs)

// // // import java.util.*;

// // // public class Classroom {
// // //     static class Edge {
// // //         int src;
// // //         int dest;

// // //         public Edge(int s, int d) {
// // //             this.src = s;
// // //             this.dest = d;
// // //         }
// // //     }

// // //     // Step 1: Topological sort (fill stack)
// // //     public static void topSort(ArrayList<Edge>[] graph, int curr, boolean[] vis, Stack<Integer> stack) {
// // //         vis[curr] = true;
// // //         for (int i = 0; i < graph[curr].size(); i++) {
// // //             Edge e = graph[curr].get(i);
// // //             if (!vis[e.dest]) {
// // //                 topSort(graph, e.dest, vis, stack);
// // //             }
// // //         }
// // //         stack.push(curr);
// // //     }

// // //     // Step 2: DFS on transposed graph
// // //     public static void dfs(ArrayList<Edge>[] graph, int curr, boolean[] vis) {
// // //         vis[curr] = true;
// // //         System.out.print(curr + " ");
// // //         for (int i = 0; i < graph[curr].size(); i++) {
// // //             Edge e = graph[curr].get(i);
// // //             if (!vis[e.dest]) {
// // //                 dfs(graph, e.dest, vis);
// // //             }
// // //         }
// // //     }

// // //     // Kosaraju’s Algorithm
// // //     public static void kosaraju(ArrayList<Edge>[] graph, int V) {
// // //         // Step 1: Topological sort
// // //         Stack<Integer> stack = new Stack<>();
// // //         boolean[] vis = new boolean[V];
// // //         for (int i = 0; i < V; i++) {
// // //             if (!vis[i]) {
// // //                 topSort(graph, i, vis, stack);
// // //             }
// // //         }

// // //         // Step 2: Transpose graph
// // //         ArrayList<Edge>[] transpose = new ArrayList[V];
// // //         for (int i = 0; i < V; i++) {
// // //             transpose[i] = new ArrayList<>();
// // //         }
// // //         for (int i = 0; i < V; i++) {
// // //             for (Edge e : graph[i]) {
// // //                 transpose[e.dest].add(new Edge(e.dest, e.src));
// // //             }
// // //         }

// // //         // Step 3: DFS according to stack order
// // //         Arrays.fill(vis, false);
// // //         System.out.println("Strongly Connected Components:");
// // //         while (!stack.isEmpty()) {
// // //             int curr = stack.pop();
// // //             if (!vis[curr]) {
// // //                 dfs(transpose, curr, vis);
// // //                 System.out.println();
// // //             }
// // //         }
// // //     }

// // //     // Graph creation
// // //     public static void createGraph(ArrayList<Edge>[] graph) {
// // //         for (int i = 0; i < graph.length; i++) {
// // //             graph[i] = new ArrayList<>();
// // //         }

// // //         graph[0].add(new Edge(0, 2));
// // //         graph[0].add(new Edge(0, 3));
// // //         graph[1].add(new Edge(1, 0));
// // //         graph[2].add(new Edge(2, 1));
// // //         graph[3].add(new Edge(3, 4));
// // //     }

// // //     public static void main(String[] args) {
// // //         int V = 5;
// // //         ArrayList<Edge>[] graph = new ArrayList[V];
// // //         createGraph(graph);

// // //         kosaraju(graph, V);
// // //     }
// // // }











// // //Bridge in Graphs (Tarjan’s Algorithm for finding bridges).
// // import java.util.*;

// // public class BridgeInGraph {

// //     // Edge class to represent connections
// //     static class Edge {
// //         int src, dest;
// //         Edge(int s, int d) {
// //             this.src = s;
// //             this.dest = d;
// //         }
// //     }

// //     // Step 1: Create graph
// //     public static void createGraph(ArrayList<Edge>[] graph) {
// //         for (int i = 0; i < graph.length; i++) {
// //             graph[i] = new ArrayList<>();
// //         }

// //         // Add edges (undirected graph)
// //         graph[0].add(new Edge(0, 1));
// //         graph[0].add(new Edge(0, 2));

// //         graph[1].add(new Edge(1, 0));
// //         graph[1].add(new Edge(1, 3));

// //         graph[2].add(new Edge(2, 0));
// //         graph[2].add(new Edge(2, 3));

// //         graph[3].add(new Edge(3, 1));
// //         graph[3].add(new Edge(3, 2));
// //         graph[3].add(new Edge(3, 4));

// //         graph[4].add(new Edge(4, 3));
// //         graph[4].add(new Edge(4, 5));

// //         graph[5].add(new Edge(5, 4));
// //     }

// //     // Step 2: DFS to find bridges
// //     public static void dfs(ArrayList<Edge>[] graph, int curr, int parent,
// //                            boolean[] vis, int[] dt, int[] low, int time) {
// //         vis[curr] = true;
// //         dt[curr] = low[curr] = ++time; // discovery & low time

// //         for (Edge e : graph[curr]) {
// //             int neigh = e.dest;
// //             if (neigh == parent) continue; // ignore the edge back to parent

// //             if (!vis[neigh]) {
// //                 dfs(graph, neigh, curr, vis, dt, low, time);
// //                 low[curr] = Math.min(low[curr], low[neigh]);

// //                 // Bridge condition
// //                 if (dt[curr] < low[neigh]) {
// //                     System.out.println("Bridge: " + curr + " --- " + neigh);
// //                 }
// //             } else {
// //                 // Back edge → update low
// //                 low[curr] = Math.min(low[curr], dt[neigh]);
// //             }
// //         }
// //     }

// //     // Step 3: Run Tarjan’s Bridge Algorithm
// //     public static void tarjanBridge(ArrayList<Edge>[] graph, int V) {
// //         boolean[] vis = new boolean[V];
// //         int[] dt = new int[V];
// //         int[] low = new int[V];
// //         int time = 0;

// //         for (int i = 0; i < V; i++) {
// //             if (!vis[i]) {
// //                 dfs(graph, i, -1, vis, dt, low, time);
// //             }
// //         }
// //     }

// //     // Main function
// //     public static void main(String[] args) {
// //         int V = 6;
// //         ArrayList<Edge>[] graph = new ArrayList[V];
// //         createGraph(graph);

// //         System.out.println("Bridges in the graph:");
// //         tarjanBridge(graph, V);
// //     }
// // }




// //Articulation Points (APs) using Tarjan’s Algorithm.

// import java.util.*;

// public class ArticulationPoint {

//     static class Edge {
//         int src, dest;
//         Edge(int s, int d) {
//             this.src = s;
//             this.dest = d;
//         }
//     }

//     // Create graph
//     public static void createGraph(ArrayList<Edge>[] graph) {
//         for (int i = 0; i < graph.length; i++) {
//             graph[i] = new ArrayList<>();
//         }

//         // Example graph (with articulation points)
//         graph[0].add(new Edge(0, 1));
//         graph[1].add(new Edge(1, 0));

//         graph[0].add(new Edge(0, 2));
//         graph[2].add(new Edge(2, 0));

//         graph[1].add(new Edge(1, 2));
//         graph[2].add(new Edge(2, 1));

//         graph[1].add(new Edge(1, 3));
//         graph[3].add(new Edge(3, 1));

//         graph[3].add(new Edge(3, 4));
//         graph[4].add(new Edge(4, 3));
//     }

//     // DFS to find articulation points
//     public static void dfs(ArrayList<Edge>[] graph, int curr, int parent,
//                            int[] dt, int[] low, boolean[] vis, int time, boolean[] ap) {
//         vis[curr] = true;
//         dt[curr] = low[curr] = ++time;
//         int children = 0;

//         for (Edge e : graph[curr]) {
//             int neigh = e.dest;

//             if (neigh == parent) continue;

//             if (!vis[neigh]) {
//                 children++;
//                 dfs(graph, neigh, curr, dt, low, vis, time, ap);

//                 low[curr] = Math.min(low[curr], low[neigh]);

//                 // Rule 1: Non-root articulation point
//                 if (parent != -1 && dt[curr] <= low[neigh]) {
//                     ap[curr] = true;
//                 }
//             } else {
//                 // Back edge
//                 low[curr] = Math.min(low[curr], dt[neigh]);
//             }
//         }

//         // Rule 2: Root articulation point
//         if (parent == -1 && children > 1) {
//             ap[curr] = true;
//         }
//     }

//     // Function to find APs
//     public static void findAP(ArrayList<Edge>[] graph, int V) {
//         int[] dt = new int[V];
//         int[] low = new int[V];
//         boolean[] vis = new boolean[V];
//         boolean[] ap = new boolean[V]; // store articulation points
//         int time = 0;

//         for (int i = 0; i < V; i++) {
//             if (!vis[i]) {
//                 dfs(graph, i, -1, dt, low, vis, time, ap);
//             }
//         }

//         // Print articulation points
//         System.out.println("Articulation Points:");
//         for (int i = 0; i < V; i++) {
//             if (ap[i]) {
//                 System.out.println(i);
//             }
//         }
//     }

//     public static void main(String[] args) {
//         int V = 5;
//         ArrayList<Edge>[] graph = new ArrayList[V];
//         createGraph(graph);

//         findAP(graph, V);
//     }
// }
