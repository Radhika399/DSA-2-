//package Heap;
// // // // // // // // import java.util.PriorityQueue;

// // // // // // // // public class Classroom {

// // // // // // // //     // Student class implementing Comparable
// // // // // // // //     static class Student implements Comparable<Student> {
// // // // // // // //         String name;
// // // // // // // //         int rank;

// // // // // // // //         public Student(String name, int rank) {
// // // // // // // //             this.name = name;
// // // // // // // //             this.rank = rank;
// // // // // // // //         }

// // // // // // // //         // Override compareTo to sort by rank (ascending)
// // // // // // // //         @Override
// // // // // // // //         public int compareTo(Student s2) {
// // // // // // // //             return this.rank - s2.rank; // smaller rank comes first
// // // // // // // //         }
// // // // // // // //     }

// // // // // // // //     public static void main(String[] args) {
// // // // // // // //         // ===== Example 1: PriorityQueue of integers =====
// // // // // // // //         PriorityQueue<Integer> pqInt = new PriorityQueue<>();
// // // // // // // //         pqInt.add(3);
// // // // // // // //         pqInt.add(4);
// // // // // // // //         pqInt.add(1);
// // // // // // // //         pqInt.add(7);

// // // // // // // //         System.out.println("PriorityQueue of integers (ascending):");
// // // // // // // //         while (!pqInt.isEmpty()) {
// // // // // // // //             System.out.println(pqInt.peek());
// // // // // // // //             pqInt.remove();
// // // // // // // //         }

// // // // // // // //         // ===== Example 2: PriorityQueue of Students =====
// // // // // // // //         PriorityQueue<Student> pqStudent = new PriorityQueue<>();
// // // // // // // //         pqStudent.add(new Student("Alice", 3));
// // // // // // // //         pqStudent.add(new Student("Bob", 1));
// // // // // // // //         pqStudent.add(new Student("Charlie", 4));
// // // // // // // //         pqStudent.add(new Student("David", 2));

// // // // // // // //         System.out.println("\nPriorityQueue of students (by rank):");
// // // // // // // //         while (!pqStudent.isEmpty()) {
// // // // // // // //             Student top = pqStudent.peek();
// // // // // // // //             System.out.println(top.name + " - Rank: " + top.rank);
// // // // // // // //             pqStudent.remove();
// // // // // // // //         }
// // // // // // // //     }
// // // // // // // // }






// // // // // // // import java.util.ArrayList;

// // // // // // // public class Classroom {

// // // // // // //     static class Heap {
// // // // // // //         ArrayList<Integer> arr;

// // // // // // //         public Heap() {
// // // // // // //             arr = new ArrayList<>();
// // // // // // //         }

// // // // // // //         // Add element to heap
// // // // // // //         public void add(int data) {
// // // // // // //             arr.add(data);           // Add at last index
// // // // // // //             int x = arr.size() - 1;  // child index
// // // // // // //             int par = (x - 1) / 2;   // parent index

// // // // // // //             // Bubble up
// // // // // // //             while (x > 0 && arr.get(x) < arr.get(par)) {
// // // // // // //                 int temp = arr.get(x);
// // // // // // //                 arr.set(x, arr.get(par));
// // // // // // //                 arr.set(par, temp);

// // // // // // //                 x = par;
// // // // // // //                 par = (x - 1) / 2;
// // // // // // //             }
// // // // // // //         }

// // // // // // //         // Peek top element
// // // // // // //         public int peek() {
// // // // // // //             if (arr.size() == 0) return -1;
// // // // // // //             return arr.get(0);
// // // // // // //         }

// // // // // // //         // Remove top element
// // // // // // //         public int remove() {
// // // // // // //             if (arr.size() == 0) return -1;

// // // // // // //             int data = arr.get(0);
// // // // // // //             int last = arr.size() - 1;
// // // // // // //             arr.set(0, arr.get(last)); // Move last to top
// // // // // // //             arr.remove(last);          // Delete last

// // // // // // //             heapify(0);
// // // // // // //             return data;
// // // // // // //         }

// // // // // // //         // Heapify from index i
// // // // // // //         private void heapify(int i) {
// // // // // // //             int left = 2 * i + 1;
// // // // // // //             int right = 2 * i + 2;
// // // // // // //             int minIdx = i;

// // // // // // //             if (left < arr.size() && arr.get(left) < arr.get(minIdx))
// // // // // // //                 minIdx = left;
// // // // // // //             if (right < arr.size() && arr.get(right) < arr.get(minIdx))
// // // // // // //                 minIdx = right;

// // // // // // //             if (minIdx != i) {
// // // // // // //                 int temp = arr.get(i);
// // // // // // //                 arr.set(i, arr.get(minIdx));
// // // // // // //                 arr.set(minIdx, temp);
// // // // // // //                 heapify(minIdx);
// // // // // // //             }
// // // // // // //         }

// // // // // // //         public boolean isEmpty() {
// // // // // // //             return arr.size() == 0;
// // // // // // //         }
// // // // // // //     }

// // // // // // //     public static void main(String[] args) {
// // // // // // //         Heap pq = new Heap();
// // // // // // //         pq.add(3);
// // // // // // //         pq.add(4);
// // // // // // //         pq.add(1);
// // // // // // //         pq.add(5);

// // // // // // //         System.out.println("Heap elements in ascending order:");
// // // // // // //         while (!pq.isEmpty()) {
// // // // // // //             System.out.print(pq.peek() + " ");
// // // // // // //             pq.remove();
// // // // // // //         }
// // // // // // //     }
// // // // // // // }









// // // // // // public class Classroom {

// // // // // //     // Heapify a subtree rooted at index i for max-heap
// // // // // //     public static void heapify(int arr[], int i, int size) {
// // // // // //         int left = 2 * i + 1;
// // // // // //         int right = 2 * i + 2;
// // // // // //         int maxIdx = i;

// // // // // //         if (left < size && arr[left] > arr[maxIdx])
// // // // // //             maxIdx = left;

// // // // // //         if (right < size && arr[right] > arr[maxIdx])
// // // // // //             maxIdx = right;

// // // // // //         if (maxIdx != i) {
// // // // // //             int temp = arr[i];
// // // // // //             arr[i] = arr[maxIdx];
// // // // // //             arr[maxIdx] = temp;

// // // // // //             // Recursively heapify the affected subtree
// // // // // //             heapify(arr, maxIdx, size);
// // // // // //         }
// // // // // //     }

// // // // // //     // Heap Sort
// // // // // //     public static void heapSort(int arr[]) {
// // // // // //         int n = arr.length;

// // // // // //         // Step 1: Build max heap
// // // // // //         for (int i = n / 2 - 1; i >= 0; i--) {
// // // // // //             heapify(arr, i, n);
// // // // // //         }

// // // // // //         // Step 2: Extract elements from heap one by one
// // // // // //         for (int i = n - 1; i > 0; i--) {
// // // // // //             // Swap first (largest) with last
// // // // // //             int temp = arr[0];
// // // // // //             arr[0] = arr[i];
// // // // // //             arr[i] = temp;

// // // // // //             // Heapify the reduced heap
// // // // // //             heapify(arr, 0, i);
// // // // // //         }
// // // // // //     }

// // // // // //     public static void main(String[] args) {
// // // // // //         int arr[] = {4, 10, 3, 5, 1};

// // // // // //         heapSort(arr);

// // // // // //         System.out.println("Sorted array:");
// // // // // //         for (int i = 0; i < arr.length; i++)
// // // // // //             System.out.print(arr[i] + " ");
// // // // // //     }
// // // // // // }

























// // // // // import java.util.*;

// // // // // public class Classroom {

// // // // //     // Point class implementing Comparable
// // // // //     static class Point implements Comparable<Point> {
// // // // //         int x, y;
// // // // //         int distSq; // distance squared from origin

// // // // //         public Point(int x, int y) {
// // // // //             this.x = x;
// // // // //             this.y = y;
// // // // //             this.distSq = x * x + y * y; // calculate distance squared
// // // // //         }

// // // // //         // Compare points based on distance squared
// // // // //         @Override
// // // // //         public int compareTo(Point p2) {
// // // // //             return this.distSq - p2.distSq; // min-heap behavior
// // // // //         }

// // // // //         @Override
// // // // //         public String toString() {
// // // // //             return "(" + x + "," + y + ")";
// // // // //         }
// // // // //     }

// // // // //     // Method to find K closest points
// // // // //     public static List<Point> kClosestPoints(int[][] pts, int k) {
// // // // //         PriorityQueue<Point> pq = new PriorityQueue<>();
// // // // //         for (int i = 0; i < pts.length; i++) {
// // // // //             pq.add(new Point(pts[i][0], pts[i][1]));
// // // // //         }

// // // // //         List<Point> result = new ArrayList<>();
// // // // //         for (int i = 0; i < k; i++) {
// // // // //             result.add(pq.poll());
// // // // //         }

// // // // //         return result;
// // // // //     }

// // // // //     public static void main(String[] args) {
// // // // //         int[][] pts = { {1, 3}, {3, 4}, {2, -1}, {5, 2} };
// // // // //         int k = 2;

// // // // //         List<Point> closest = kClosestPoints(pts, k);

// // // // //         System.out.println("The " + k + " closest points to origin:");
// // // // //         for (Point p : closest) {
// // // // //             System.out.println(p);
// // // // //         }
// // // // //     }
// // // // // }













// // // // // Connect N Ropes
// // // // //  Given are N ropes of different lengths, the task is to connect these ropes into one rope with minimum cost, such that the cost to connect two ropes is equal to the sum of their lengths. 
// // // // //  ropes = (4, 3, 2, 6)
// // // // //   ans = 29 
// // // // //   connect 2 & 3 [5]
// // // // //    connect 5 & 4 [9]
// // // // //     connect 9 & 6 [15]


// // // // import java.util.PriorityQueue;

// // // // public class Classroom {
// // // //     public static void main(String[] args) {
// // // //         int[] ropes = {4, 3, 2, 6};

// // // //         // Min-heap to always get the smallest ropes
// // // //         PriorityQueue<Integer> pq = new PriorityQueue<>();
// // // //         for (int i = 0; i < ropes.length; i++) {
// // // //             pq.add(ropes[i]);
// // // //         }

// // // //         int cost = 0;

// // // //         while (pq.size() > 1) {
// // // //             int min1 = pq.remove(); // smallest rope
// // // //             int min2 = pq.remove(); // second smallest rope

// // // //             int sum = min1 + min2;  // cost of connecting these two
// // // //             cost += sum;

// // // //             pq.add(sum); // add the combined rope back
// // // //         }

// // // //         System.out.println("Cost of connecting all ropes = " + cost);
// // // //     }
// // // // }




// // // Weakest Soldier
// // // We are given an mxn binary matrix of I's (soldiers) and 0's (civilians). The soldiers are
// // // positioned in front of the civilians. That is, all the I's will appear to the left of all the 0's
// // // in each row.
// // // A row i is weaker than a row j if one of the following is true:
// // // • The number of soldiers in row i is less than the number of soldiers in row j.
// // // • Both rows have the same number of soldiers and i < j.
// // // Find the K weakest rows.
// // // m=4, n=4,
// // // 1000
// // // 1000
// // // 1000
// // // ans = row0 & row2

// // import java.util.*;

// // public class Classroom {

// //     // Row class implementing Comparable to sort by soldiers count and index
// //     static class Row implements Comparable<Row> {
// //         int soldiers; // number of soldiers in this row
// //         int idx;      // row index

// //         public Row(int soldiers, int idx) {
// //             this.soldiers = soldiers;
// //             this.idx = idx;
// //         }

// //         @Override
// //         public int compareTo(Row r2) {
// //             // First compare by number of soldiers
// //             if (this.soldiers != r2.soldiers)
// //                 return this.soldiers - r2.soldiers; // fewer soldiers comes first
// //             else
// //                 return this.idx - r2.idx;           // if equal, smaller index comes first
// //         }
// //     }

// //     // Count soldiers (1's) in a row
// //     public static int countSoldiers(int[] row) {
// //         int count = 0;
// //         for (int val : row) {
// //             if (val == 1)
// //                 count++;
// //             else
// //                 break; // soldiers always come first
// //         }
// //         return count;
// //     }

// //     // Find K weakest rows
// //     public static int[] kWeakestRows(int[][] mat, int k) {
// //         int m = mat.length;
// //         PriorityQueue<Row> pq = new PriorityQueue<>();

// //         for (int i = 0; i < m; i++) {
// //             int soldiers = countSoldiers(mat[i]);
// //             pq.add(new Row(soldiers, i));
// //         }

// //         int[] result = new int[k];
// //         for (int i = 0; i < k; i++) {
// //             result[i] = pq.poll().idx;
// //         }

// //         return result;
// //     }

// //     public static void main(String[] args) {
// //         int[][] mat = {
// //             {1, 0, 0, 0},
// //             {1, 0, 0, 0},
// //             {1, 0, 0, 0},
// //             {1, 0, 0, 0}
// //         };

// //         int k = 2;
// //         int[] weakest = kWeakestRows(mat, k);

// //         System.out.println("The " + k + " weakest rows are:");
// //         for (int idx : weakest) {
// //             System.out.println("row " + idx);
// //         }
// //     }
// // }
















// //Slding window max
// import java.util.*;

// public class Classroom {

//     // Pair class to store value and index
//     static class Pair implements Comparable<Pair> {
//         int val; // value of element
//         int idx; // index in array

//         public Pair(int val, int idx) {
//             this.val = val;
//             this.idx = idx;
//         }

//         // Max-heap: larger value comes first
//         @Override
//         public int compareTo(Pair p2) {
//             return p2.val - this.val; // descending order
//         }
//     }

//     public static int[] maxOfSubarrays(int[] arr, int k) {
//         int n = arr.length;
//         int[] res = new int[n - k + 1]; // result array
//         PriorityQueue<Pair> pq = new PriorityQueue<>();

//         // 1st window
//         for (int i = 0; i < k; i++) {
//             pq.add(new Pair(arr[i], i));
//         }
//         res[0] = pq.peek().val;

//         // Remaining windows
//         for (int i = k; i < n; i++) {
//             // Remove elements out of current window
//             while (!pq.isEmpty() && pq.peek().idx <= i - k) {
//                 pq.remove();
//             }

//             // Add new element
//             pq.add(new Pair(arr[i], i));

//             // Current max
//             res[i - k + 1] = pq.peek().val;
//         }

//         return res;
//     }

//     public static void main(String[] args) {
//         int[] arr = {1, 3, -1, -3, 5, 3, 6, 7};
//         int k = 3;

//         int[] result = maxOfSubarrays(arr, k);

//         System.out.println("Maximum of all subarrays of size " + k + ":");
//         for (int val : result) {
//             System.out.print(val + " ");
//         }
//     }
// }










