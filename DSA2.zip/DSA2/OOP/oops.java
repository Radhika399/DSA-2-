// package oops;
// // // Encapsulation
// // class Student {
// //     private String name;
    
// //     //Getter method
// //     public String getName () {
// //         return name;
// //     }
// //     //Setter method
// //     public void setName(String name)
// // {
// //     this.name=name;
// // }}

// // public class oops {
// //     public static void main (String[]args){
// //         Student s = new Student();
// //         s.setName("Radhika");
// //         System.out.println("Student name is "+s.getName());
// //     }
// // }
// // //

// //========================================================

// //Inhertance 
// // class Animal {
// //     void sound() {
// //         System.out.println("Animal makes a sound");
// //     }
// // }

// // class Dog extends Animal {
// //     void bark() {
// //         System.out.println("Dog barks");
// //     }
// // }

// // public class Main {
// //     public static void main(String[] args) {
// //         Dog d = new Dog();
// //         d.sound(); // Inherited from Animal
// //         d.bark();  // Dog's own method
// //     }
// // }

// //=====================================================


// //polymorphism
// // class Animal {
// //     void sound (){
// //         System.out.println("Animal sound");

// //     }
// // }
// // class Cat extends Animal{
// //     void sound (){
// //         System.out.println("Cat meows");
// //     }
// // }

// // public class Main {
// //     public static void main (String []args){
// //         Animal a = new Cat();  // Upcasting 
// //         a.sound ();            // calls overridden method 
// //     }
// // }

// //=================================


// // //Abstraction
// // abstract class Shape{
// //     abstract void draw();
// // }
// // class Circle extends Shape {
// //     void draw(){
// //         System.out.println("Drawing circle ");
// //     }
// // }

// // public class Main {
// //     public static void main (String []args){
// //         Shape s= new Circle ():
// //         s.draw();
// //     }
// // }
// //=====
// // interface Vehicle {
// //     void drive();
// // }

// // class Car implements Vehicle {
// //     public void drive() {
// //         System.out.println("Car is driving");
// //     }
// // }

// // public class Main {
// //     public static void main(String[] args) {
// //         Vehicle v = new Car();
// //         v.drive();
// //     }
// // }
