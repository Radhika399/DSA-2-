//package Queue;
// // // import java.util.*;

// // // public class q {

// // //     public static void reverseQueue(Queue<Integer> q) {
// // //         Stack<Integer> s = new Stack<>();

// // //         // Step 1: Push all elements into stack
// // //         while (!q.isEmpty()) {
// // //             s.push(q.remove());
// // //         }

// // //         // Step 2: Pop from stack back into queue
// // //         while (!s.isEmpty()) {
// // //             q.add(s.pop());
// // //         }
// // //     }

// // //     public static void main(String[] args) {
// // //         Queue<Integer> q = new LinkedList<>();

// // //         // Original queue: 1,2,3,4,5
// // //         for (int i = 1; i <= 5; i++) {
// // //             q.add(i);
// // //         }

// // //         System.out.println("Original queue: " + q);

// // //         reverseQueue(q);

// // //         System.out.println("Reversed queue: " + q);
// // //     }
// // // }


// // //deque using linked list

// // import java.util.*;

// // public class DequeExample {
// //     public static void main(String[] args) {
// //         Deque<Integer> dq = new ArrayDeque<>();

// //         // Add elements
// //         dq.addFirst(10); // front
// //         dq.addLast(20);  // rear
// //         dq.addFirst(5);  // front
// //         dq.addLast(25);  // rear

// //         System.out.println("Deque: " + dq);

// //         // Peek elements
// //         System.out.println("First element: " + dq.getFirst());
// //         System.out.println("Last element: " + dq.getLast());

// //         // Remove elements
// //         dq.removeFirst(); // removes 5
// //         dq.removeLast();  // removes 25

// //         System.out.println("Deque after removals: " + dq);
// //         System.out.println("First element now: " + dq.getFirst());
// //         System.out.println("Last element now: " + dq.getLast());
// //     }
// // }



// import java.util.Deque;
// import java.util.LinkedList;

// public class Classroom {

//     // Stack using Deque
//     static class Stack {
//         Deque<Integer> deque = new LinkedList<>();

//         // push element
//         public void push(int data) {
//             deque.addLast(data);
//         }

//         // pop element
//         public int pop() {
//             if (deque.isEmpty()) {
//                 System.out.println("Stack is empty");
//                 return -1;
//             }
//             return deque.removeLast();
//         }

//         // peek top element
//         public int peek() {
//             if (deque.isEmpty()) {
//                 System.out.println("Stack is empty");
//                 return -1;
//             }
//             return deque.getLast();
//         }
//     }

//     // Queue using Deque
//     static class Queue {
//         Deque<Integer> deque = new LinkedList<>();

//         // add element
//         public void add(int data) {
//             deque.addLast(data);
//         }

//         // remove element
//         public int remove() {
//             if (deque.isEmpty()) {
//                 System.out.println("Queue is empty");
//                 return -1;
//             }
//             return deque.removeFirst();
//         }

//         // peek front element
//         public int peek() {
//             if (deque.isEmpty()) {
//                 System.out.println("Queue is empty");
//                 return -1;
//             }
//             return deque.getFirst();
//         }
//     }

//     public static void main(String[] args) {
//         // Test Stack
//         Stack s = new Stack();
//         s.push(1);
//         s.push(2);
//         s.push(3);
//         System.out.println("Stack peek: " + s.peek());
//         System.out.println("Stack pop: " + s.pop());
//         System.out.println("Stack pop: " + s.pop());

//         // Test Queue
//         Queue q = new Queue();
//         q.add(10);
//         q.add(20);
//         q.add(30);
//         System.out.println("Queue peek: " + q.peek());
//         System.out.println("Queue remove: " + q.remove());
//         System.out.println("Queue remove: " + q.remove());
//     }
// }
