//package Queue;
// // // // // // // // public class QueueB {
// // // // // // // //     static class Queue {
// // // // // // // //         static int arr[];
// // // // // // // //         static int size;
// // // // // // // //         static int rear;

// // // // // // // //         Queue(int n) {
// // // // // // // //             arr = new int[n];
// // // // // // // //             size = n;
// // // // // // // //             rear = -1;
// // // // // // // //         }

// // // // // // // //         // check if queue is empty
// // // // // // // //         public static boolean isEmpty() {
// // // // // // // //             return rear == -1;
// // // // // // // //         }

// // // // // // // //         // add element to queue
// // // // // // // //         public static void add(int data) {
// // // // // // // //             if (rear == size - 1) {
// // // // // // // //                 System.out.println("Queue is full");
// // // // // // // //                 return;
// // // // // // // //             }
// // // // // // // //             rear++;
// // // // // // // //             arr[rear] = data;
// // // // // // // //         }

// // // // // // // //         // remove element from queue
// // // // // // // //         public static int remove() {
// // // // // // // //             if (isEmpty()) {
// // // // // // // //                 System.out.println("Queue is empty");
// // // // // // // //                 return -1;
// // // // // // // //             }
// // // // // // // //             int front = arr[0];
// // // // // // // //             for (int i = 0; i < rear; i++) {
// // // // // // // //                 arr[i] = arr[i + 1];
// // // // // // // //             }
// // // // // // // //             rear--;
// // // // // // // //             return front;
// // // // // // // //         }

// // // // // // // //         // peek element at front
// // // // // // // //         public static int peek() {
// // // // // // // //             if (isEmpty()) {
// // // // // // // //                 System.out.println("Queue is empty");
// // // // // // // //                 return -1;
// // // // // // // //             }
// // // // // // // //             return arr[0];
// // // // // // // //         }
// // // // // // // //     }

// // // // // // // //     public static void main(String args[]) {
// // // // // // // //         Queue q = new Queue(5);
// // // // // // // //         q.add(1);
// // // // // // // //         q.add(2);
// // // // // // // //         q.add(3);

// // // // // // // //         System.out.println("Peek: " + q.peek());

// // // // // // // //         System.out.println("Removed: " + q.remove());
// // // // // // // //         System.out.println("Peek after remove: " + q.peek());

// // // // // // // //         q.add(4);
// // // // // // // //         q.add(5);
// // // // // // // //         q.add(6); // should show "Queue is full"

// // // // // // // //         while (!q.isEmpty()) {
// // // // // // // //             System.out.println("Removed: " + q.remove());
// // // // // // // //         }

// // // // // // // //         q.remove(); // should show "Queue is empty"
// // // // // // // //     }
// // // // // // // // }

// // // // // // //======================================================================================


// // // // // // // public class CircularQueue {
// // // // // // //     static class Queue {
// // // // // // //         int arr[];
// // // // // // //         int size;
// // // // // // //         int front;
// // // // // // //         int rear;

// // // // // // //         Queue(int n) {
// // // // // // //             arr = new int[n];
// // // // // // //             size = n;
// // // // // // //             front = -1;
// // // // // // //             rear = -1;
// // // // // // //         }

// // // // // // //         // check if queue is empty
// // // // // // //         public boolean isEmpty() {
// // // // // // //             return front == -1;
// // // // // // //         }

// // // // // // //         // check if queue is full
// // // // // // //         public boolean isFull() {
// // // // // // //             return (rear + 1) % size == front;
// // // // // // //         }

// // // // // // //         // add element
// // // // // // //         public void add(int data) {
// // // // // // //             if (isFull()) {
// // // // // // //                 System.out.println("Queue is full");
// // // // // // //                 return;
// // // // // // //             }
// // // // // // //             // first element
// // // // // // //             if (front == -1) {
// // // // // // //                 front = 0;
// // // // // // //             }
// // // // // // //             rear = (rear + 1) % size;
// // // // // // //             arr[rear] = data;
// // // // // // //             System.out.println("Inserted: " + data);
// // // // // // //         }

// // // // // // //         // remove element
// // // // // // //         public int remove() {
// // // // // // //             if (isEmpty()) {
// // // // // // //                 System.out.println("Queue is empty");
// // // // // // //                 return -1;
// // // // // // //             }
// // // // // // //             int result = arr[front];
// // // // // // //             // last element
// // // // // // //             if (front == rear) {
// // // // // // //                 front = -1;
// // // // // // //                 rear = -1;
// // // // // // //             } else {
// // // // // // //                 front = (front + 1) % size;
// // // // // // //             }
// // // // // // //             return result;
// // // // // // //         }

// // // // // // //         // peek front
// // // // // // //         public int peek() {
// // // // // // //             if (isEmpty()) {
// // // // // // //                 System.out.println("Queue is empty");
// // // // // // //                 return -1;
// // // // // // //             }
// // // // // // //             return arr[front];
// // // // // // //         }
// // // // // // //     }

// // // // // // //     public static void main(String args[]) {
// // // // // // //         Queue q = new Queue(3);

// // // // // // //         q.add(1);
// // // // // // //         q.add(2);
// // // // // // //         q.add(3);
// // // // // // //         q.add(4); // should show "Queue is full"

// // // // // // //         System.out.println("Removed: " + q.remove());
// // // // // // //         q.add(4);

// // // // // // //         while (!q.isEmpty()) {
// // // // // // //             System.out.println("Removed: " + q.remove());
// // // // // // //         }

// // // // // // //         q.remove(); // should show "Queue is empty"
// // // // // // //     }
// // // // // // // }


// // // // // // public class QueueB {
// // // // // //     // Node class
// // // // // //     static class Node {
// // // // // //         int data;
// // // // // //         Node next;

// // // // // //         Node(int data) {
// // // // // //             this.data = data;
// // // // // //             this.next = null;
// // // // // //         }
// // // // // //     }

// // // // // //     // Queue class
// // // // // //     static class Queue {
// // // // // //         Node head = null; // front
// // // // // //         Node tail = null; // rear

// // // // // //         // check if queue is empty
// // // // // //         public boolean isEmpty() {
// // // // // //             return head == null;
// // // // // //         }

// // // // // //         // add element to queue
// // // // // //         public void add(int data) {
// // // // // //             Node newNode = new Node(data);
// // // // // //             if (tail == null) {
// // // // // //                 // first element
// // // // // //                 head = tail = newNode;
// // // // // //                 return;
// // // // // //             }
// // // // // //             tail.next = newNode;
// // // // // //             tail = newNode;
// // // // // //         }

// // // // // //         // remove element from queue
// // // // // //         public int remove() {
// // // // // //             if (isEmpty()) {
// // // // // //                 System.out.println("Queue is empty");
// // // // // //                 return -1;
// // // // // //             }
// // // // // //             int front = head.data;
// // // // // //             // single element
// // // // // //             if (head == tail) {
// // // // // //                 head = tail = null;
// // // // // //             } else {
// // // // // //                 head = head.next;
// // // // // //             }
// // // // // //             return front;
// // // // // //         }

// // // // // //         // peek front element
// // // // // //         public int peek() {
// // // // // //             if (isEmpty()) {
// // // // // //                 System.out.println("Queue is empty");
// // // // // //                 return -1;
// // // // // //             }
// // // // // //             return head.data;
// // // // // //         }
// // // // // //     }

// // // // // //     public static void main(String args[]) {
// // // // // //         Queue q = new Queue();
// // // // // //         q.add(1);
// // // // // //         q.add(2);
// // // // // //         q.add(3);

// // // // // //         System.out.println("Front element: " + q.peek());

// // // // // //         while (!q.isEmpty()) {
// // // // // //             System.out.println("Removed: " + q.remove());
// // // // // //         }

// // // // // //         q.remove(); // should show "Queue is empty"
// // // // // //     }
// // // // // // }

// // // // // import java.util.*;

// // // // // public class QueueB {
// // // // //     public static void main(String[] args) {
// // // // //         // Using Java Collection Framework's Queue
// // // // //         Queue<Integer> q = new ArrayDeque<>();

// // // // //         // Add elements to the queue
// // // // //         q.add(1);
// // // // //         q.add(2);
// // // // //         q.add(3);

// // // // //         System.out.println("Queue elements:");
// // // // //         while (!q.isEmpty()) {
// // // // //             System.out.println(q.peek()); // view front element
// // // // //             q.remove();                   // remove front element
// // // // //         }

// // // // //         // Trying to remove from empty queue
// // // // //         if (q.isEmpty()) {
// // // // //             System.out.println("Queue is empty now!");
// // // // //         }
// // // // //     }
// // // // // }


// // // // import java.util.Stack;

// // // // public class QueueB {
// // // //     static class Queue {
// // // //         static Stack<Integer> s1 = new Stack<>();
// // // //         static Stack<Integer> s2 = new Stack<>();

// // // //         // check if queue is empty
// // // //         public static boolean isEmpty() {
// // // //             return s1.isEmpty() && s2.isEmpty();
// // // //         }

// // // //         // add element to queue
// // // //         public static void add(int data) {
// // // //             // push all elements to s1
// // // //             s1.push(data);
// // // //         }

// // // //         // remove element from queue
// // // //         public static int remove() {
// // // //             if (isEmpty()) {
// // // //                 System.out.println("Queue is empty");
// // // //                 return -1;
// // // //             }

// // // //             // if s2 is empty, move all elements from s1 to s2
// // // //             if (s2.isEmpty()) {
// // // //                 while (!s1.isEmpty()) {
// // // //                     s2.push(s1.pop());
// // // //                 }
// // // //             }

// // // //             return s2.pop(); // remove from front
// // // //         }

// // // //         // peek front element
// // // //         public static int peek() {
// // // //             if (isEmpty()) {
// // // //                 System.out.println("Queue is empty");
// // // //                 return -1;
// // // //             }

// // // //             if (s2.isEmpty()) {
// // // //                 while (!s1.isEmpty()) {
// // // //                     s2.push(s1.pop());
// // // //                 }
// // // //             }

// // // //             return s2.peek();
// // // //         }
// // // //     }

// // // //     public static void main(String[] args) {
// // // //         Queue q = new Queue();

// // // //         // Add elements
// // // //         q.add(1);
// // // //         q.add(2);
// // // //         q.add(3);

// // // //         System.out.println("Queue elements:");
// // // //         while (!q.isEmpty()) {
// // // //             System.out.println(q.peek()); // view front
// // // //             q.remove();                  // remove front
// // // //         }

// // // //         // Try removing from empty queue
// // // //         q.remove(); // prints "Queue is empty"
// // // //     }
// // // // }




// // // import java.util.Stack;

// // // public class MyStack {
// // //     static class StackClass {
// // //         Stack<Integer> stack = new Stack<>();

// // //         // push element
// // //         public void push(int data) {
// // //             stack.push(data);
// // //             System.out.println("Pushed: " + data);
// // //         }

// // //         // pop element
// // //         public int pop() {
// // //             if (stack.isEmpty()) {
// // //                 System.out.println("Stack is empty");
// // //                 return -1;
// // //             }
// // //             return stack.pop();
// // //         }

// // //         // peek top element
// // //         public int peek() {
// // //             if (stack.isEmpty()) {
// // //                 System.out.println("Stack is empty");
// // //                 return -1;
// // //             }
// // //             return stack.peek();
// // //         }

// // //         // check if stack is empty
// // //         public boolean isEmpty() {
// // //             return stack.isEmpty();
// // //         }
// // //     }

// // //     public static void main(String[] args) {
// // //         StackClass s = new StackClass();

// // //         s.push(10);
// // //         s.push(20);
// // //         s.push(30);

// // //         System.out.println("Top element: " + s.peek());

// // //         while (!s.isEmpty()) {
// // //             System.out.println("Popped: " + s.pop());
// // //         }

// // //         s.pop(); // stack is empty
// // //     }
// // // }



// // import java.util.*;

// // public class Classroom {

// //     public static void printNonRepeating(String str) {
// //         int freq[] = new int[256]; // ASCII size
// //         Queue<Character> q = new LinkedList<>();

// //         for (int i = 0; i < str.length(); i++) {
// //             char ch = str.charAt(i);

// //             // add current char to queue
// //             q.add(ch);

// //             // update frequency
// //             freq[ch]++;

// //             // remove characters from front that are repeating
// //             while (!q.isEmpty() && freq[q.peek()] > 1) {
// //                 q.remove();
// //             }

// //             // print first non-repeating character
// //             if (q.isEmpty()) {
// //                 System.out.print("-1 ");
// //             } else {
// //                 System.out.print(q.peek() + " ");
// //             }
// //         }
// //     }

// //     public static void main(String[] args) {
// //         String str = "aabccxb";
// //         printNonRepeating(str);
// //     }
// // }


// import java.util.*;

// public class Classroom {

//     public static void interLeave(Queue<Integer> q) {
//         if (q.size() % 2 != 0) {
//             System.out.println("Queue length must be even.");
//             return;
//         }

//         int halfSize = q.size() / 2;
//         Queue<Integer> firstHalf = new LinkedList<>();

//         // Step 1: Put first half in a separate queue
//         for (int i = 0; i < halfSize; i++) {
//             firstHalf.add(q.remove());
//         }

//         // Step 2: Interleave elements
//         while (!firstHalf.isEmpty()) {
//             // take from first half
//             q.add(firstHalf.remove());
//             // take from second half (remaining in q)
//             q.add(q.remove());
//         }
//     }

//     public static void main(String[] args) {
//         Queue<Integer> q = new LinkedList<>();
//         for (int i = 1; i <= 10; i++) {
//             q.add(i);
//         }

//         System.out.println("Original queue: " + q);
//         interLeave(q);
//         System.out.println("Interleaved queue: " + q);
//     }
// }
