
// //Activity Selection Problem.
// import java.util.*;

// public class Classroom {

//     public static void main(String[] args) {
//         // Activity start and end times
//         int start[] = {10, 12, 20};
//         int end[] = {20, 25, 30};

//         // Call activity selection
//         activitySelection(start, end);
//     }

//     public static void activitySelection(int start[], int end[]) {
//         int n = start.length;

//         // Pair activity index with start and end time
//         int activities[][] = new int[n][3];
//         for (int i = 0; i < n; i++) {
//             activities[i][0] = i;      // index
//             activities[i][1] = start[i]; // start time
//             activities[i][2] = end[i];   // end time
//         }

//         // Sort activities by end time
//         Arrays.sort(activities, Comparator.comparingInt(a -> a[2]));

//         ArrayList<Integer> ans = new ArrayList<>();
//         int maxAct = 0;

//         // Select first activity
//         ans.add(activities[0][0]);
//         maxAct = 1;
//         int lastEnd = activities[0][2];

//         // Select rest of the activities
//         for (int i = 1; i < n; i++) {
//             if (activities[i][1] >= lastEnd) {
//                 ans.add(activities[i][0]);
//                 maxAct++;
//                 lastEnd = activities[i][2];
//             }
//         }

//         // Print result
//         System.out.println("Maximum activities: " + maxAct);
//         System.out.print("Selected activity indices: ");
//         for (int idx : ans) {
//             System.out.print(idx + " ");
//         }
//     }
// }
