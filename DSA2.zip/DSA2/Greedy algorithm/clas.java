// import java.util.*;

// public class clas {

//     static class Item {
//         int value;
//         int weight;
//         double ratio;

//         Item(int value, int weight) {
//             this.value = value;
//             this.weight = weight;
//             this.ratio = (double) value / weight;
//         }
//     }

//     public static double fractionalKnapsack(int[] value, int[] weight, int W) {
//         int n = value.length;
//         Item[] items = new Item[n];

//         for (int i = 0; i < n; i++) {
//             items[i] = new Item(value[i], weight[i]);
//         }

//         // Sort items by value/weight ratio in descending order
//         Arrays.sort(items, (a, b) -> Double.compare(b.ratio, a.ratio));

//         double finalValue = 0;
//         int capacity = W;

//         for (int i = 0; i < n; i++) {
//             if (capacity >= items[i].weight) {
//                 // Include full item
//                 finalValue += items[i].value;
//                 capacity -= items[i].weight;
//             } else {
//                 // Include fractional item
//                 finalValue += items[i].ratio * capacity;
//                 capacity = 0;
//                 break;
//             }
//         }

//         return finalValue;
//     }

//     public static void main(String[] args) {
//         int[] value = {60, 100, 120};
//         int[] weight = {10, 20, 30};
//         int W = 50;

//         double maxValue = fractionalKnapsack(value, weight, W);
//         System.out.println("Maximum value in knapsack = " + maxValue);
//     }
// }
