// // // // // // // // import java.util.Arrays;

// // // // // // // // public class cla {

// // // // // // // //     public static int minAbsoluteDifferenceSum(int[] A, int[] B) {
// // // // // // // //         Arrays.sort(A);
// // // // // // // //         Arrays.sort(B);

// // // // // // // //         int minDiff = 0;
// // // // // // // //         for (int i = 0; i < A.length; i++) {
// // // // // // // //             minDiff += Math.abs(A[i] - B[i]);
// // // // // // // //         }

// // // // // // // //         return minDiff;
// // // // // // // //     }

// // // // // // // //     public static void main(String[] args) {
// // // // // // // //         int[] A = {1, 2, 3};
// // // // // // // //         int[] B = {2, 1, 3};

// // // // // // // //         int result = minAbsoluteDifferenceSum(A, B);
// // // // // // // //         System.out.println("Minimum sum of absolute differences = " + result);
// // // // // // // //     }
// // // // // // // // }



// // // // // // // Max Length Chain of Pairs
// // // // // // // You are given n pairs of numbers. In every pair, the first number is always smaller than the
// // // // // // // second number. A pair (c, d) can come after pair (a, b) if b < c.
// // // // // // // Find the longest chain which can be formed from a given set of pairs.
// // // // // // // pairs =
// // // // // // // (5, 24)
// // // // // // // (39, 60)
// // // // // // // (5, 28)
// // // // // // // (27, 40)
// // // // // // // (50, 90)

// // // // // // // ans : 3


// // // // // // import java.util.*;

// // // // // // public class MaxLengthChain {
// // // // // //     public static void main(String[] args) {
// // // // // //         // Input pairs
// // // // // //         int[][] pairs = {
// // // // // //             {5, 24},
// // // // // //             {39, 60},
// // // // // //             {5, 28},
// // // // // //             {27, 40},
// // // // // //             {50, 90}
// // // // // //         };

// // // // // //         // Step 1: Sort pairs based on the second element
// // // // // //         Arrays.sort(pairs, Comparator.comparingInt(o -> o[1]));

// // // // // //         // Step 2: Initialize
// // // // // //         int chainLen = 1;  // At least one pair is always possible
// // // // // //         int chainEnd = pairs[0][1]; // End of the first selected pair

// // // // // //         // Step 3: Iterate through pairs to build the chain
// // // // // //         for (int i = 1; i < pairs.length; i++) {
// // // // // //             if (pairs[i][0] > chainEnd) { // Can chain this pair
// // // // // //                 chainLen++;
// // // // // //                 chainEnd = pairs[i][1]; // Update the chain end
// // // // // //             }
// // // // // //         }

// // // // // //         // Step 4: Print result
// // // // // //         System.out.println("Max length of chain = " + chainLen);
// // // // // //     }
// // // // // // }



// // // // // // Indian Coins
// // // // // // [1, 2, 5, 10, 20, 50, 100, 500, 2000]
// // // // // // We are given an infinite supply of denominations
// // // // // // Find min no. of coinslnotes to make change for a value V.
// // // // // // v: 121
// // // // // // ans 3 (100+20+1)
// // // // // // v: 590
// // // // // // ans 4 (500+50+20+20)
// // // // // import java.util.*;

// // // // // public class Classroom {
// // // // //     public static void main(String[] args) {
// // // // //         Integer[] coins = {1, 2, 5, 10, 20, 50, 100, 500, 2000};
// // // // //         int amount = 590;

// // // // //         // Sort coins in descending order
// // // // //         Arrays.sort(coins, Collections.reverseOrder());

// // // // //         int countOfCoins = 0;
// // // // //         ArrayList<Integer> ans = new ArrayList<>();

// // // // //         // Greedy approach
// // // // //         for (int i = 0; i < coins.length; i++) {
// // // // //             while (coins[i] <= amount) {
// // // // //                 amount -= coins[i];
// // // // //                 countOfCoins++;
// // // // //                 ans.add(coins[i]);
// // // // //             }
// // // // //         }

// // // // //         // Output results
// // // // //         System.out.println("Total (min) coins used = " + countOfCoins);
// // // // //         System.out.print("Coins used: ");
// // // // //         for (int coin : ans) {
// // // // //             System.out.print(coin + " ");
// // // // //         }
// // // // //     }
// // // // // }


// // // // ### Problem

// // // // Given an array of jobs where each job has a **deadline** and **profit**.
// // // // Each job takes **1 unit of time**, and only one job can be scheduled at a time.
// // // // Maximize the total profit.

// // // // ---

// // // // ### Input

// // // // ```
// // // // Jobs:
// // // // A: deadline = 4, profit = 20
// // // // B: deadline = 1, profit = 10
// // // // C: deadline = 4, profit = 20
// // // // D: deadline = 1, profit = 30
// // // // ```

// // // // ---

// // // // ### Output

// // // // ```
// // // // Max profit = 40
// // // // Scheduled jobs = D, C
// // // // ```


// // // import java.util.*;

// // // class Job {
// // //     int id;
// // //     int deadline;
// // //     int profit;

// // //     public Job(int id, int deadline, int profit) {
// // //         this.id = id;
// // //         this.deadline = deadline;
// // //         this.profit = profit;
// // //     }
// // // }

// // // public class JobSequencing {
// // //     public static void main(String[] args) {
// // //         int[][] jobsInfo = {
// // //             {0, 4, 20},  // A
// // //             {1, 1, 10},  // B
// // //             {2, 4, 20},  // C
// // //             {3, 1, 30}   // D
// // //         };

// // //         ArrayList<Job> jobs = new ArrayList<>();
// // //         for (int i = 0; i < jobsInfo.length; i++) {
// // //             jobs.add(new Job(jobsInfo[i][0], jobsInfo[i][1], jobsInfo[i][2]));
// // //         }

// // //         // Sort jobs in descending order of profit
// // //         Collections.sort(jobs, (a, b) -> b.profit - a.profit);

// // //         ArrayList<Integer> seq = new ArrayList<>();
// // //         int time = 0;

// // //         for (Job curr : jobs) {
// // //             if (curr.deadline > time) {
// // //                 seq.add(curr.id);
// // //                 time++;
// // //             }
// // //         }

// // //         // Output
// // //         System.out.println("Max jobs = " + seq.size());
// // //         System.out.print("Scheduled job IDs: ");
// // //         for (int id : seq) {
// // //             System.out.print(id + " ");
// // //         }
// // //     }
// // // }


// // ### Problem

// // Given a chocolate bar of size `m × n` composed of square pieces.
// // Each break along a horizontal or vertical line has a **cost**.
// // Break the chocolate into **single squares** with **minimal total cost**.

// // ---

// // ### Input

// // ```
// // Vertical break costs: x1, x2, ..., xm-1
// // Horizontal break costs: y1, y2, ..., yn-1
// // ```

// // ---

// // ### Output

// // ```
// // Minimal total cost to break the chocolate into single squares
// // ```
// import java.util.*;

// public class Classroom {
//     public static void main(String[] args) {
//         int m = 4; // rows
//         int n = 6; // columns

//         // Cost of vertical cuts (m-1 cuts)
//         Integer[] costVer = {2, 1, 3}; // example
//         // Cost of horizontal cuts (n-1 cuts)
//         Integer[] costHor = {4, 1, 2}; // example

//         // Sort costs in descending order
//         Arrays.sort(costVer, Collections.reverseOrder());
//         Arrays.sort(costHor, Collections.reverseOrder());

//         int h = 0, v = 0;
//         int hp = 1, vp = 1; // horizontal and vertical pieces count
//         int totalCost = 0;

//         // Greedy approach: always take the maximum cost cut available
//         while (h < costHor.length && v < costVer.length) {
//             if (costHor[h] >= costVer[v]) {
//                 totalCost += costHor[h] * vp;
//                 hp++;
//                 h++;
//             } else {
//                 totalCost += costVer[v] * hp;
//                 vp++;
//                 v++;
//             }
//         }

//         // Remaining horizontal cuts
//         while (h < costHor.length) {
//             totalCost += costHor[h] * vp;
//             h++;
//         }

//         // Remaining vertical cuts
//         while (v < costVer.length) {
//             totalCost += costVer[v] * hp;
//             v++;
//         }

//         System.out.println("Minimal total cost = " + totalCost);
//     }
// }
