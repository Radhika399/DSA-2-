// // // // import java.util.*;

// // // // public class bst {

// // // //     // Node definition
// // // //     static class Node {
// // // //         int data;
// // // //         Node left, right;

// // // //         Node(int data) {
// // // //             this.data = data;
// // // //             left = right = null;
// // // //         }
// // // //     }

// // // //     // Insert into BST
// // // //     public static Node insert(Node root, int val) {
// // // //         if (root == null) {
// // // //             root = new Node(val);
// // // //             return root;
// // // //         }
// // // //         if (val < root.data) {
// // // //             root.left = insert(root.left, val);
// // // //         } else {
// // // //             root.right = insert(root.right, val);
// // // //         }
// // // //         return root;
// // // //     }

// // // //     // Inorder Traversal
// // // //     public static void inorder(Node root) {
// // // //         if (root == null) return;
// // // //         inorder(root.left);
// // // //         System.out.print(root.data + " ");
// // // //         inorder(root.right);
// // // //     }

// // // //     // Search in BST
// // // //     public static boolean search(Node root, int key) {
// // // //         if (root == null) return false;
// // // //         if (root.data == key) return true;
// // // //         if (key < root.data) return search(root.left, key);
// // // //         return search(root.right, key);
// // // //     }

// // // //     // Delete from BST
// // // //     public static Node delete(Node root, int val) {
// // // //         if (root == null) return null;

// // // //         if (val < root.data) {
// // // //             root.left = delete(root.left, val);
// // // //         } else if (val > root.data) {
// // // //             root.right = delete(root.right, val);
// // // //         } else {
// // // //             // Case 1: Leaf node
// // // //             if (root.left == null && root.right == null) {
// // // //                 return null;
// // // //             }
// // // //             // Case 2: One child
// // // //             if (root.left == null) {
// // // //                 return root.right;
// // // //             } else if (root.right == null) {
// // // //                 return root.left;
// // // //             }
// // // //             // Case 3: Two children
// // // //             Node inorderSuccessor = findInorderSuccessor(root.right);
// // // //             root.data = inorderSuccessor.data;
// // // //             root.right = delete(root.right, inorderSuccessor.data);
// // // //         }
// // // //         return root;
// // // //     }

// // // //     // Find inorder successor (minimum value in right subtree)
// // // //     public static Node findInorderSuccessor(Node root) {
// // // //         while (root.left != null) {
// // // //             root = root.left;
// // // //         }
// // // //         return root;
// // // //     }

// // // //     // Print values in a given range [k1, k2]
// // // //     public static void printRange(Node root, int k1, int k2) {
// // // //         if (root == null) return;

// // // //         if (root.data >= k1 && root.data <= k2) {
// // // //             printRange(root.left, k1, k2);
// // // //             System.out.print(root.data + " ");
// // // //             printRange(root.right, k1, k2);
// // // //         } else if (root.data < k1) {
// // // //             printRange(root.right, k1, k2);
// // // //         } else {
// // // //             printRange(root.left, k1, k2);
// // // //         }
// // // //     }

// // // //     // Print all root-to-leaf paths
// // // //     public static void printRootToLeaf(Node root, ArrayList<Integer> path) {
// // // //         if (root == null) return;

// // // //         // Add current node to path
// // // //         path.add(root.data);

// // // //         // Leaf node → print path
// // // //         if (root.left == null && root.right == null) {
// // // //             printPath(path);
// // // //         } else {
// // // //             // Continue for left and right
// // // //             printRootToLeaf(root.left, path);
// // // //             printRootToLeaf(root.right, path);
// // // //         }

// // // //         // Backtrack
// // // //         path.remove(path.size() - 1);
// // // //     }

// // // //     // Helper to print a path
// // // //     public static void printPath(ArrayList<Integer> path) {
// // // //         for (int val : path) {
// // // //             System.out.print(val + " ");
// // // //         }
// // // //         System.out.println();
// // // //     }

// // // //     // Check if a tree is a valid BST
// // // //     public static boolean isValidBST(Node root, Node min, Node max) {
// // // //         if (root == null) return true;

// // // //         if (min != null && root.data <= min.data) return false;
// // // //         if (max != null && root.data >= max.data) return false;

// // // //         return isValidBST(root.left, min, root) &&
// // // //                isValidBST(root.right, root, max);
// // // //     }

// // // //     // Main function
// // // //     public static void main(String[] args) {
// // // //         int values[] = {8, 5, 3, 1, 4, 6, 10, 11, 14};
// // // //         Node root = null;

// // // //         // Insert values
// // // //         for (int val : values) {
// // // //             root = insert(root, val);
// // // //         }

// // // //         // Inorder before deletion
// // // //         System.out.print("Inorder Traversal: ");
// // // //         inorder(root);
// // // //         System.out.println();

// // // //         // Delete a node
// // // //         root = delete(root, 1);
// // // //         System.out.print("After deleting 1: ");
// // // //         inorder(root);
// // // //         System.out.println();

// // // //         // Print range
// // // //         System.out.print("Values in range [5, 12]: ");
// // // //         printRange(root, 5, 12);
// // // //         System.out.println();

// // // //         // Print root-to-leaf paths
// // // //         System.out.println("Root-to-leaf paths:");
// // // //         printRootToLeaf(root, new ArrayList<>());

// // // //         // Check if valid BST
// // // //         System.out.println("Is valid BST? " + isValidBST(root, null, null));
// // // //     }
// // // // }














// // // public class Classroom {

// // //     // Node definition
// // //     static class Node {
// // //         int data;
// // //         Node left, right;

// // //         public Node(int data) {
// // //             this.data = data;
// // //             this.left = null;
// // //             this.right = null;
// // //         }
// // //     }

// // //     // Create mirror of a tree
// // //     public static Node createMirror(Node root) {
// // //         if (root == null) {
// // //             return null;
// // //         }

// // //         // Recursively create mirrors
// // //         Node leftMirror = createMirror(root.left);
// // //         Node rightMirror = createMirror(root.right);

// // //         // Swap
// // //         root.left = rightMirror;
// // //         root.right = leftMirror;

// // //         return root;
// // //     }

// // //     // Preorder traversal
// // //     public static void preorder(Node root) {
// // //         if (root == null) {
// // //             return;
// // //         }
// // //         System.out.print(root.data + " ");
// // //         preorder(root.left);
// // //         preorder(root.right);
// // //     }

// // //     // Main function
// // //     public static void main(String[] args) {
// // //         // Create tree manually
// // //         Node root = new Node(8);
// // //         root.left = new Node(5);
// // //         root.right = new Node(10);
// // //         root.left.left = new Node(3);
// // //         root.left.right = new Node(6);
// // //         root.right.right = new Node(11);

// // //         // Preorder before mirroring
// // //         System.out.print("Preorder (Original): ");
// // //         preorder(root);
// // //         System.out.println();

// // //         // Mirror the tree
// // //         createMirror(root);

// // //         // Preorder after mirroring
// // //         System.out.print("Preorder (Mirror): ");
// // //         preorder(root);
// // //         System.out.println();
// // //     }
// // // }



// // // Original Tree (before createMirror)
// // //         8
// // //        / \
// // //       5   10
// // //      / \     \
// // //     3   6     11

// // // Mirror Tree (after createMirror)
// // //         8
// // //        / \
// // //      10    5
// // //     /    / \
// // //    11   6   3





// // import java.util.*;

// // public class AdvancedBST {

// //     // Node definition
// //     static class Node {
// //         int data;
// //         Node left, right;
// //         public Node(int data) {
// //             this.data = data;
// //             this.left = this.right = null;
// //         }
// //     }

// //     // 1. Create Balanced BST from Sorted Array
// //     public static Node createBST(int arr[], int st, int end) {
// //         if (st > end) return null;
// //         int mid = (st + end) / 2;
// //         Node root = new Node(arr[mid]);
// //         root.left = createBST(arr, st, mid - 1);
// //         root.right = createBST(arr, mid + 1, end);
// //         return root;
// //     }

// //     // 2. Inorder Traversal to get sorted sequence
// //     public static void getInorder(Node root, ArrayList<Integer> inorder) {
// //         if (root == null) return;
// //         getInorder(root.left, inorder);
// //         inorder.add(root.data);
// //         getInorder(root.right, inorder);
// //     }

// //     // 3. Balance an existing BST
// //     public static Node balanceBST(Node root) {
// //         ArrayList<Integer> inorder = new ArrayList<>();
// //         getInorder(root, inorder);
// //         return createBST(inorder.stream().mapToInt(i -> i).toArray(), 0, inorder.size() - 1);
// //     }

// //     // Preorder Traversal
// //     public static void preorder(Node root) {
// //         if (root == null) return;
// //         System.out.print(root.data + " ");
// //         preorder(root.left);
// //         preorder(root.right);
// //     }

// //     // ================================
// //     // 4. Largest BST in a Binary Tree
// //     // ================================
// //     static class Info {
// //         boolean isBST;
// //         int size, min, max;
// //         Info(boolean isBST, int size, int min, int max) {
// //             this.isBST = isBST;
// //             this.size = size;
// //             this.min = min;
// //             this.max = max;
// //         }
// //     }

// //     static int maxBST = 0;

// //     public static Info largestBST(Node root) {
// //         if (root == null) {
// //             return new Info(true, 0, Integer.MAX_VALUE, Integer.MIN_VALUE);
// //         }

// //         Info leftInfo = largestBST(root.left);
// //         Info rightInfo = largestBST(root.right);

// //         int size = leftInfo.size + rightInfo.size + 1;
// //         int min = Math.min(root.data, Math.min(leftInfo.min, rightInfo.min));
// //         int max = Math.max(root.data, Math.max(leftInfo.max, rightInfo.max));

// //         if (leftInfo.isBST && rightInfo.isBST &&
// //             root.data > leftInfo.max && root.data < rightInfo.min) {
// //             maxBST = Math.max(maxBST, size);
// //             return new Info(true, size, min, max);
// //         }

// //         return new Info(false, size, min, max);
// //     }

// //     // ================================
// //     // Main
// //     // ================================
// //     public static void main(String[] args) {
// //         // Example 1: Create balanced BST from sorted array
// //         int arr[] = {3, 5, 6, 8, 10, 11, 12};
// //         Node balancedRoot = createBST(arr, 0, arr.length - 1);
// //         System.out.print("Balanced BST Preorder: ");
// //         preorder(balancedRoot);
// //         System.out.println();

// //         // Example 2: Balance an unbalanced BST
// //         Node root = new Node(8);
// //         root.left = new Node(6);
// //         root.left.left = new Node(5);
// //         root.left.left.left = new Node(3);
// //         root.right = new Node(10);
// //         root.right.right = new Node(11);
// //         root.right.right.right = new Node(12);

// //         System.out.print("Unbalanced BST Preorder: ");
// //         preorder(root);
// //         System.out.println();

// //         root = balanceBST(root);
// //         System.out.print("Balanced BST Preorder (after fixing): ");
// //         preorder(root);
// //         System.out.println();

// //         // Example 3: Largest BST in a Binary Tree
// //         Node tree = new Node(50);
// //         tree.left = new Node(30);
// //         tree.left.left = new Node(5);
// //         tree.left.right = new Node(20); // breaks BST
// //         tree.right = new Node(60);
// //         tree.right.left = new Node(45);
// //         tree.right.right = new Node(70);
// //         tree.right.right.left = new Node(65);
// //         tree.right.right.right = new Node(80);

// //         maxBST = 0;
// //         largestBST(tree);
// //         System.out.println("Size of Largest BST in tree: " + maxBST);
// //     }
// // }























// import java.util.*;

// public class Classroom {

//     static class Node {
//         int data;
//         Node left, right;
//         Node(int data) {
//             this.data = data;
//             this.left = null;
//             this.right = null;
//         }
//     }

//     // Get inorder traversal of BST
//     public static void getInorder(Node root, ArrayList<Integer> arr) {
//         if (root == null) return;
//         getInorder(root.left, arr);
//         arr.add(root.data);
//         getInorder(root.right, arr);
//     }

//     // Merge two sorted arrays
//     public static ArrayList<Integer> mergeArrays(ArrayList<Integer> arr1, ArrayList<Integer> arr2) {
//         ArrayList<Integer> merged = new ArrayList<>();
//         int i = 0, j = 0;
//         while (i < arr1.size() && j < arr2.size()) {
//             if (arr1.get(i) < arr2.get(j)) {
//                 merged.add(arr1.get(i++));
//             } else {
//                 merged.add(arr2.get(j++));
//             }
//         }
//         while (i < arr1.size()) merged.add(arr1.get(i++));
//         while (j < arr2.size()) merged.add(arr2.get(j++));
//         return merged;
//     }

//     // Convert sorted array to balanced BST
//     public static Node sortedArrayToBST(ArrayList<Integer> arr, int start, int end) {
//         if (start > end) return null;
//         int mid = (start + end) / 2;
//         Node root = new Node(arr.get(mid));
//         root.left = sortedArrayToBST(arr, start, mid - 1);
//         root.right = sortedArrayToBST(arr, mid + 1, end);
//         return root;
//     }

//     // Merge two BSTs
//     public static Node mergeBSTs(Node root1, Node root2) {
//         ArrayList<Integer> arr1 = new ArrayList<>();
//         ArrayList<Integer> arr2 = new ArrayList<>();
//         getInorder(root1, arr1);
//         getInorder(root2, arr2);

//         ArrayList<Integer> mergedArr = mergeArrays(arr1, arr2);
//         return sortedArrayToBST(mergedArr, 0, mergedArr.size() - 1);
//     }

//     // Print inorder
//     public static void inorder(Node root) {
//         if (root == null) return;
//         inorder(root.left);
//         System.out.print(root.data + " ");
//         inorder(root.right);
//     }

//     public static void main(String[] args) {
//         // BST 1
//         Node root1 = new Node(4);
//         root1.left = new Node(2);
//         root1.right = new Node(9);

//         // BST 2
//         Node root2 = new Node(3);
//         root2.left = new Node(1);
//         root2.right = new Node(12);

//         Node root = mergeBSTs(root1, root2);

//         System.out.println("Inorder of final merged BST:");
//         inorder(root);  // should print sorted values
//     }
// }

// Input BST 1
//        4
//       / \
//      2   9

// 🌳 Input BST 2
//        3
//       / \
//      1   12


//         3
//        / \
//       1   9
//        \  / \
//         2 4 12




