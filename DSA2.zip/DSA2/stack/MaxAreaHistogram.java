// package stack;
// // // import java.util.*;

// // // public class DuplicateParentheses {
// // //     public static boolean isDuplicate(String str) {
// // //         Stack<Character> s = new Stack<>();

// // //         for (int i = 0; i < str.length(); i++) {
// // //             char ch = str.charAt(i);

// // //             // closing parenthesis
// // //             if (ch == ')') {
// // //                 int count = 0;
// // //                 while (!s.isEmpty() && s.peek() != '(') {
// // //                     s.pop();
// // //                     count++;
// // //                 }

// // //                 // pop the opening bracket
// // //                 if (!s.isEmpty()) {
// // //                     s.pop();
// // //                 }

// // //                 // if nothing inside ( ... ) -> duplicate
// // //                 if (count < 1) {
// // //                     return true;
// // //                 }
// // //             } else {
// // //                 // push everything else
// // //                 s.push(ch);
// // //             }
// // //         }
// // //         return false;
// // //     }

// // //     public static void main(String[] args) {
// // //         String str1 = "(a-b)";     // valid
// // //         String str2 = "((a+b))";   // duplicate

// // //         System.out.println(str1 + " -> " + isDuplicate(str1)); // false
// // //         System.out.println(str2 + " -> " + isDuplicate(str2)); // true
// // //     }
// // // }


// // import java.util.Stack;

// // public class MaxAreaHistogram {
// //     public static int maxArea(int arr[]) {
// //         int n = arr.length;
// //         int maxArea = 0;

// //         int nsr[] = new int[n]; // Next Smaller Right
// //         int nsl[] = new int[n]; // Next Smaller Left

// //         Stack<Integer> s = new Stack<>();

// //         // Step 1: Next Smaller Right
// //         for (int i = n - 1; i >= 0; i--) {
// //             while (!s.isEmpty() && arr[s.peek()] >= arr[i]) {
// //                 s.pop();
// //             }
// //             if (s.isEmpty()) {
// //                 nsr[i] = n; // no smaller to the right
// //             } else {
// //                 nsr[i] = s.peek();
// //             }
// //             s.push(i);
// //         }

// //         // clear stack for NSL
// //         s.clear();

// //         // Step 2: Next Smaller Left
// //         for (int i = 0; i < n; i++) {
// //             while (!s.isEmpty() && arr[s.peek()] >= arr[i]) {
// //                 s.pop();
// //             }
// //             if (s.isEmpty()) {
// //                 nsl[i] = -1; // no smaller to the left
// //             } else {
// //                 nsl[i] = s.peek();
// //             }
// //             s.push(i);
// //         }

// //         // Step 3: Calculate area for each bar
// //         for (int i = 0; i < n; i++) {
// //             int height = arr[i];
// //             int width = nsr[i] - nsl[i] - 1;
// //             int currArea = height * width;
// //             maxArea = Math.max(maxArea, currArea);
// //         }

// //         return maxArea;
// //     }

// //     public static void main(String[] args) {
// //         int arr[] = {2, 1, 5, 6, 2, 3};
// //         System.out.println("Max area in histogram = " + maxArea(arr));
// //     }
// // }
