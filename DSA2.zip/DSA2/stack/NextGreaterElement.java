// package stack;
// // // // // // //stack implementation using ArrayList
// // // // // // import java.util.ArrayList;

// // // // // // public class StackB {
// // // // // //     static class Stack {
// // // // // //         static ArrayList<Integer> list = new ArrayList<>();

// // // // // //         // check if stack is empty
// // // // // //         public static boolean isEmpty() {
// // // // // //             return list.size() == 0;
// // // // // //         }

// // // // // //         // push
// // // // // //         public static void push(int data) {
// // // // // //             list.add(data);
// // // // // //         }

// // // // // //         // pop
// // // // // //         public static int pop() {
// // // // // //             if (isEmpty()) {
// // // // // //                 System.out.println("Stack is empty!");
// // // // // //                 return -1;
// // // // // //             }
// // // // // //             int top = list.get(list.size() - 1);
// // // // // //             list.remove(list.size() - 1);
// // // // // //             return top;
// // // // // //         }

// // // // // //         // peek
// // // // // //         public static int peek() {
// // // // // //             if (isEmpty()) {
// // // // // //                 System.out.println("Stack is empty!");
// // // // // //                 return -1;
// // // // // //             }
// // // // // //             return list.get(list.size() - 1);
// // // // // //         }
// // // // // //     }

// // // // // //     public static void main(String args[]) {
// // // // // //         Stack s = new Stack();
// // // // // //         s.push(1);
// // // // // //         s.push(2);
// // // // // //         s.push(3);

// // // // // //         while (!s.isEmpty()) {
// // // // // //             System.out.println(s.peek());
// // // // // //             s.pop();
// // // // // //         }
// // // // // //     }
// // // // // // }





// // // // // public class StackLinkedList {
// // // // //     static class Node {
// // // // //         int data;
// // // // //         Node next;

// // // // //         Node(int data) {
// // // // //             this.data = data;
// // // // //             this.next = null;
// // // // //         }
// // // // //     }

// // // // //     static class Stack {
// // // // //         static Node head = null;

// // // // //         // check empty
// // // // //         public static boolean isEmpty() {
// // // // //             return head == null;
// // // // //         }

// // // // //         // push
// // // // //         public static void push(int data) {
// // // // //             Node newNode = new Node(data);
// // // // //             if (isEmpty()) {
// // // // //                 head = newNode;
// // // // //                 return;
// // // // //             }
// // // // //             newNode.next = head;
// // // // //             head = newNode;
// // // // //         }

// // // // //         // pop
// // // // //         public static int pop() {
// // // // //             if (isEmpty()) {
// // // // //                 System.out.println("Stack is empty!");
// // // // //                 return -1;
// // // // //             }
// // // // //             int top = head.data;
// // // // //             head = head.next;
// // // // //             return top;
// // // // //         }

// // // // //         // peek
// // // // //         public static int peek() {
// // // // //             if (isEmpty()) {
// // // // //                 System.out.println("Stack is empty!");
// // // // //                 return -1;
// // // // //             }
// // // // //             return head.data;
// // // // //         }
// // // // //     }

// // // // //     public static void main(String[] args) {
// // // // //         Stack s = new Stack();
// // // // //         s.push(1);
// // // // //         s.push(2);
// // // // //         s.push(3);

// // // // //         while (!s.isEmpty()) {
// // // // //             System.out.println(s.peek());
// // // // //             s.pop();
// // // // //         }
// // // // //     }
// // // // // }



// // // // import java.util.Stack;

// // // // public class StackFramework {
// // // //     public static void main(String[] args) {
// // // //         Stack<Integer> s = new Stack<>();

// // // //         // push
// // // //         s.push(1);
// // // //         s.push(2);
// // // //         s.push(3);

// // // //         // print stack top to bottom
// // // //         while (!s.isEmpty()) {
// // // //             System.out.println(s.peek());
// // // //             s.pop();
// // // //         }
// // // //     }
// // // // }

// // // import java.util.*;

// // // public class StackB {

// // //     // 1. Push at Bottom of Stack
// // //     public static void pushAtBottom(Stack<Integer> s, int data) {
// // //         if (s.isEmpty()) {
// // //             s.push(data);
// // //             return;
// // //         }
// // //         int top = s.pop();
// // //         pushAtBottom(s, data);
// // //         s.push(top);
// // //     }

// // //     // 2. Reverse a String using Stack
// // //     public static String reverseString(String str) {
// // //         Stack<Character> s = new Stack<>();
// // //         int idx = 0;

// // //         while (idx < str.length()) {
// // //             s.push(str.charAt(idx));
// // //             idx++;
// // //         }

// // //         StringBuilder result = new StringBuilder("");
// // //         while (!s.isEmpty()) {
// // //             char curr = s.pop();
// // //             result.append(curr);
// // //         }
// // //         return result.toString();
// // //     }

// // //     // 3. Reverse a Stack using recursion
// // //     public static void reverseStack(Stack<Integer> s) {
// // //         if (s.isEmpty()) {
// // //             return;
// // //         }
// // //         int top = s.pop();
// // //         reverseStack(s);
// // //         pushAtBottom(s, top);
// // //     }

// // //     // 4. Stock Span Problem
// // //     public static void stockSpan(int stocks[]) {
// // //         Stack<Integer> s = new Stack<>();
// // //         int span[] = new int[stocks.length];

// // //         // first day span is always 1
// // //         span[0] = 1;
// // //         s.push(0);

// // //         for (int i = 1; i < stocks.length; i++) {
// // //             int currPrice = stocks[i];

// // //             while (!s.isEmpty() && currPrice > stocks[s.peek()]) {
// // //                 s.pop();
// // //             }

// // //             if (s.isEmpty()) {
// // //                 span[i] = i + 1;
// // //             } else {
// // //                 int prevHigh = s.peek();
// // //                 span[i] = i - prevHigh;
// // //             }
// // //             s.push(i);
// // //         }

// // //         // print span
// // //         for (int i = 0; i < span.length; i++) {
// // //             System.out.print(span[i] + " ");
// // //         }
// // //         System.out.println();
// // //     }

// // //     // Main function
// // //     public static void main(String[] args) {
// // //         // 1. Push at bottom test
// // //         Stack<Integer> s = new Stack<>();
// // //         s.push(1);
// // //         s.push(2);
// // //         s.push(3);
// // //         pushAtBottom(s, 4);
// // //         System.out.println("After pushAtBottom:");
// // //         while (!s.isEmpty()) {
// // //             System.out.println(s.pop());
// // //         }

// // //         // 2. Reverse String test
// // //         String str = "hello";
// // //         System.out.println("\nReversed String: " + reverseString(str));

// // //         // 3. Reverse Stack test
// // //         Stack<Integer> s2 = new Stack<>();
// // //         s2.push(1);
// // //         s2.push(2);
// // //         s2.push(3);
// // //         reverseStack(s2);
// // //         System.out.println("\nReversed Stack:");
// // //         while (!s2.isEmpty()) {
// // //             System.out.println(s2.pop());
// // //         }

// // //         // 4. Stock Span test
// // //         int stocks[] = {100, 80, 60, 70, 60, 85, 100};
// // //         System.out.println("\nStock Span:");
// // //         stockSpan(stocks);
// // //     }
// // // }


// // // Next Greater Element
// // // The next greater element of some element x in an array is the first greater
// // // element that is to the right of x in the same array.
// // // arr [6, 8, O, 1, 31]
// // // next Greater = [8, -1, 1, 3, -11]


// // import java.util.*;

// // public class NextGreaterElement {
// //     public static void main(String args[]) {
// //         int arr[] = {6, 8, 0, 1, 3};
// //         int n = arr.length;

// //         int nxtGreater[] = new int[n];
// //         Stack<Integer> s = new Stack<>();

// //         // Traverse from right to left
// //         for (int i = n - 1; i >= 0; i--) {
// //             int curr = arr[i];

// //             // 1. Pop smaller or equal elements
// //             while (!s.isEmpty() && s.peek() <= curr) {
// //                 s.pop();
// //             }

// //             // 2. If stack is empty, no greater element
// //             if (s.isEmpty()) {
// //                 nxtGreater[i] = -1;
// //             } else {
// //                 nxtGreater[i] = s.peek();
// //             }

// //             // 3. Push current element into stack
// //             s.push(curr);
// //         }

// //         // Print result
// //         System.out.print("Next Greater Elements: ");
// //         for (int i = 0; i < n; i++) {
// //             System.out.print(nxtGreater[i] + " ");
// //         }
// //         System.out.println();
// //     }
// // }


