// // // LinkedList collection framework

// // // import java.util.LinkedList;

// // // public class Classroom {
// // //     public static void main(String args[]) {
// // //         // create
// // //         LinkedList<Integer> ll = new LinkedList<>();

// // //         // add
// // //         ll.addLast(1);
// // //         ll.addLast(2);
// // //         ll.addFirst(0);

// // //         // print
// // //         System.out.println(ll);

// // //         // remove
// // //         ll.removeLast();
// // //         System.out.println(ll);
// // //     }
// // // }

// // // LinkedList - Merge Sort 

// // class LinkedList {
// //     Node head;

// //     // Node class
// //     private static class Node {
// //         int data;
// //         Node next;

// //         Node(int data) {
// //             this.data = data;
// //             this.next = null;
// //         }
// //     }

// //     // addFirst
// //     public void addFirst(int data) {
// //         Node newNode = new Node(data);
// //         newNode.next = head;
// //         head = newNode;
// //     }

// //     // print
// //     public void printList(Node head) {
// //         Node temp = head;
// //         while (temp != null) {
// //             System.out.print(temp.data + " ");
// //             temp = temp.next;
// //         }
// //         System.out.println();
// //     }

// //     // merge sort
// //     public Node mergeSort(Node head) {
// //         if (head == null || head.next == null) {
// //             return head;
// //         }

// //         Node mid = getMid(head);
// //         Node rightHead = mid.next;
// //         mid.next = null;

// //         Node left = mergeSort(head);
// //         Node right = mergeSort(rightHead);

// //         return merge(left, right);
// //     }

// //     // merge two sorted lists
// //     private Node merge(Node head1, Node head2) {
// //         Node mergedLL = new Node(-1);
// //         Node temp = mergedLL;

// //         while (head1 != null && head2 != null) {
// //             if (head1.data <= head2.data) {
// //                 temp.next = head1;
// //                 head1 = head1.next;
// //             } else {
// //                 temp.next = head2;
// //                 head2 = head2.next;
// //             }
// //             temp = temp.next;
// //         }

// //         // remaining elements
// //         if (head1 != null) temp.next = head1;
// //         if (head2 != null) temp.next = head2;

// //         return mergedLL.next;
// //     }

// //     // get mid node
// //     private Node getMid(Node head) {
// //         Node slow = head;
// //         Node fast = head.next;

// //         while (fast != null && fast.next != null) {
// //             slow = slow.next;
// //             fast = fast.next.next;
// //         }
// //         return slow; // mid node
// //     }

// //     // main
// //     public static void main(String args[]) {
// //         LinkedList ll = new LinkedList();

// //         ll.addFirst(1);
// //         ll.addFirst(2);
// //         ll.addFirst(3);
// //         ll.addFirst(4);
// //         ll.addFirst(5);

// //         System.out.println("Original List:");
// //         ll.printList(ll.head);

// //         ll.head = ll.mergeSort(ll.head);

// //         System.out.println("Sorted List:");
// //         ll.printList(ll.head);
// //     }
// // }

// // Zig-Zag Linked List

// class LinkedList {
//     Node head;

//     // Node class
//     private static class Node {
//         int data;
//         Node next;

//         Node(int data) {
//             this.data = data;
//             this.next = null;
//         }
//     }

//     // addLast
//     public void addLast(int data) {
//         Node newNode = new Node(data);
//         if (head == null) {
//             head = newNode;
//             return;
//         }
//         Node temp = head;
//         while (temp.next != null) {
//             temp = temp.next;
//         }
//         temp.next = newNode;
//     }

//     // print
//     public void print() {
//         Node temp = head;
//         while (temp != null) {
//             System.out.print(temp.data + " ");
//             temp = temp.next;
//         }
//         System.out.println();
//     }

//     // zig-zag function
//     public void zigZag() {
//         // find mid
//         Node slow = head;
//         Node fast = head.next;

//         while (fast != null && fast.next != null) {
//             slow = slow.next;
//             fast = fast.next.next;
//         }

//         Node mid = slow;

//         // 2nd half reverse
//         Node curr = mid.next;
//         mid.next = null;
//         Node prev = null;
//         Node next;

//         while (curr != null) {
//             next = curr.next;
//             curr.next = prev;
//             prev = curr;
//             curr = next;
//         }

//         Node left = head;
//         Node right = prev;

//         // zig-zag merge
//         Node nextL, nextR;
//         while (left != null && right != null) {
//             nextL = left.next;
//             nextR = right.next;

//             left.next = right;
//             if (nextL == null) break;
//             right.next = nextL;

//             left = nextL;
//             right = nextR;
//         }
//     }

//     // main
//     public static void main(String args[]) {
//         LinkedList ll = new LinkedList();

//         ll.addLast(1);
//         ll.addLast(2);
//         ll.addLast(3);
//         ll.addLast(4);
//         ll.addLast(5);

//         System.out.println("Original List:");
//         ll.print();

//         ll.zigZag();

//         System.out.println("Zig-Zag List:");
//         ll.print();
//     }
// }

public class DoubleLL {
    // Node class
    class Node {
        int data;
        Node next;
        Node prev;

        Node(int data) {
            this.data = data;
            this.next = null;
            this.prev = null;
        }
    }

    // Head, tail and size
    private Node head;
    private Node tail;
    private int size;

    // Add at the beginning
    public void addFirst(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = tail = newNode;
        } else {
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
        }
        size++;
    }

    // Print list
    public void print() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + "<->");
            temp = temp.next;
        }
        System.out.println("null");
    }

    // Remove first node
    public void removeFirst() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }
        if (head == tail) { // only one element
            head = tail = null;
        } else {
            head = head.next;
            head.prev = null;
        }
        size--;
    }

    // Remove last node
    public void removeLast() {
        if (tail == null) {
            System.out.println("List is empty");
            return;
        }
        if (head == tail) { // only one element
            head = tail = null;
        } else {
            tail = tail.prev;
            tail.next = null;
        }
        size--;
    }

    // Reverse list
    public void reverse() {
        Node curr = head;
        Node prevNode = null;
        Node nextNode;

        while (curr != null) {
            nextNode = curr.next;
            curr.next = prevNode;
            curr.prev = nextNode;
            prevNode = curr;
            curr = nextNode;
        }
        // Swap head and tail
        Node temp = head;
        head = tail;
        tail = temp;
    }

    // Main method
    public static void main(String[] args) {
        DoubleLL dll = new DoubleLL();

        // Add elements
        dll.addFirst(3);
        dll.addFirst(2);
        dll.addFirst(1);

        System.out.println("Original List:");
        dll.print();

        dll.removeFirst();
        System.out.println("After removeFirst:");
        dll.print();

        dll.removeLast();
        System.out.println("After removeLast:");
        dll.print();

        dll.addFirst(5);
        dll.addFirst(4);
        dll.addFirst(3);
        System.out.println("Before reverse:");
        dll.print();

        dll.reverse();
        System.out.println("After reverse:");
        dll.print();

        System.out.println("Final size: " + dll.size);
    }
}
