// // Linked List Implementation in Java
// public class LinkedList {

//     // Node class definition
//     public static class Node {
//         int data;
//         Node next;

//         public Node(int data) {
//             this.data = data; // Assign data
//             this.next = null; // Initially next is null
//         }
//     }

//     public static Node head;
//     public static Node tail;
//     public static int size;

//     // Add node at beginning of the list
//     public void addFirst(int data) {
//         Node newNode = new Node(data); // Create new node
//         size++;

//         if (head == null) { // If list is empty
//             head = tail = newNode;
//             return;
//         }

//         newNode.next = head; // Point new node to current head
//         head = newNode; // Update head to new node
//     }

//     // Add node at end of the list
//     public void addLast(int data) {
//         Node newNode = new Node(data); // Create new node
//         size++;

//         if (head == null) {
//             head = tail = newNode;
//             return;
//         }

//         tail.next = newNode; // Link current tail to new node
//         tail = newNode; // Update tail
//     }

//     // Print Linked List
//     public void print() {
//         if (head == null) {
//             System.out.println("LL is empty");
//             return;
//         }

//         Node temp = head;
//         while (temp != null) {
//             System.out.print(temp.data + " "); // Print current node data
//             temp = temp.next; // Move to next node
//         }
//         System.out.println();
//     }

//     // Add node at specific index
//     public void add(int idx, int data) {
//         if (idx == 0) {
//             addFirst(data);
//             return;
//         }

//         Node newNode = new Node(data);
//         Node temp = head;
//         int i = 0;

//         while (i < idx - 1) {
//             temp = temp.next;
//             i++;
//         }

//         newNode.next = temp.next;
//         temp.next = newNode;
//         size++;
//     }

//     // Remove first node
//     public int removeFirst() {
//         if (size == 0) {
//             System.out.println("LL is empty");
//             return Integer.MIN_VALUE;
//         } else if (size == 1) {
//             int val = head.data;
//             head = tail = null;
//             size = 0;
//             return val;
//         }

//         int val = head.data;
//         head = head.next;
//         size--;
//         return val;
//     }

//     // Remove last node
//     public int removeLast() {
//         if (size == 0) {
//             System.out.println("LL is empty");
//             return Integer.MIN_VALUE;
//         } else if (size == 1) {
//             int val = head.data;
//             head = tail = null;
//             size = 0;
//             return val;
//         }

//         Node prev = head;
//         for (int i = 0; i < size - 2; i++) {
//             prev = prev.next;
//         }

//         int val = prev.next.data;
//         prev.next = null;
//         tail = prev;
//         size--;
//         return val;
//     }

//     // Iterative search
//     public int itrSearch(int key) {
//         Node temp = head;
//         int i = 0;

//         while (temp != null) {
//             if (temp.data == key) {
//                 return i; // Key found
//             }
//             temp = temp.next;
//             i++;
//         }

//         return -1; // Key not found
//     }

//     // Recursive search helper
//     public int helper(Node head, int key) {
//         if (head == null) return -1;
//         if (head.data == key) return 0;

//         int idx = helper(head.next, key);
//         return (idx == -1) ? -1 : idx + 1;
//     }

//     // Recursive search
//     public int recSearch(int key) {
//         return helper(head, key);
//     }

//     // Reverse the linked list
//     public void reverse() {
//         Node prev = null;
//         Node curr = head;
//         Node next;

//         while (curr != null) {
//             next = curr.next;
//             curr.next = prev;
//             prev = curr;
//             curr = next;
//         }

//         head = prev;
//     }

//     // Delete Nth node from end
//     public void deleteNthfromEnd(int n) {
//         // Step 1: calculate total size
//         int sz = 0;
//         Node temp = head;
//         while (temp != null) {
//             temp = temp.next;
//             sz++;
//         }

//         if (n == sz) {
//             head = head.next; // Remove first
//             size--;
//             return;
//         }

//         // Step 2: reach node before target
//         int iToFind = sz - n;
//         Node prev = head;
//         for (int i = 1; i < iToFind; i++) {
//             prev = prev.next;
//         }

//         prev.next = prev.next.next;
//         size--;
//     }

//     // Find middle of the list
//     public Node findMid(Node head) {
//         Node slow = head;
//         Node fast = head;

//         while (fast != null && fast.next != null) {
//             slow = slow.next; // Move by 1
//             fast = fast.next.next; // Move by 2
//         }

//         return slow; // Midpoint
//     }

//     // Check if linked list is palindrome
//     public boolean checkPalindrome() {
//         if (head == null || head.next == null) return true;

//         // Step 1 - Find mid
//         Node midNode = findMid(head);

//         // Step 2 - Reverse 2nd half
//         Node prev = null;
//         Node curr = midNode;
//         Node next;

//         while (curr != null) {
//             next = curr.next;
//             curr.next = prev;
//             prev = curr;
//             curr = next;
//         }

//         // Step 3 - Compare both halves
//         Node right = prev;
//         Node left = head;

//         while (right != null) {
//             if (left.data != right.data) {
//                 return false;
//             }
//             left = left.next;
//             right = right.next;
//         }

//         return true;
//     }

//     // Detect cycle in linked list (Floyd's Cycle Detection)
//     public boolean isCycle() {
//         Node slow = head;
//         Node fast = head;

//         while (fast != null && fast.next != null) {
//             slow = slow.next;       // Move by 1
//             fast = fast.next.next;  // Move by 2

//             if (slow == fast) {
//                 return true; // Cycle detected
//             }
//         }

//         return false; // No cycle
//     }

//     // Remove cycle from linked list
//     public void removeCycle() {
//         Node slow = head;
//         Node fast = head;
//         boolean cycle = false;

//         // Detect cycle using Floyd’s algorithm
//         while (fast != null && fast.next != null) {
//             slow = slow.next;
//             fast = fast.next.next;

//             if (slow == fast) {
//                 cycle = true;
//                 break;
//             }
//         }

//         if (!cycle) return;

//         // Find start of the cycle
//         slow = head;
//         Node prev = null; // Previous node to break the cycle

//         while (slow != fast) {
//             prev = fast;
//             slow = slow.next;
//             fast = fast.next;
//         }

//         // Break the cycle
//         prev.next = null;
//     }

//     // Main method to test LinkedList operations
//     public static void main(String args[]) {
//         LinkedList ll = new LinkedList();

//         ll.addFirst(1);
//         ll.addFirst(2);
//         ll.addLast(1);
//         ll.addLast(2);

//         System.out.print("Original list: ");
//         ll.print();

//         System.out.println("Is Palindrome: " + ll.checkPalindrome());

//         ll.reverse();
//         System.out.print("Reversed list: ");
//         ll.print();

//         System.out.println("Index of 2: " + ll.itrSearch(2));

//         ll.deleteNthfromEnd(2);
//         System.out.print("After deleting 2nd from end: ");
//         ll.print();

//         // Add a cycle for testing
//         head.next.next.next = head; // Creating a cycle (e.g., 2 -> 1 -> 1 -> 2 -> back to 2)
//         System.out.println("Cycle exists: " + ll.isCycle());
//         ll.removeCycle();
//         System.out.println("Cycle exists after removal: " + ll.isCycle());

//         System.out.print("Final list: ");
//         ll.print();
//     }
// }
